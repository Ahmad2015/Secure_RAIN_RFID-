 #!/bin/sh
#  Script.sh
#  
#
#  Created by Ahmad Shahrafidz Khalid on 19/02/2016.
#
# declare STRING variable


#for i in {1..30}
#do

#echo 2
#./LocPriv -u Cmdenv -f ../simulations/omnetppQ2.ini -c NoAuth1 -n ../src:.:../../inet/src -l ../../inet/src/inet -c NoAuth >> q2NoA.txt

echo 20q2
./../../src/LocPriv -u Cmdenv -f t20All.ini -c NoAuth1 -n ../../src:.:../../../inet/src -l ../../../inet/src/inet > t20All.txt
