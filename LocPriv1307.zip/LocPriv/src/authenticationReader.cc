//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "authenticationReader.h"
//#include "command.h"


Define_Module(AuthenticationReader);

void AuthenticationReader::initialize() {
    // TODO - Generated method body]
    frReader    = gate("frReader");
    toReader    = gate("toReader");
    csiId       = par("CryptoSuite");
}

BYTE rsKey[64] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
                 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13,
                 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d,
                 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
                 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31,
                 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b,
                 0x3c, 0x3d, 0x3e, 0x3f};

//128bit keyR
 int ikey[] = {
         0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
         0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};

void AuthenticationReader::HMAC_SHA1( BYTE text[12], int text_len, BYTE *key, int key_len, BYTE *digest) {
    m_block = (SHA1_WORKSPACE_BLOCK *)m_workspace;

    //for (int i=0;i<64;i++) {
     //   m_ipad[i]=0;
     //   m_opad[i]=0;
     //   szReport[i]=0;
    //    AppendBuf1[i]=0;
    //    AppendBuf2[i]=0;
    //    SHA1_Key[i]=0;
    //}

    //initialize with 0
    memset(SHA1_Key, 0x00, SHA1_BLOCK_SIZE); //SHA1_BLOCK_SIZE = 64
    memset(AppendBuf1,0x00,sizeof(AppendBuf1));
    memset(AppendBuf2,0x00,sizeof(AppendBuf2));
    //memset=(szReport,0x00,sizeof(szReport));

    // repeated 64 times for values in ipad and opad
    memset(m_ipad, 0x36, sizeof(m_ipad)); //decimal 54
    memset(m_opad, 0x5c, sizeof(m_opad)); //decimal 92
   // EV <<"\n text in clear:\t:" << text;

    EV <<"\nText in HEX:\t"; dispHEX((unsigned char *)text, text_len);
    EV <<"\n\nkey:\t";       dispHEX((unsigned char *)key, key_len);

   // EV << thisNode->getParentModule()->getSubmodule("tag");
    //pos = mod->getCurrentPosition();
    //EV <<"\n\nTag Real coordinate: (" << pos.x <<"," <<pos.y<<","<<pos.z<<")"<<endl;

    // STEP 1
    //if key length is equal to the block size
    if (key_len > SHA1_BLOCK_SIZE) {
        Reset();
        Update((BYTE *)key, key_len);
        Final();
        GetHash((BYTE *)SHA1_Key);
   }
    else {
        memcpy(SHA1_Key, key, key_len);
        }

    EV <<"\n\nK0:\t";
    dispHEX((unsigned char *) SHA1_Key, sizeof(SHA1_Key));

    // STEP 2
    for (int i=0; i<sizeof(m_ipad); i++) {
        m_ipad[i] ^= SHA1_Key[i];
    }
    EV <<"\n\nStep 2:\nK0 ^ ipad:\t";
    dispHEX((unsigned char *) m_ipad, sizeof(m_ipad));

    // STEP 3
    memcpy(AppendBuf1, m_ipad, sizeof(m_ipad));
    memcpy(AppendBuf1 + sizeof(m_ipad), text, text_len);
    EV << "\n\nSTEP 3\n(K0^ipad||text):\t";
    dispHEX((unsigned char *) AppendBuf1, 64+text_len);

    // STEP 4
    Reset();
    Update((BYTE *)AppendBuf1, sizeof(m_ipad) + text_len);
    Final();
    GetHash((BYTE *)szReport);
    EV << "\n\nSTEP 4:\nHash(K0^ipad||text) after:";
    dispHEX(szReport, std::strlen((char *)szReport));

    // STEP 5
    for (int j=0; j<sizeof(m_opad); j++) {
        m_opad[j] ^= SHA1_Key[j];
    }
     EV <<"\n\nStep5\nopad ^ KO:\t";// for (int i=0;i<64;i++) EV<< m_opad[i]+1-1;
     dispHEX((unsigned char *)m_opad, sizeof(m_opad));

    // STEP 6
//  EV <<"\n\nStep 6 b4:\n";
     dispHEX(AppendBuf2, 64);
    memcpy(AppendBuf2, m_opad, sizeof(m_opad));
    memcpy(AppendBuf2 + sizeof(m_opad), szReport, SHA1_DIGEST_LENGTH);
    EV <<"\n\nStep 6\n(K0 ^ opad) || Hash((Key ^ ipad)||text)";
 //   dispHEX(AppendBuf2, sizeof(m_opad)+SHA1_DIGEST_LENGTH);


    //STEP 7
    Reset();
    Update((BYTE *)AppendBuf2, sizeof(m_opad) + SHA1_DIGEST_LENGTH);
    Final();
    GetHash((BYTE *)digest);

    EV <<"\n\nSTEP 7\nHMAC(Key, Text) = Hash((K0^opad)||Hash(Key ^ ipad)||clearEPC))";
    dispHEX((unsigned char *) digest,20);


 //   cPacket *result = (cPacket *)digest;
 //   cPacket *pktOut = new cPacket;
 //   pktOut->setName("HMACSHA1");
 //   pktOut->addPar("hmac");
 //   pktOut->par("hmac").setStringValue((char *)digest);
 //   send(pktOut,toTag);

}


// ****** BAWAK DR SHA1 ***


void AuthenticationReader::Reset() {
    // SHA1 initialization constants
    m_state[0] = 0x67452301;
    m_state[1] = 0xEFCDAB89;
    m_state[2] = 0x98BADCFE;
    m_state[3] = 0x10325476;
    m_state[4] = 0xC3D2E1F0;

    m_count[0] = 0;
    m_count[1] = 0;
}

void AuthenticationReader::Transform(UINT_32 *state, BYTE *buffer) {
    // Copy state[] to working vars
        UINT_32 a, b, c, d, e;

        a = state[0];
        b = state[1];
        c = state[2];
        d = state[3];
        e = state[4];

        memcpy(m_block, buffer, 64);

        // 4 rounds of 20 operations each. Loop unrolled.
        _R0(a,b,c,d,e, 0); _R0(e,a,b,c,d, 1); _R0(d,e,a,b,c, 2); _R0(c,d,e,a,b, 3);
        _R0(b,c,d,e,a, 4); _R0(a,b,c,d,e, 5); _R0(e,a,b,c,d, 6); _R0(d,e,a,b,c, 7);
        _R0(c,d,e,a,b, 8); _R0(b,c,d,e,a, 9); _R0(a,b,c,d,e,10); _R0(e,a,b,c,d,11);
        _R0(d,e,a,b,c,12); _R0(c,d,e,a,b,13); _R0(b,c,d,e,a,14); _R0(a,b,c,d,e,15);
        _R1(e,a,b,c,d,16); _R1(d,e,a,b,c,17); _R1(c,d,e,a,b,18); _R1(b,c,d,e,a,19);
        _R2(a,b,c,d,e,20); _R2(e,a,b,c,d,21); _R2(d,e,a,b,c,22); _R2(c,d,e,a,b,23);
        _R2(b,c,d,e,a,24); _R2(a,b,c,d,e,25); _R2(e,a,b,c,d,26); _R2(d,e,a,b,c,27);
        _R2(c,d,e,a,b,28); _R2(b,c,d,e,a,29); _R2(a,b,c,d,e,30); _R2(e,a,b,c,d,31);
        _R2(d,e,a,b,c,32); _R2(c,d,e,a,b,33); _R2(b,c,d,e,a,34); _R2(a,b,c,d,e,35);
        _R2(e,a,b,c,d,36); _R2(d,e,a,b,c,37); _R2(c,d,e,a,b,38); _R2(b,c,d,e,a,39);
        _R3(a,b,c,d,e,40); _R3(e,a,b,c,d,41); _R3(d,e,a,b,c,42); _R3(c,d,e,a,b,43);
        _R3(b,c,d,e,a,44); _R3(a,b,c,d,e,45); _R3(e,a,b,c,d,46); _R3(d,e,a,b,c,47);
        _R3(c,d,e,a,b,48); _R3(b,c,d,e,a,49); _R3(a,b,c,d,e,50); _R3(e,a,b,c,d,51);
        _R3(d,e,a,b,c,52); _R3(c,d,e,a,b,53); _R3(b,c,d,e,a,54); _R3(a,b,c,d,e,55);
        _R3(e,a,b,c,d,56); _R3(d,e,a,b,c,57); _R3(c,d,e,a,b,58); _R3(b,c,d,e,a,59);
        _R4(a,b,c,d,e,60); _R4(e,a,b,c,d,61); _R4(d,e,a,b,c,62); _R4(c,d,e,a,b,63);
        _R4(b,c,d,e,a,64); _R4(a,b,c,d,e,65); _R4(e,a,b,c,d,66); _R4(d,e,a,b,c,67);
        _R4(c,d,e,a,b,68); _R4(b,c,d,e,a,69); _R4(a,b,c,d,e,70); _R4(e,a,b,c,d,71);
        _R4(d,e,a,b,c,72); _R4(c,d,e,a,b,73); _R4(b,c,d,e,a,74); _R4(a,b,c,d,e,75);
        _R4(e,a,b,c,d,76); _R4(d,e,a,b,c,77); _R4(c,d,e,a,b,78); _R4(b,c,d,e,a,79);

        // Add the working vars back into state
        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
        state[4] += e;

        // Wipe variables
        a = b = c = d = e = 0;
}

void AuthenticationReader::Update(BYTE *data, UINT_32 len) {
    UINT_32 i, j;

    j = (m_count[0] >> 3) & 63;

    if((m_count[0] += len << 3) < (len << 3)) m_count[1]++;

    m_count[1] += (len >> 29);

    if((j + len) > 63) {
        i = 64 - j;
        memcpy(&m_buffer[j], data, i);
        Transform(m_state, m_buffer);
        for(; i + 63 < len; i += 64) Transform(m_state, &data[i]);
       j = 0;
    }
    else i = 0;

    memcpy(&m_buffer[j], &data[i], len - i);
}

void AuthenticationReader::Final() {
    UINT_32 i;
    BYTE finalcount[8];

    for(i = 0; i < 8; i++)
        finalcount[i] = (BYTE)((m_count[((i >= 4) ? 0 : 1)]
            >> ((3 - (i & 3)) * 8) ) & 255); // Endian independent

    Update((BYTE *)"\200", 1);

    while ((m_count[0] & 504) != 448)
        Update((BYTE *)"\0", 1);

    Update(finalcount, 8); // Cause a SHA1Transform()

    for(i = 0; i < 20; i++) {
        m_digest[i] = (BYTE)((m_state[i >> 2 ] >> ((3 - (i & 3)) * 8) ) & 255);
    }
}

void AuthenticationReader::GetHash(BYTE *puDest) {
    memcpy(puDest, m_digest, 20);
 }



void AuthenticationReader::dispHEX(unsigned char *msg, int msgLength) {

    for (int i=0;i<msgLength;i++) {
        //EV <<" <"<< msg[i]-0<<"> ";
         if (i % 4 == 0) EV << " ";
         if (i % 16 == 0) EV << "\n";

         if ((int) msg[i] /16 == 0)       { EV <<"0"; hmSHA1[i] = 0;     }
         else if ((int) msg[i] /16 == 1)  { EV <<"1"; hmSHA1[i] = 1*16;  }
         else if ((int) msg[i] /16 == 2)  { EV <<"2"; hmSHA1[i] = 2*16;  }
         else if ((int) msg[i] /16 == 3)  { EV <<"3"; hmSHA1[i] = 3*16;  }
         else if ((int) msg[i] /16 == 4)  { EV <<"4"; hmSHA1[i] = 4*16;  }
         else if ((int) msg[i] /16 == 5)  { EV <<"5"; hmSHA1[i] = 5*16;  }
         else if ((int) msg[i] /16 == 6)  { EV <<"6"; hmSHA1[i] = 6*16;  }
         else if ((int) msg[i] /16 == 7)  { EV <<"7"; hmSHA1[i] = 7*16;  }
         else if ((int) msg[i] /16 == 8)  { EV <<"8"; hmSHA1[i] = 8*16;  }
         else if ((int) msg[i] /16 == 9)  { EV <<"9"; hmSHA1[i] = 9*16;  }
         else if ((int) msg[i] /16 == 10) { EV <<"A"; hmSHA1[i] = 10*16; }
         else if ((int) msg[i] /16 == 11) { EV <<"B"; hmSHA1[i] = 11*16; }
         else if ((int) msg[i] /16 == 12) { EV <<"C"; hmSHA1[i] = 12*16; }
         else if ((int) msg[i] /16 == 13) { EV <<"D"; hmSHA1[i] = 13*16; }
         else if ((int) msg[i] /16 == 14) { EV <<"E"; hmSHA1[i] = 14*16; }
         else if ((int) msg[i] /16 == 15) { EV <<"F"; hmSHA1[i] = 15*16; }

         if ((int) msg[i] %16 == 0)       { EV <<"0"; hmSHA1[i] += 0;  }
         else if ((int) msg[i] %16 == 1)  { EV <<"1"; hmSHA1[i] += 1;  }
         else if ((int) msg[i] %16 == 2)  { EV <<"2"; hmSHA1[i] += 2;  }
         else if ((int) msg[i] %16 == 3)  { EV <<"3"; hmSHA1[i] += 3;  }
         else if ((int) msg[i] %16 == 4)  { EV <<"4"; hmSHA1[i] += 4;  }
         else if ((int) msg[i] %16 == 5)  { EV <<"5"; hmSHA1[i] += 5;  }
         else if ((int) msg[i] %16 == 6)  { EV <<"6"; hmSHA1[i] += 6;  }
         else if ((int) msg[i] %16 == 7)  { EV <<"7"; hmSHA1[i] += 7;  }
         else if ((int) msg[i] %16 == 8)  { EV <<"8"; hmSHA1[i] += 8;  }
         else if ((int) msg[i] %16 == 9)  { EV <<"9"; hmSHA1[i] += 9;  }
         else if ((int) msg[i] %16 == 10) { EV <<"A"; hmSHA1[i] += 10; }
         else if ((int) msg[i] %16 == 11) { EV <<"B"; hmSHA1[i] += 11; }
         else if ((int) msg[i] %16 == 12) { EV <<"C"; hmSHA1[i] += 12; }
         else if ((int) msg[i] %16 == 13) { EV <<"D"; hmSHA1[i] += 13; }
         else if ((int) msg[i] %16 == 14) { EV <<"E"; hmSHA1[i] += 14; }
         else if ((int) msg[i] %16 == 15) { EV <<"F"; hmSHA1[i] += 15; }
     }
}


void AuthenticationReader::handleMessage(cMessage *msg) {
    // TODO - Generated method body
    if (strcmp(msg->getName(),"decryptECP") == 0) {
        EV << "\nreceived decryptECP\n";
        //decryptEPC(msg);
    }
    else if (strcmp(msg->getName(),"authStart") == 0) {
         cPacket *pktIn = check_and_cast <cPacket *> (msg);
         authPacket *msgIn = check_and_cast <authPacket *> (pktIn->decapsulate());
         EV<< "auth:\t"<< msgIn->getAuthType();
         verify1 = false; // reinitialize

         if (msgIn->getAuthType() == NOAUTH) {
             noAuthentication();
         }
         else if (msgIn->getAuthType() == PRESENT80) {
             requestPRESENT();
         }
         else if (msgIn->getAuthType() == XOR) { //XOR
             requestXOR();
         }
         else if (msgIn->getAuthType() == GPSCCR) {
             requestGPSCCR();
         }
         else if (msgIn->getAuthType() == AES128ECB) {
             requestAES128ECB();
         }
         else if (msgIn->getAuthType() == AES128CBC) {
             requestAES128CBC();
         }
         delete msgIn;
         // delete pktIn;
         // delete msg;
     }
    else if (strcmp(msg->getName(),"Response") == 0) {
        if (csiId == PRESENT80) {
            verifyPRESENT(msg);
        }
        else if (csiId == XOR) { //XOR
            verifyXOR(msg);
        }
        else if (csiId == GPSCCR) {
            EV <<"\nverify value:\t"<<verify1;
            if (verify1 == false) {
                verify1GPSCCR(msg);
                verify1 = true;
            }
            else verify2GPSCCR(msg);
        }
        else if (csiId == AES128ECB) {
            verifyAES128ECB(msg);
        }
        else if (csiId == AES128CBC) {
            verifyAES128CBC(msg);
        }
        // delete msg;
    }
    delete msg;
}

void AuthenticationReader::decryptEPC(cMessage *msg) {
    msgHideEPC *msgIn = check_and_cast<msgHideEPC *>(msg);

    //128bit output
    int output[16] = {0};
    int input[16] = {
            msgIn->getHideEPC128(0), msgIn->getHideEPC128(1),
            msgIn->getHideEPC128(2),msgIn->getHideEPC128(3),
            msgIn->getHideEPC128(4),msgIn->getHideEPC128(5),
            msgIn->getHideEPC128(6),msgIn->getHideEPC128(7),
            msgIn->getHideEPC128(8),msgIn->getHideEPC128(9),
            msgIn->getHideEPC128(10),msgIn->getHideEPC128(11),
            msgIn->getHideEPC128(12),msgIn->getHideEPC128(13),
            msgIn->getHideEPC128(14),msgIn->getHideEPC128(15)
    };

    for (int i=0;i<msgIn->getHideEPC128ArraySize();i++) {
        EV << msgIn->getHideEPC128(i) << " ";
    }
    AES128_ECB_decrypt(input, ikey, output);

    msgHideEPC *msgOut = new msgHideEPC;
    msgOut->setName("clearEPC");

    EV << "\nResult: ";
    for (int i=0;i<12;i++) {
        EV << output[i] << " ";
        msgOut->setEPC96(i,output[i]);
    }
    send (msgOut, toReader);
}


void AuthenticationReader::noAuthentication(){
    send(new cMessage("NoAuth"),toReader);
}

void AuthenticationReader::requestXOR() {
    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("AuthRequest");
    msgOut->setRn16(iHandle); //handle
    msgOut->setMsg(0);
    msgOut->setSenRep(1);

    iXOR1 *msgXor = new iXOR1;
    EV <<"\n\tXOR request ";
    long Register1;

//  Register1 = rand(); //RNi
    Register1 = 0x1ba586777e45a0e7;
    RRN16 = Register1;
    Register1 = Register1 + XOR_On;         //RNi + On
    Register1 = Register1 ^ XOR_PSK;        //SRNi = (RNi+On) ⊕ PSK
    EV <<"\t SRNi :  \t\t "<< Register1;

    msgXor->setSrni(Register1);
//  duration = nbitIXOR / txRate;
    msgOut->encapsulate(msgXor);
//  sendDirect(msgOut, radioDelay, duration, host->gate("in"));

    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitIXOR);
    send(pktOut,toReader);
}

void AuthenticationReader::verifyXOR(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgXOR1In = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tXOR1 *msgIn = check_and_cast <tXOR1 *> (msgXOR1In->decapsulate());

    unsigned long Register1, Register2, n;
    int Bit1Counter;

    Register1 = RRN16;
    Register2 = XOR_PSK;
    n = Register1;
    Bit1Counter = 0;
    while(n) {
        Bit1Counter++;
        n &= n-1;
    }

    while (Bit1Counter >0) {
           Register1 = Register1 << 1; //RNi'
           Register2 = Register2 << 1; //PSK'
           Bit1Counter--;
       }

    Register1 = msgIn->getSorni() ^ Register1; //SORNi ⊕ RNi'
    EV << "\t\t\t\t SORNi ⊕ RNi': \t\t" << Register1;

    Register2 = Register2 + XOR_On; //PSK' + On
//  EV << "\n\t\t PSK' + On   : \t\t " << Register2;

    if (Register1 == Register2) {
        cPacket *pktOut = new cPacket;
        pktOut->setName("Authenticated");
        pktOut->setBitLength(1);
        send(pktOut,toReader);
        EV << "\n\t\t*** XOR Authenticated ***"
     <<endl;

    csiAuth = true;

//  hX = msgIn->get;
//  hY = ;
//  hZ = ;


    } else EV <<"\n*** WRONG ***";
     delete msgXOR1In;
     delete msgIn;
     //134 ////delete pktIn;
}

void AuthenticationReader::requestPRESENT() {
    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("Authenticate");
    msgOut->setRn16(iHandle); //handle
    msgOut->setMsg(0);
    msgOut->setSenRep(1);

    iPRESENT *msgPresent = new iPRESENT;
    long Register1;
    //42 bits iChallenge
    int state[8] ={0};
    int i;
    Register1 = pow(2,42)-1;
//    EV << "\n\t*** PRESENT80 AUTHENTICATION STARTS ***" << message->getOwner()->getFullName();

    //could also use
//    Register1 = rand() %Register1 ;
    Register1 = 0x1ba586777e45a0e7;

    EV   << "\n\t\tiChallenge:\t\t";
    // 8*6 = 48bits
    for (i=0;i<6;i++) {
        iChallenge[i] = state[i] = Register1 % 256 &0xFF;
        Register1 = Register1 / 256;
        EV << " " << state[i];
    }
    for (i=0; i<8; i++) {
        msgPresent->setIChallenge(i,state[i]);
    }
    msgOut->encapsulate(msgPresent);
    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitIPRESENT);
    send(pktOut,toReader);
}

void AuthenticationReader::verifyPRESENT(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgPresentIn = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tPRESENT *msgIn = check_and_cast <tPRESENT *> (msgPresentIn->decapsulate());

    static const int sBox4[] = {
            0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd, 0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};

    static const int invsBox4[] = {
            0x5,0xe,0xf,0x8,0xc,0x1,0x2,0xd,0xb,0x4,0x6,0x3,0x0,0x7,0x9,0xa};

    //  Input values
    int key[] = {
            0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b};

    volatile int state[] = {
            msgIn->getTResponse(0) &0xFF, msgIn->getTResponse(1) &0xFF,
            msgIn->getTResponse(2) &0xFF, msgIn->getTResponse(3) &0xFF,
            msgIn->getTResponse(4) &0xFF, msgIn->getTResponse(5) &0xFF,
            msgIn->getTResponse(6) &0xFF, msgIn->getTResponse(7) &0xFF};

    //  Counter
    int i = 0;
    //  pLayer variables
    int position = 0;
    int element_source = 0;
    int bit_source = 0;
    int element_destination = 0;
    int bit_destination = 0;
    int temp_pLayer[8];
    //  Key scheduling variables
    int round = 0;
    int save1;
    int save2;
    int subkey[32][8];
    //  ****************** Encryption **************************
    //  ****************** Key Scheduling **********************
    //  key precomputation
        for(i=2;i<=9;i++) {
            subkey[0][i-2] = key[i];
        }
        do {
            i=0;
            save1  = key[0];
            save2  = key[1];
            i = 0;
            do {
                key[i] = key[i+2];
                i++;
            }
            while(i<8);
            key[8] = save1;
            key[9] = save2;
            i = 0;
            save1 = key[0] & 7;
            do {
                key[i] = (key[i] >> 3 &0xFF) | (key[i+1] << 5 &0xFF);
                i++;
            }
            while(i<9);
            key[9] = (key[9] >> 3 &0xFF) | (save1 << 5 &0xFF);

            key[9] = sBox4[key[9]>>4]<<4 | (key[9] & 0xF);

            if((round+1) % 2 == 1)
                key[1] ^= 128;
            key[2] = ((((round+1)>>1) ^ (key[2] & 15)) | (key[2] & 240));

            for(i=2;i<=9;i++) {
                subkey[round+1][i-2] = key[i];
            }
            round++;
        }
        while(round<31);

    //  ****************** End Key Scheduling ******************
        do {
    //  ****************** addRoundkey *************************
            i=0;
            do {
                state[i] = (state[i] &0xFF)^ (subkey[round][i] &0xFF);
                temp_pLayer[i] = 0;
                i++;
            }
            while(i<=7);
    //  ****************** End addRoundkey *********************
    //  ****************** pLayer ******************************
            for(i=0;i<64;i++) {
                position = (4*i) % 63;                      //arthmetic calculation of the pLayer
                if(i == 63)                                 //Exception for bit 63
                    position = 63;
                element_source = i / 8;
                bit_source = i % 8;
                element_destination = position / 8;
                bit_destination = position % 8;
                temp_pLayer[element_destination] |= ((state[element_source]>>bit_source) & 0x1) << bit_destination;
            }
            for(i=0;i<=7;i++) {
                state[i] = temp_pLayer[i];
            }
    //  ****************** End pLayer **************************
    //  ****************** sBox ********************************
            i=0;
            do {
                state[i] = invsBox4[state[i]>>4]<<4 | invsBox4[state[i] & 0xF];
                i++;
            }
            while(i<=7);
    //  ****************** End sBox ****************************
            round--;
        }
        while(round>0);
    //  ****************** addRoundkey *************************
        i = 0;
        do { //final key XOR
            state[i] = state[i] ^ subkey[0][i];
            i++;
        }
        while(i<=7);

    //  ****************** End addRoundkey *********************
    //  ****************** End Encryption **********************

    EV << "\n\t\tEnd State :\t\t";
    for (i=0;i<6;i++){
        EV << " " << state[i];
    }

    int validation = 0;
    for (i=0;i<6;i++) {
            if (iChallenge[i] != state[i])
                validation = 1;
    }

    if (validation == 0) {
        EV << "\n\t*** PRESENT80 AUTHENTICATED ***\n\t\tPresent duration :\t" <<endl;
        csiAuth = true;
        cPacket *pktOut = new cPacket;
        pktOut->setName("Authenticated");
        pktOut->setBitLength(1);
        send(pktOut,toReader);

    }
    else {
            EV << "NON VALID";
        }
    delete msgPresentIn;
    //1505 //1606 ////delete msgIn;
}

void AuthenticationReader::requestGPSCCR() {
    EV <<"\n\t*** CryptoGPS AUTHENTICATION STARTS\n";
    iGPS1a *msgGps = new iGPS1a ("GPSCCR");

    msgGps->setAuthMethod(0);
    msgGps->setStep(0);
    msgGps->setFlags(0);
 //   return msgGps;

    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("Authenticate");
    msgOut->setRn16(iHandle); //handle
    msgOut->setSenRep(1);
    msgOut->setMsg(0);
    msgOut->encapsulate(msgGps);

    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitICRYPTO1a);
    send(pktOut,toReader);
//    duration = nbitICRYPTO1a / txRate;/
//    sendDirect(msgOut, radioDelay, duration, host->gate("in"));
}

void AuthenticationReader::verify1GPSCCR(cMessage *msg) {
    EV <<"\n\nverify1:\t"<<verify1;
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgGps1In = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tGPS1a *msgIn = check_and_cast <tGPS1a *> (msgGps1In->decapsulate());

    iGPS1b *msgGps = new iGPS1b ("GPSCCR");

    int c[] = { 0x2D, 0xF0, 0xF5, 0xB4, 0xF2};

    // Tag should check on X length (δ),
    // sending challenge 'c'
    if (msgIn->getLenghtx() == 392) {
        EV <<"\nx: ";
        for (int i=0; i<5;i++) {
            msgGps->setIChallenge(i,c[i]);
            EV << c[i] << " ";
        }
    }
//    return msgOut;
    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("Authenticate");
    msgOut->setRn16(iHandle); //handle
    msgOut->setSenRep(1);
    msgOut->setMsg(1);
    msgOut->encapsulate(msgGps);
    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitICRYPTO1a);
    send(pktOut,toReader);

//    duration = nbitICRYPTO1a / txRate;
//    sendDirect(msgOut, radioDelay, duration, host->gate("in"));
    //1505 ////delete msgGps1In;
    //1505 //1606 ////delete msgIn;
}

void AuthenticationReader::verify2GPSCCR(cMessage *msg) {
    EV<< "\n\nverify2:\t"<<verify1;
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgGps2In = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tGPS1b *msgIn = check_and_cast <tGPS1b *> (msgGps2In->decapsulate());

    /* for c & z, δ = ω = 5 bytes (40bits)
    * x = 49 bytes (392bits) for the commitment X.
    * X = EC2OSP([r]P, uncompressed)
    * coupon r, where ρ = σ + ω' + θ = 192 + 40 + 80 = 312bits
    */

    int y[]={ 0x05, 0xE8, 0xB1, 0xE1, 0x12, 0x1B, 0x08, 0xFB,
              0x9A, 0x0F, 0x67, 0x2E, 0xD9, 0xCE, 0x48, 0x04,
              0x4B, 0xD6, 0x18, 0x32, 0x42, 0x08, 0x7C, 0xAD,
              0xDD, 0xA3, 0x92, 0xF2, 0xCA, 0x1F, 0x36, 0xFD,
              0xD9, 0x42, 0x48, 0xE8, 0x48, 0x5D, 0x5E};

    int validy=1;
    for (int i=0;i<tailleY;i++){
    if (msgIn->getY(i) != y[i]) validy=0;
    }

    if (validy == 0)
        EV<< "CryptoGPS CCR invalid\n";
    else {
        EV<< "\n\t*** CryptoGPS CCR AUTHENTICATED ***";
        csiAuth = true;
        cPacket *pktOut = new cPacket;
        pktOut->setName("Authenticated");
        pktOut->setBitLength(1);
        send(pktOut,toReader);
    }
    //1505 ////delete msgGps2In;
    //1505 //1606 ////delete msgIn;
}

void AuthenticationReader::requestAES128ECB() {
    iAES1 *msgAes = new iAES1;

    int eChall[10] = {0x96, 0x56, 0x44, 0x02, 0x37, 0x57, 0x96, 0xC6, 0x96, 0x64};
    int i;
    /*{
            0x6b,0xc1,0xbe,0xe2,0x2e,
            0x40,0x9f,0x96,0xe9,0x3d};
*/

   // 8*10 = 80bits
    for (i=0;i<10;i++) {
        iChallenge[i] = eChall[i];
        EV << "  " << eChall[i];
    }

    for (i=0; i<10; i++){
        msgAes->setIChallenge(i,eChall[i]);
    }
    msgAes->setAuthMethod(0 &0b00);
    msgAes->setCustomData(0 &0b0);
    msgAes->setRfu(0 &0b00000);
    msgAes->setKeyId(0 &0x00);
    //return msgOut;
    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("Authenticate");
    msgOut->setRn16(iHandle); //handle
    msgOut->setMsg(0);
    msgOut->setSenRep(1);
    msgOut->encapsulate(msgAes);
    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitIAES1);
    send(pktOut,toReader);
//    duration = nbitIAES1 / txRate;
//    sendDirect(msgOut, radioDelay, duration, host->gate("in"));
}



void AuthenticationReader::verifyAES128ECB(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgAES1In = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tAES1 *msgIn = check_and_cast <tAES1 *> (msgAES1In->decapsulate());

    int i, validation;

    int input[] = {
            msgIn->getTResponse(0), msgIn->getTResponse(1),
            msgIn->getTResponse(2), msgIn->getTResponse(3),
            msgIn->getTResponse(4), msgIn->getTResponse(5),
            msgIn->getTResponse(6), msgIn->getTResponse(7),
            msgIn->getTResponse(8), msgIn->getTResponse(9),
            msgIn->getTResponse(10), msgIn->getTResponse(11),
            msgIn->getTResponse(12), msgIn->getTResponse(13),
            msgIn->getTResponse(14), msgIn->getTResponse(15)};

    //128bit output
    int output[16] = {0};

    AES128_ECB_decrypt(input, ikey, output);

    EV << "\n\t\tReply :\t\t";

    for (i=0;i<10;i++) EV << "  " << output[i];

    validation = 0;
    for (i=0;i<6;i++) {
        if (iChallenge[i] != output[i]) validation = 1;
    }

    if (validation == 0) {
        EV << "\n\t*** AES128 ECB AUTHENTICATED ***";
        csiAuth = true;
        cPacket *pktOut = new cPacket;
        pktOut->setName("Authenticated");
        pktOut->setBitLength(1);
        send(pktOut,toReader);
    }
    else {
        EV << "NON VALID";
    }
    delete msgAES1In;
    delete msgIn;
    //1505 ////delete pktIn;
}
//////CBC//////////
void AuthenticationReader::requestAES128CBC() {
    iAES2 *msgAes = new iAES2;
    EV << "\n\t*** AES128-CBC AUTHENTICATION STARTS ***\n\t\t Challenge :\t\t";
    int eChall[16] = {0};
    int i;

    // 8*10 = 80bits
    for (i=0;i<10;i++) {
//        iChallenge[i] = eChall[i] = rand() % 256 -1;
        iChallenge[i] = eChall[i] = intrand(256);
        EV << "  " << eChall[i];
    }

    for (i=0; i<16 ;i++) {
        msgAes->setIChallenge(i,eChall[i]);
    }
//  return msgOut;

    iMsgAuthenticate *msgOut = new iMsgAuthenticate ("Authenticate");
    msgOut->setRn16(iHandle); //handle
    msgOut->setMsg(0);
    msgOut->setSenRep(1);
    msgOut->encapsulate(msgAes);
    cPacket *pktOut = new cPacket;
    pktOut->setName("AuthRequest");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitIAES2);
    send(pktOut,toReader);
//    duration = nbitIAES2 / txRate;
//    sendDirect(msgOut, radioDelay, duration, host->gate("in"));


}

/////////
void AuthenticationReader::verifyAES128CBC(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    tMsgAuthenticate *msgAES2In = check_and_cast <tMsgAuthenticate *> (pktIn->decapsulate());
    tAES2 *msgIn = check_and_cast <tAES2 *> (msgAES2In->decapsulate());

    int input[] = {
            msgIn->getTResponse(0), msgIn->getTResponse(1), msgIn->getTResponse(2), msgIn->getTResponse(3),
            msgIn->getTResponse(4), msgIn->getTResponse(5), msgIn->getTResponse(6), msgIn->getTResponse(7),
            msgIn->getTResponse(8), msgIn->getTResponse(9), msgIn->getTResponse(10), msgIn->getTResponse(11),
            msgIn->getTResponse(12), msgIn->getTResponse(13), msgIn->getTResponse(14), msgIn->getTResponse(15)};

    //128bit output
    int output[16] = {0};
    int iv[]  = {
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f};

    EV << "\n\t\tReply :\t\t";
    AES128_CBC_decrypt_buffer(output, input, CBC_BLOCKSIZE, ikey, iv);
    for (int i =0; i<10; i++) EV << output[i] << " ";

    int validation = 0;
    for (int i=0;i<6;i++) {
        if (iChallenge[i] != output[i])
            validation = 1;
    }

    if (validation == 0) {
        EV << "\n\t*** AES128 CBC AUTHENTICATED ***";
        csiAuth = true;
        cPacket *pktOut = new cPacket;
        pktOut->setName("Authenticated");
        pktOut->setBitLength(1);
        send(pktOut,toReader);
    }
    else {
        EV << "NON VALID";
    }

    //1505 ////delete msgAES2In;
    //1505 //1606 ////delete msgIn;
//    //1505 ////delete pktIn;
    //1505 //1606 ////delete msg;
}

// AES128-ECB Decrypt
void AuthenticationReader::AES128_ECB_decrypt(int* input, const int* ikey, int *output)
{
  // Copy input to output, and work in-memory on output
  BlockCopy(output, input);
  istate = (state_t*)output;

  // The iKeyExpansion routine must be called before encryption.
  iKey = ikey;
  KeyExpansion();

  InvCipher();
}

void AuthenticationReader::BlockCopy(int* output, int* input) {
    int i;
    for (i=0;i<KEYLEN;++i) {
        output[i] = input[i];
    }
}

// This function produces Nb(Nr+1) round keys. The round keys are used in each round to decrypt the states.
void AuthenticationReader::KeyExpansion(void)
{
    int i, j, k, t0, t1, t2, t3;
    int tempa[4]; // Used for the column/row operations

    // The round constant word array, Rcon[i], contains the values given by
    // x to th e power (i-1) being powers of x (x is denoted as {02}) in the field GF(2^8)
    // Note that i starts at 1, not 0).
    int iRcon[] = {
            0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a,
            0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39,
            0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a,
            0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8,
            0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef,
            0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc,
            0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b,
            0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3,
            0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94,
            0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20,
            0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35,
            0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f,
            0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04,
            0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63,
            0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd,
            0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb  };


    // The first round key is the key itself.
    for(i = 0; i < Nk; ++i) {
        t0 = (i*4) + 0;
        t1 = (i*4) + 1;
        t2 = (i*4) + 2;
        t3 = (i*4) + 3;

        iRoundKey[t0] = iKey[t0];
        iRoundKey[t1] = iKey[t1];
        iRoundKey[t2] = iKey[t2];
        iRoundKey[t3] = iKey[t3];
  }

  // All other round keys are found from the previous round keys.
  for(; (i < (Nb * (Nr + 1))); ++i) {
    for(j = 0; j < 4; ++j) {
      tempa[j]=iRoundKey[(i-1) * 4 + j];
    }
    if (i % Nk == 0) {
      // This function rotates the 4 bytes in a word to the left once.
      // [a0,a1,a2,a3] becomes [a1,a2,a3,a0]

      // Function RotWord()
      {
        k = tempa[0];
        tempa[0] = tempa[1];
        tempa[1] = tempa[2];
        tempa[2] = tempa[3];
        tempa[3] = k;
      }

      // SubWord() is a function that takes a four-byte input word and
      // applies the S-box to each of the four bytes to produce an output word.

      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }

      tempa[0] =  tempa[0] ^ iRcon[i/Nk];
    }
    else if (Nk > 6 && i % Nk == 4) {
      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }
    }
    iRoundKey[i * 4 + 0] = iRoundKey[(i - Nk) * 4 + 0] ^ tempa[0];
    iRoundKey[i * 4 + 1] = iRoundKey[(i - Nk) * 4 + 1] ^ tempa[1];
    iRoundKey[i * 4 + 2] = iRoundKey[(i - Nk) * 4 + 2] ^ tempa[2];
    iRoundKey[i * 4 + 3] = iRoundKey[(i - Nk) * 4 + 3] ^ tempa[3];
  }
}

void AuthenticationReader::InvCipher(void)
{
  int round=0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(Nr);

  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for(round=Nr-1;round>0;round--)
  {
    InvShiftRows();
    InvSubBytes();
    AddRoundKey(round);
    InvMixColumns();
  }

  // The last round is given below.
  // The MixColumns function is not here in the last round.
  InvShiftRows();
  InvSubBytes();
  AddRoundKey(0);
}

// This function adds the round key to state.
// The round key is added to the state by an XOR function.
void AuthenticationReader::AddRoundKey(int round) {
  int i,j;
  for(i=0;i<4;++i) {
    for(j = 0; j < 4; ++j) {
      (*istate)[i][j] ^= iRoundKey[round * Nb * 4 + i * Nb + j];
    }
  }
}

 // MixColumns function mixes the columns of the state matrix.
 // The method used to multiply may be difficult to understand for the inexperienced.
 // Please use the references to gain more information.
void AuthenticationReader::InvMixColumns(void)
 {
   int i;
   int a,b,c,d;
   for(i=0;i<4;++i)
   {
     a = (*istate)[i][0];
     b = (*istate)[i][1];
     c = (*istate)[i][2];
     d = (*istate)[i][3];

     (*istate)[i][0] = Multiply(a, 0x0e) ^ Multiply(b, 0x0b) ^ Multiply(c, 0x0d) ^ Multiply(d, 0x09);
     (*istate)[i][1] = Multiply(a, 0x09) ^ Multiply(b, 0x0e) ^ Multiply(c, 0x0b) ^ Multiply(d, 0x0d);
     (*istate)[i][2] = Multiply(a, 0x0d) ^ Multiply(b, 0x09) ^ Multiply(c, 0x0e) ^ Multiply(d, 0x0b);
     (*istate)[i][3] = Multiply(a, 0x0b) ^ Multiply(b, 0x0d) ^ Multiply(c, 0x09) ^ Multiply(d, 0x0e);
   }
 }
 // The SubBytes Function Substitutes the values in the
 // state matrix with values in an S-box.
 void AuthenticationReader::InvSubBytes(void)
 {
   int i,j;
   for(i=0;i<4;++i)
   {
     for(j=0;j<4;++j)
     {
       (*istate)[j][i] = getSBoxInvert((*istate)[j][i]);
     }
   }
 }

void AuthenticationReader::InvShiftRows(void)
 {
   int temp;

   // Rotate first row 1 columns to right
   temp=(*istate)[3][1];
   (*istate)[3][1]=(*istate)[2][1];
   (*istate)[2][1]=(*istate)[1][1];
   (*istate)[1][1]=(*istate)[0][1];
   (*istate)[0][1]=temp;

   // Rotate second row 2 columns to right
   temp=(*istate)[0][2];
   (*istate)[0][2]=(*istate)[2][2];
   (*istate)[2][2]=temp;

   temp=(*istate)[1][2];
   (*istate)[1][2]=(*istate)[3][2];
   (*istate)[3][2]=temp;

   // Rotate third row 3 columns to right
   temp=(*istate)[0][3];
   (*istate)[0][3]=(*istate)[1][3];
   (*istate)[1][3]=(*istate)[2][3];
   (*istate)[2][3]=(*istate)[3][3];
   (*istate)[3][3]=temp;
 }

int AuthenticationReader::getSBoxValue(int num) {
    // The lookup-tables are marked const so they can be placed in read-only storage instead of RAM
      // The numbers below can be computed dynamically trading ROM for RAM -
      // This can be useful in (embedded) bootloader applications, where ROM is often limited.
    int isbox[] =   {
            //0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F
            0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
            0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
            0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
            0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
            0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
            0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
            0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
            0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
            0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
            0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
            0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
            0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
            0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
            0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
            0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
            0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 };
  return isbox[num];
}

int AuthenticationReader::getSBoxInvert(int num) {

    int irsbox[256] =
    { 0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
      0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
      0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
      0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
      0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
      0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
      0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
      0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
      0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
      0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
      0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
      0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
      0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
      0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
      0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
      0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d };

  return irsbox[num];
}

int AuthenticationReader::xtime(int x) {
 return ((x<<1) ^ (((x>>7) & 1) * 0x1b));
}

int AuthenticationReader::Multiply(int x, int y) {
  return (((y & 1) * x &0xFF) ^
       ((y>>1 & 1) * xtime(x) &0xFF) ^
       ((y>>2 & 1) * xtime(xtime(x)) &0xFF) ^
       ((y>>3 & 1) * xtime(xtime(xtime(x))) &0xFF) ^
       ((y>>4 & 1) * xtime(xtime(xtime(xtime(x))))&0xFF));
  }

void AuthenticationReader::AES128_CBC_decrypt_buffer(int* output, int* input, int length, const int* key, const int* iv) {
  int i;
  int remainders = length % KEYLEN; /* Remaining bytes in the last non-full block */

  BlockCopy(output, input);
  istate = (state_t*)output;

  // Skip the key expansion if key is passed as 0
  if(0 != key) {
    iKey = ikey;
    KeyExpansion();
  }

  // If iv is passed as 0, we continue to encrypt without re-setting the Iv
  if(iv != 0) {
    iIv = (int*)iv;
  }

  for(i = 0; i < length; i += KEYLEN) {
    BlockCopy(output, input);
    istate = (state_t*)output;
    InvCipher();
    XorWithIv(output);
    iIv = input;
    input += KEYLEN;
    output += KEYLEN;
  }

  if(remainders) {
    BlockCopy(output, input);
    memset(output+remainders, 0, KEYLEN - remainders); // add 0-padding
    istate = (state_t*)output;
    InvCipher();
  }
}

void AuthenticationReader::XorWithIv(int* buf) {
  int i;
  for(i = 0; i < KEYLEN; ++i) {
    buf[i] ^= iIv[i];
  }
}

int AuthenticationReader::rXPC(char *sig) {
    //server[
    int res = 0;
    int i=7;
    EV << "\n";
    while (sig[i] != ']') {
        res = ((int) sig[i]-48) + (res*10);
        i++;
    }
    return res;
}


