//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_AUTHENTICATIONREADER_H_
#define __LOCPRIV_AUTHENTICATIONREADER_H_

#include <omnetpp.h>
#include "AllMsg_m.h"
#include "command.h"
#include "sha1.h"
//#include "memory.h" // for memset and memcpy

//typedef unsigned char UINT_8 ;



/**
 * TODO - Generated class
 */
class AuthenticationReader : public cSimpleModule
{
protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);

    int csiId;
    bool verify1;

    cGate       *frReader;
    cGate       *toReader;
    cGate       *frAuth;
    cGate       *toAuth;

    void        decryptEPC(cMessage *msg);
    void        noAuthentication();
    void        requestXOR();
    void        verifyXOR(cMessage *msg);
    void        requestPRESENT();
    void        verifyPRESENT(cMessage *msg);
    void        requestGPSCCR();
    void        verify1GPSCCR(cMessage *msg);
    void        verify2GPSCCR(cMessage *msg);
    void        requestAES128ECB();
    void        verifyAES128ECB(cMessage *msg);
    void        requestAES128CBC();
    void        verifyAES128CBC(cMessage *msg);
    void        AES128_ECB_decrypt(int* input, const int* ikey, int *output);
    void        BlockCopy(int* output, int* input);
    void        KeyExpansion(void);
    void        InvCipher(void);
    void        InvMixColumns(void);
    void        InvSubBytes(void);
    void        InvShiftRows(void);
    int         getSBoxValue(int num);
    int         getSBoxInvert(int num);
    int         xtime(int x);
    void        AddRoundKey(int round);
    int         Multiply(int x, int y);
    void        AES128_CBC_decrypt_buffer(int* output, int* input, int length, const int* key, const int* iv);
    void        XorWithIv(int* buf);
    int         rXPC(char *sig);

    state_t* istate;
    int iHandle;
    unsigned long RRN16;
    const int* iKey;     // The Key input to the AES Program
    int iRoundKey[176];     // The array that stores the round keys.
    int* iIv;
    bool csiAuth;
    int iChallenge[10]; //PRESENT80 (6), AES128 (10)

private:
    void        HMAC_SHA1(BYTE text[12], int text_len, BYTE *key, int key_len, BYTE *digest);
    void        dispHEX                     (BYTE *msg, int msgLength);
    
    void        Update(BYTE *data, UINT_32 len); // Update the hash value
    void        Final();     // Finalize hash and report
    void        GetHash(BYTE *puDest);     // Private SHA-1 transformation
    void        Transform(UINT_32 *state, BYTE *buffer);
    virtual void Reset();

    BYTE      m_ipad[64];
    BYTE      m_opad[64];
//  BYTE      digest[20] ;

    BYTE      m_buffer[64];
    BYTE      m_digest[20];

    BYTE      AppendBuf1[64];
    BYTE      AppendBuf2[64];
    BYTE      SHA1_Key[64];
    BYTE      szReport[64];
    BYTE      m_workspace[64];

    UINT_32     m_state[5];
    UINT_32     m_count[2];
//  UINT_32     __reserved1[1];
//  UINT_32     __reserved2[3];

    enum {
        SHA1_DIGEST_LENGTH  = 20,
        SHA1_BLOCK_SIZE     = 64,
        //             HMAC_BUF_LEN        = 4096
        HMAC_BUF_LEN        = 64
    };

    typedef union {
        BYTE  c[64];
        UINT_32 l[16];
    } SHA1_WORKSPACE_BLOCK;

    SHA1_WORKSPACE_BLOCK *m_block; // SHA1 pointer to the BYTE array above
    int hmSHA1[20];

};

#endif
