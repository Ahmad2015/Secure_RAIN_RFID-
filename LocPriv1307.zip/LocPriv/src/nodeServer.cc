//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 


#include "nodeServer.h"
//#include "authenticationTag.h"

// -> to do list
//  -to add authentication to server -- 24/01 meeting
//  -review authentication to be used with responseBuffer
//  - check R updated info when found a tag

Define_Module(NodeServer);

void NodeServer::initialize()
{
    // TODO - Generated method body
    EV << "initialize server"<< endl;

    numReaders          = par ("numReaders");
    numTags             = par ("numTags");
    cryptoSuite         = par ("CryptoSuite");
    propagationSpeed    = par ("propagationSpeed");
    preambleDuration    = par ("preambleDuration");
    bitrate             = par ("bitrate");
    headerBitLength     = par ("headerBitLength");
    Q                   = par ("rQ");
    toLocate            = gate("toLocate");
    frLocate            = gate("frLocate");
    toAuth              = gate("toAuth");
    frAuth              = gate("frAuth");
    constraintAreaMaxX  = par("constraintAreaMaxX");
    constraintAreaMaxY  = par("constraintAreaMaxY");;
    maxCoverage         = sqrt((constraintAreaMaxX*constraintAreaMaxX)+(constraintAreaMaxY*constraintAreaMaxY));


    for (int i=0;i<numReaders;i++) {
        endReaderTime[i] = simTime();
        startReaderTime[i] = simTime();
        toReader[i] = nullptr;
        toReader[i] = gate("toReader",i);
    }

    EV<<"\n\ngate:\t"<< gate("toReader",0)<<"\ntoReader[0]" << toReader[0]<<"\t" << toReader[1] << "\t" << toReader[2] << "\t" << toReader[3];

//  EV<< "radioModule Name :"<< radioModule->getFullName()<<endl;
//  EV << "radio transmission State: "<< radio->getTransmissionState()<<endl;
//  radio->setRadioMode(fullDuplex ? inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER : inet::physicallayer::IRadio::RADIO_MODE_TRANSMITTER);
//    scheduleAt(simTime(), new cMessage);
//  toReader[0] = nullptr;
//  toReader[0] = gate("toReader[0]");
    startOverallTime        = simTime();
    endOverallTime          = simTime();
    startLocateTime         = simTime();
    endLocateTime           = simTime();
    overallAuthTime         = 0;
    overallDiscoveryTime    = 0;

    for (int i=0; i< 30; i++) {
        for (int j = 0; j < 101 ;j++) {
            ReaderDetail[i].toa[j] = 0;
         //   locDetails[i][j].tempsRef = 0;
        }
        ReaderDetail[i].Q           = 0;
        ReaderDetail[i].totCol      = 0;
        ReaderDetail[i].totReq      = 0;
        ReaderDetail[i].csi_ID      = cryptoSuite;
        ReaderDetail[i].WoutAuth    = 0;
        ReaderDetail[i].WithAuth    = 0;
        ReaderDetail[i].activeTags  = 0;
    }
    overheadRTR = (2*preambleDuration) + ((headerBitLength+nbitReqRN)/bitrate) + ((headerBitLength+nbitReqRNReply)/bitrate);
    overheadRT_ACK      = preambleDuration + (( headerBitLength + nbitACK        ) /bitrate);
    overheadTR_EPC      = preambleDuration + (( headerBitLength + nbitACKReply   ) /bitrate);
    overheadRT_ReqRN    = preambleDuration + (( headerBitLength + nbitReqRN      ) /bitrate);
    overheadTR_Handle   = preambleDuration + (( headerBitLength + nbitReqRNReply ) /bitrate);
    overheadRT_AuthAES1 = preambleDuration + (( headerBitLength + nbitIAES1      ) /bitrate);
    overheadTR_RespAES1 = preambleDuration + (( headerBitLength + nbitTAES1      ) /bitrate);
//    overheadXchange1    = overheadRT_ACK        + overheadTR_EPC;
//    overheadXchange2    = overheadRT_ReqRN      + overheadTR_Handle;
//    overheadXchange3    = overheadRT_AuthAES1   + overheadTR_RespAES1;
}

void NodeServer::finish() {
    endOverallTime = simTime();

    EV <<"SERVER:\t"<< ReaderDetail[0].csi_ID
       <<"\tQ:\t"                      << ReaderDetail[0].Q
       <<"\t#Tags: "                   << numTags
       <<"\nOverDiscTime:\t"           << overallDiscoveryTime
       <<"\tOverAuthTime:\t"           << overallTime - overallDiscoveryTime
       <<"\tOverReaderTime:\t"         << overallTime
       <<"\tEndReaderInServerTime:\t"  << startLocateTime
       <<"\tTotTimeToLoc:\t"           << endLocateTime - startLocateTime
       <<"\tOverDuration:\t"           << endOverallTime - startOverallTime;

//    for (int j=0;j<numTags;j++){
//1        for (int k=0;k<numReaders;k++) {
//1            EV <<"\ndistanceFrReader#"<<k<<": "<< distanceTag[k][j];
//1        }
//        EV <<"\nServer finish -> Tag#"<< j <<"\t("
//                << tagsCoordinate[j].x <<",\t"
//                << tagsCoordinate[j].y <<",\t"
//                << tagsCoordinate[j].z <<")";
//    }
    for (int i=0;i<numReaders;i++){
           EV <<"\nReader#"<<i<<"\ttotReq: "<< ReaderDetail[i].totReq
                   <<"\tQ: " << ReaderDetail[i].Q
                   <<"\tact:\t" << ReaderDetail[i].activeTags
         << "\t#qRep: " << ReaderDetail[i].totQRep
                << "\t#qAdj: " << ReaderDetail[i].totQAdj
                << "\t#Req: " << ReaderDetail[i].totReq
                <<"\ttotCol: " << ReaderDetail[i].totCol
                <<"\twoAuth: " << (simtime_t) ReaderDetail[i].WoutAuth
                <<"\twiAuth: " << (simtime_t) ReaderDetail[i].WithAuth;
  //              <<"\t" <<numTags;

           for (int j=0;j<numTags;j++) {
               EV <<"\tToA"<<j<<": " << ReaderDetail[i].toa[j];
           }

    }
        for (int seq=0; seq<(numTags*numReaders*4); seq++) {
            if (seq%4 == 0) { EV <<"\n";}
            for (int t=0; t<numTags; t++) {
                for (int r=0; r<numReaders; r++) {
                    if (locUpdateList[t][r][seq] > 0 ) {
                        EV <<" #"<<seq<<" T"<<t<<" R"<< r <<" "<< locUpdateList[t][r][seq]<<endl;
                    }
                }
            }
        }
}

void NodeServer::handleMessage(cMessage *msg)
{
//    if (msg->isSelfMessage()) {
    if (strcmp(msg->getName(),"readerInitPosition") == 0) {
        rMsgPosition *msgIn = check_and_cast <rMsgPosition *>(msg);
        //check current reader for each message
        currReader = msgIn->getReaderId();

        coordReader [currReader].x  = msgIn->getR_X();
        coordReader [currReader].y  = msgIn->getR_Y();
        EV <<"current reader: " << currReader
                <<"(" << coordReader[currReader].x <<", "<<coordReader[currReader].y<<", "<<coordReader[currReader].z<<")";

        distR1R2 =  pow(pow(coordReader[0].x-coordReader[1].x,2) + pow(coordReader[0].y-coordReader[1].y,2),0.5);
        distR1R3 =  pow(pow(coordReader[0].x-coordReader[2].x,2) + pow(coordReader[0].y-coordReader[2].y,2),0.5);
        distR2R3 =  pow(pow(coordReader[1].x-coordReader[2].x,2) + pow(coordReader[1].y-coordReader[2].y,2),0.5);

        if (currReader == activeReaderTX) {
            cPacket *pktOut = new cPacket;
            pktOut->setName("startQuery");
            pktOut->setBitLength(4);
            send(pktOut,gate("toReader",activeReaderTX)); //R0
        }
        delete msgIn;
    }
    else if (strcmp(msg->getName(),"timeRefUpdate") == 0) {
        EV <<"\n\n\n\n"
           << preambleDuration << "/"<<headerBitLength << "/" <<nbitACK << "/" <<bitrate
           <<"\n"<< preambleDuration+((headerBitLength+nbitACK)/bitrate)
           << preambleDuration << "/"<<headerBitLength << "/" <<nbitACKReply << "/" <<bitrate
           <<"\n"<< preambleDuration+((headerBitLength+nbitACKReply)/bitrate);

        msgLocTime *timeUpdateIn = check_and_cast<msgLocTime *> (msg);
        currReader  = timeUpdateIn->getReaderId();
        locTagId    = timeUpdateIn->getTagId(); //to be used for the rest of the calculation

/*        locTimeUpdate[seqLoc] = (simtime_t) timeUpdateIn->getLocTime();
        EV <<"timeUpdateIn: "<<activeReaderTX<<"-"
           << locTagId <<"-" <<activeReaderTX <<": "
           << (simtime_t) timeUpdateIn->getLocTime() <<endl;
  */
        //start dgn seqLoc = 0
        locUpdateList[locTagId][currReader][seqLoc] = (simtime_t) timeUpdateIn->getLocTime();

        EV <<"\nLocUpdateList: T"<< locTagId<< "/ R"<< timeUpdateIn->getReaderId() <<"/ #"
                    << seqLoc<< "/ " << (simtime_t) timeUpdateIn->getLocTime()<<endl;
        //seqLoc = 1
        seqLoc++;
        delete timeUpdateIn;

    }
    else if (strcmp(msg->getName(),"timeUpdate") == 0) {
        locReaderCounter++;
        msgLocTime *timeUpdateIn    = check_and_cast <msgLocTime *> (msg);
        currReader                  = timeUpdateIn->getReaderId();
        tmpOverheadType             = timeUpdateIn->getTypeOverhead();
        //locTagId                    = timeUpdateIn->getTagId();

        //register Tn in time update for each sequence

        locUpdateList[locTagId][currReader][seqLoc] = (simtime_t) timeUpdateIn->getLocTime();

        EV << "\nupdated in LocUpdateList:[" << locTagId << "][" << timeUpdateIn->getReaderId() << "][" << seqLoc
           << "] = " << locUpdateList[locTagId][currReader][seqLoc]
           << " "                   << timeUpdateIn->getTypeOverhead()
           << "\ncurrent Reader: "                << currReader
           << "\nactive Reader: "                << activeReaderTX
           << "\noverH "            << tmpOverheadType
           <<"\nTo" << locUpdateList[locTagId][currReader][seqLoc-1]
           <<"\nT1" << locUpdateList[locTagId][currReader][seqLoc];

        // to calculate the the time&distance reference
        if (currReader == activeReaderTX) {
            if (seqLoc > 0) {
                diffTime1 = (timeUpdateIn->getLocTime() - locUpdateList[locTagId][currReader][seqLoc-1]);
                EV <<"\nduration: "<< diffTime1;

                //T1:EPC, T2:Handle, T3:Auth
                if (tmpOverheadType == overhEPC) {
                    propRefTime = (diffTime1 - overheadRT_ACK - overheadTR_EPC)/2;

                    //clearEPC
                    msgHideEPC *pktOut = new msgHideEPC("");
                    pktOut->setRN16(timeUpdateIn->getRN16());
                    for (int i=0;i<timeUpdateIn->getHideEPC128ArraySize();i++) {
                        pktOut->setHideEPC128(i,timeUpdateIn->getHideEPC128(i));
                    }
                    send(pktOut,toAuth);

                }
                else if (tmpOverheadType == overhHandle) {
                    propRefTime = (diffTime1 - overheadRT_ReqRN - overheadTR_Handle)/2;
                }
                else if (tmpOverheadType == overhResAES1) {
                    propRefTime = (diffTime1 - overheadRT_AuthAES1 - overheadTR_RespAES1)/2;
                }
                else {
                    EV << "\n666a :" << tmpOverheadType;
                }
            }
            distRefRT = SIMTIME_DBL(propRefTime)*propagationSpeed;
        }

        //send to locate
        if (locReaderCounter == 3) {
            msgLocate *pktOut = new msgLocate("locate");
            pktOut->setReaderId(currReader);
            pktOut->setTagId(locTagId);

            for (int r=0; r <numReaders; r++) {
                if (r == activeReaderTX) {
                    pktOut->setDistanceRT(r,distRefRT);
                }
                else if (r != activeReaderTX) {
                    diffTime1 = (locUpdateList[locTagId][r][seqLoc] - locUpdateList[locTagId][activeReaderTX][seqLoc-1]);

                    if (timeUpdateIn->getTypeOverhead() == overhEPC) {
                        propTime1 = (diffTime1 - overheadRT_ACK - overheadTR_EPC);
                    } else if (timeUpdateIn->getTypeOverhead() == overhHandle) {
                        propTime1 = (diffTime1 - overheadRT_ReqRN - overheadTR_Handle);
                    } else if (timeUpdateIn->getTypeOverhead() == overhResAES1) {
                        propTime1 = (diffTime1 - overheadRT_AuthAES1 - overheadTR_RespAES1);
                    } else EV << "\n666b";

                    if (propTime1 > propRefTime) {
                        propTime2 = propTime1 - propRefTime;
                    }
                    else {
                        propTime2 = propRefTime - propTime1;
                    }

                    distTRprime = SIMTIME_DBL(propTime2)*propagationSpeed;
                    pktOut->setDistanceRT(r,distTRprime);
                    EV << "\nT1-T0: "                 << diffTime1
                       << "\nACK: "                 << overheadRT_ACK
                       << "\nEPC: "                 << overheadTR_EPC
                       <<"\nTime Reference: "       << propRefTime
                       <<"\ntime taken: "           << propTime2
                       <<"\nR" << r << " to T = "   << distTRprime << endl;
                }
                pktOut->setX(r,coordReader[r].x); pktOut->setY(r, coordReader[r].y);pktOut->setZ(r,coordReader[r].z);
            }
            send (pktOut, "toLocate");
            locReaderCounter = 0;
            seqLoc++;


            if ((activeReaderTX < (numReaders) ) && (timeUpdateIn->getTypeOverhead() == overhResAES1)) {
    //2            activeReaderTX++;
    //          send(new cPacket("nextReader"), gate("toReader",activeReaderTX));
    //            send(new cPacket("startQuery"), gate("toReader",activeReaderTX));
                send(new cPacket("QueryTimeout"), gate("toReader",activeReaderTX));

                //msgLocate *pktOut = new msgLocate;
                //pktOut->setName("locate");
                //pktOut->setReaderId(currReader);
                //pktOut->setTagId(h);
            }
        }
        delete timeUpdateIn;
    }

    else if (strcmp(msg->getName(),"done!!!") == 0) {
        //reader found 1 more tag
        cPacket *pktIn = check_and_cast <cPacket *> (msg);
        iMsgManager *msgIn = check_and_cast <iMsgManager *> (pktIn->decapsulate());
        currReader = activeReaderTX;
        currDist = msgIn->getJarak();
        currWiAuth = (simtime_t) msgIn->getWiAuth();
        currWoAuth = (simtime_t) msgIn->getWoAuth();
        currToA[currReader] = msgIn->getToA();

        delete msgIn;
        delete pktIn;
    }
    else if (strcmp(msg->getName(),"clearEPC") == 0) {
        msgHideEPC *msgIn = check_and_cast <msgHideEPC *> (msg);
        h = (16*msgIn->getEPC96(10)) + msgIn->getEPC96(11);
        EV << "\n\n\nhostID:\t"<< h <<" at " <<recvTRefLocMsg;

        //register time reference to the server;
//        int cR = msgIn->getReaderId();
        int cT =(16*msgIn->getEPC96(10)) + msgIn->getEPC96(11);
        tagEPC[cT] = (16*msgIn->getEPC96(10)) + msgIn->getEPC96(11);

//3        locTmps[cR][cT][iterLocTmp] = recvTRefLocMsg;
//3        EV << "\nclearEPC\nlocTmps[R][T][n]\nlocTmps["<<cR<<"]["<<cT<<"]["<<iterLocTmp<<"] = " << recvTRefLocMsg;

     // wiAuthDur   [currReader][h] = currWiAuth;
     // woAuthDur   [currReader][h] = currWoAuth;

//        RTLS(cT);

        delete msgIn;
    }
    else if (strcmp(msg->getName(),"endReader") == 0){
        //previous reader finished query
        //endReaderTime[activeReaderTX]=simTime()-startReaderTime[activeReaderTX];
        //1activeReaderTX++;
        cPacket *pktIn = check_and_cast<cPacket *>(msg);
        iMsgToServer *msgIn = check_and_cast<iMsgToServer *>(pktIn->decapsulate());
        //add a table with multiple values such as csi, Q, WoAuth, etc
        ReaderDetail[activeReaderTX].csi_ID      = msgIn->getCsi_ID();
        ReaderDetail[activeReaderTX].Q           = msgIn->getQ();
        ReaderDetail[activeReaderTX].activeTags  = msgIn->getActiveTags();
        ReaderDetail[activeReaderTX].totQRep     = msgIn->getTotQRep();
        ReaderDetail[activeReaderTX].totQAdj     = msgIn->getTotQAdj();
        ReaderDetail[activeReaderTX].totReq      = msgIn->getTotReq();
        ReaderDetail[activeReaderTX].totCol      = msgIn->getTotCol();
        ReaderDetail[activeReaderTX].WoutAuth    = msgIn->getWoutAuth();
        ReaderDetail[activeReaderTX].WithAuth    = msgIn->getWithAuth();

         overallTime += (simtime_t) msgIn->getWithAuth();
         overallDiscoveryTime += (simtime_t) msgIn->getWoutAuth();

        for (int i=0;i<numTags;i++) {
            ReaderDetail[activeReaderTX].toa[i] = msgIn->getToa(i);
        }
        activeReaderTX++;

        EV << "\n\n\ttoReader[" <<activeReaderTX<<"]"<< endl;
        if (activeReaderTX<numReaders) {
            cPacket *pktOut = new cPacket;
            pktOut->setName("startQuery");
            pktOut->setBitLength(4);
            send(pktOut,gate("toReader",activeReaderTX));
        }
        else {
           /*locate each tag
            * 00..numTags
            *
            */
            startLocateTime = simTime();
/*           for (int i=0;i<numTags;i++) {
                msgLocate *pktOut = new msgLocate;
                pktOut->setName("locate");
                pktOut->setTagId(h);
                pktOut->setReaderId(currReader);
                pktOut->setR0_X(coordReader[0].x); pktOut->setR0_Y(coordReader[0].y);pktOut->setR0_Z(coordReader[0].z);
                pktOut->setR0_Distance(distanceTag[0][i]);

                pktOut->setR1_X(coordReader[1].x); pktOut->setR1_Y(coordReader[1].y); pktOut->setR1_Z(coordReader[1].z);
                pktOut->setR1_Distance(distanceTag[1][i]);

                pktOut->setR2_X(coordReader[2].x); pktOut->setR2_Y(coordReader[2].y); pktOut->setR2_Z(coordReader[2].z);
                pktOut->setR2_Distance(distanceTag[2][i]);
                send(pktOut,"toLocate");

                EV << "\nto locate3:\t"
                        <<"("<<coordReader[0].x<<", "<<coordReader[0].y<<", "<<coordReader[0].z<<")"<<distanceTag[0][i]<<"\n"
                        <<"("<<coordReader[1].x<<", "<<coordReader[1].y<<", "<<coordReader[1].z<<")"<<distanceTag[1][i]<<"\n"
                        <<"("<<coordReader[2].x<<", "<<coordReader[2].y<<", "<<coordReader[2].z<<")"<<distanceTag[2][i]<<"\n";
            }*/
        }
        delete msgIn;
        delete pktIn;
    }
    else if (strcmp(msg->getName(),"frLocate") == 0){
        cPacket *pktIn = check_and_cast<cPacket *>(msg);
        lMsgToServer *msgIn = check_and_cast <lMsgToServer *> (pktIn->decapsulate());
        tagsCoordinate[msgIn->getTagID()].x = msgIn->getX();
        tagsCoordinate[msgIn->getTagID()].y = msgIn->getY();
        tagsCoordinate[msgIn->getTagID()].z = msgIn->getZ();
        endLocateTime = simTime();
        delete msgIn;
        delete pktIn;
    }
   //delete msg;
}
/*
void NodeServer::RTLS(int cT) {
    if (boolRTLS == true) { //current implementation June 2017
        EV << "\n\ncounterLocate: " <<counterLocate;
        counterLocate++;
        //add each arrivaltime
        if (counterLocate == 2) {
            //1st calculate distance for active Reader
            // declared in init
            //overheadRTR = (2*preambleDuration) + ((headerBitLength+nbitReqRN)/bitrate) + ((headerBitLength+nbitReqRNReply)/bitrate);
            double distRT[numReaders][numTags];
            for (int i= 0; i<numReaders; i++) { //reader
                EV << "\nR" << activeReaderTX << "->T"<< cT << "->R"<< i
                   << "\nlocTmps[" << i << "][" << cT << "][" << counterLocate<<"]: " << locTmps[i][cT][counterLocate]
                   << "\nlocTmps[" << activeReaderTX << "][" << cT << "][" << counterLocate-1 << "]: " << locTmps[activeReaderTX][cT][counterLocate-1]
                   << "\nTime of flight = " << locTmps[i][cT][counterLocate] - locTmps[activeReaderTX][cT][counterLocate-1]
                   << endl;

                tofRT[i][cT] = SIMTIME_DBL(locTmps[i][cT][counterLocate] - locTmps[activeReaderTX][cT][counterLocate-1]);
                rxTime[i][cT] = (tofRT[i][cT] - overheadRTR)/2;
                distRT[i][cT] = SIMTIME_DBL(rxTime[i][cT])*propagationSpeed;
                 }

            for (int i= 0; i<numReaders; i++) {
                if (i == activeReaderTX) {
                    distRT[i][cT] = SIMTIME_DBL(rxTime[i][cT])*propagationSpeed;
                    EV <<"R"<<activeReaderTX<<"->T"<<cT
                       <<" distance: "
                       << rxTime[i][cT]*propagationSpeed
                       <<endl;
                }
                else {
                    distRT[i][cT] = SIMTIME_DBL(tofRT[i][cT] - overheadRTR - rxTime[activeReaderTX][cT])*propagationSpeed;
                    EV <<"R"<<i<<"->T"<<cT<<" distance: "
                       << (tofRT[i][cT] - overheadRTR - rxTime[activeReaderTX][cT])*propagationSpeed
                       <<endl;
                }
            }

//            msgLocate *pktOut = new msgLocate;
//            pktOut->setName("locate");
//            pktOut->setTagId(h);
//            pktOut->setReaderId(currReader);
//            pktOut->setActiveReader(activeReaderTX);
//            pktOut->setR0_Distance(distRT[0][h]);
//            pktOut->setR1_Distance(distRT[1][h]);
//            pktOut->setR2_Distance(distRT[2][h]);
//            send(pktOut,"toLocate");

            counterLocate = -1;
            iterLocTmp = 1;//kt sini
        }
        boolRTLS = false;
    }else if (boolRTLS == false) {
        currReader = activeReaderTX;
        EV << "\nAPSAL ?";
        if (activeReaderTX < numReaders) {
            send(new cPacket("nextReader"), gate("toReader",activeReaderTX));

            msgLocate *pktOut = new msgLocate;
            pktOut->setName("locate");
            pktOut->setReaderId(currReader);
            pktOut->setTagId(h);
//            pktOut->setR0_X(coordReader[0].x); pktOut->setR0_Y(coordReader[0].y);pktOut->setR0_Z(coordReader[0].z);
//            pktOut->setR0_Distance(distanceTag[0][h]);

//            pktOut->setR1_X(coordReader[1].x); pktOut->setR1_Y(coordReader[1].y); pktOut->setR1_Z(coordReader[1].z);
//            pktOut->setR1_Distance(distanceTag[1][h]);

//            pktOut->setR2_X(coordReader[2].x); pktOut->setR2_Y(coordReader[2].y); pktOut->setR2_Z(coordReader[2].z);
//            pktOut->setR2_Distance(distanceTag[2][h]);
//            send(pktOut,"toLocate");
            EV << "\nto locate0:\t"<<h<<"\t"
                               <<"("<<coordReader[0].x<<", "<<coordReader[0].y<<", "<<coordReader[0].z<<")"<<distanceTag[0][h]<<"\n"
                               <<"("<<coordReader[1].x<<", "<<coordReader[1].y<<", "<<coordReader[1].z<<")"<<distanceTag[1][h]<<"\n"
                               <<"("<<coordReader[2].x<<", "<<coordReader[2].y<<", "<<coordReader[2].z<<")"<<distanceTag[2][h]<<"\n";


        }
        else if (method == 2) {
            startLocateTime = simTime();
            msgLocate *pktOut = new msgLocate;
            pktOut->setName("locate");
            pktOut->setTagId(h);
            pktOut->setReaderId(currReader);
            pktOut->setR0_X(coordReader[0].x); pktOut->setR0_Y(coordReader[0].y);pktOut->setR0_Z(coordReader[0].z);
            pktOut->setR0_Distance(distanceTag[0][h]);

            pktOut->setR1_X(coordReader[1].x); pktOut->setR1_Y(coordReader[1].y); pktOut->setR1_Z(coordReader[1].z);
            pktOut->setR1_Distance(distanceTag[1][h]);

            pktOut->setR2_X(coordReader[2].x); pktOut->setR2_Y(coordReader[2].y); pktOut->setR2_Z(coordReader[2].z);
            pktOut->setR2_Distance(distanceTag[2][h]);
            send(pktOut,"toLocate");

            EV << "\nto locate1:\t"<<h<<"\t"
                    <<"("<<coordReader[0].x<<", "<<coordReader[0].y<<", "<<coordReader[0].z<<")"<<distanceTag[0][h]<<"\n"
                    <<"("<<coordReader[1].x<<", "<<coordReader[1].y<<", "<<coordReader[1].z<<")"<<distanceTag[1][h]<<"\n"
                    <<"("<<coordReader[2].x<<", "<<coordReader[2].y<<", "<<coordReader[2].z<<")"<<distanceTag[2][h]<<"\n";
        }
    }
}
*/
void NodeServer::calculateDuration(int cR, int aR, int overheadType, simtime_t tStart, simtime_t tEnd) {


    if (overheadType == overhEPC) {
        if (cR == aR) {
            EV <<"\nyee: ("
               << tEnd << " - " << tStart << " - " << overheadRT_ACK + overheadTR_EPC << ") = "
               << (tEnd - tStart - overheadRT_ACK - overheadTR_EPC)/2
               <<"\n" << (SIMTIME_DBL((tEnd - tStart - overheadXchange1)/2))*propagationSpeed;
        }
    }
    else if (overheadType == overhHandle) {

    }
    else if (overheadType == overhResAES1) {

    }
}


//    else if (strcmp(msg->getName(),"TRefLoc") == 0) {
        //receive tRefLoc with ReaderId, tagId, RN16
        //require to decrypeEPC first
  //      msgTRefLoc *msgIn = check_and_cast<msgTRefLoc *>(msg);

    //    EV << "\ntrefloc readerId: " << msgIn->getReaderId();
       // currTRefLoc = msgIn->getTRefLoc();
      //  recvTRefLocMsg = (simtime_t) msgIn->getArrivalTime();
       // EV <<"\nrecvTRefLocMsg: " <<recvTRefLocMsg<<endl;
//baru tambah 04/04/2017

 //       msgHideEPC *pktOut = new msgHideEPC;
     //   pktOut->setName("tRefLoc");
   //     pktOut->setReaderId(msgIn->getReaderId());
       // pktOut->setRN16(msgIn->getRN16());
       // pktOut->setTRefLoc(msgIn->getTRefLoc());
       // for (int i=0;i<msgIn->getHideEPC128ArraySize();i++) {
       //     pktOut->setHideEPC128(i,msgIn->getHideEPC128(i));
       // }
       // send(pktOut,toAuth);
       // delete msgIn;
        //EV<<"\nlocTmps[0][0][1]: "<< locTmps[0][0][1];
       // tRefQ[msgIn->getReaderId()][h] = msgIn->getTRefLoc();
   // }
    //else if (strcmp(msg->getName(),"TRefLocClear") == 0) {
       // msgHideEPC *msgIn = check_and_cast<msgHideEPC *>(msg);
        //register time reference to the server;
      //  int cR = msgIn->getReaderId();
        //int cT =(16*msgIn->getEPC96(10)) + msgIn->getEPC96(11);
//3        locTmps[cR][cT][iterLocTmp] = recvTRefLocMsg;
//3        EV << "\ntref locTmps["<<cR<<"]["<<cT<<"]["<<iterLocTmp<<"] = " <<recvTRefLocMsg;
//3        iterLocTmp++;

        //        locDetails[cT][iterLocTmp].readerId = cR;
//        locDetails[cT][iterLocTmp].tempsRef = SIMTIME_DBL(recvTRefLocMsg);
//        EV <<"\nlocDetails["<<cT<<"]["<<iterLocTmp<<"].tempsRef:\t"<<locDetails[cT][iterLocTmp].tempsRef;

        //       tRefQ[cR][cT] = msgIn->getTRefLoc();
 //       EV << "\n\ntRef for R" << cR << " T" << cT << ": " << tRefQ[cR][cT];
        //delete msgIn;
   // }

//    else if (strcmp(msg->getName(),"RTLS") == 0) {
       // EV<<"\nlocTmps[0][0][1]: "<< locTmps[0][0][1];

  //      iMsgManager *msgIn = check_and_cast <iMsgManager *> (msg);

        //currReader = msgIn->getReaderId();
    //    currReader = activeReaderTX;
      //  recvTRefLocMsg = (simtime_t) msgIn->getArrivalTime();
      //  currToA[currReader] = msgIn->getToA();
      //  if (currReader == msgIn->getActiveReader()) {
       //     refToA = msgIn->getToA();
       // }

//        EV <<"\nServer received" << currDist
  //              << " m from R" << currReader<<" at "
      //          <<recvTRefLocMsg << "with " << iterLocTmp << " instance" << endl;
    //    msgHideEPC *pktOut = new msgHideEPC;
      //  pktOut->setRN16(msgIn->getRN16());
      //  pktOut->setReaderId(currReader);
      //  for (int i=0;i<msgIn->getHideEPC128ArraySize();i++) {
      //      pktOut->setHideEPC128(i,msgIn->getHideEPC128(i));
      //      EV << " " << msgIn->getHideEPC128(i);
      //  }
      //  send(pktOut,toAuth);
      //  boolRTLS = true;
       // delete msgIn;
//        EV<< "\nR" << currReader <<"( " <<msgIn->getRX()<<", " << msgIn->getRY()<<", " <<msgIn->getRZ()<<")";

 //   }


