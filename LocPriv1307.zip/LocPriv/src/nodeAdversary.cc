//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 


#include "nodeAdversary.h"

Define_Module(NodeAdversary);
/*
 * Adversary could listen to all radio communication. Knowing that tag will only communicate in one
 * conversation. And assuming that the adversary recognized the data format, it could then, capture
 * the RN16 given by tag for that particular session. However, it could not interfere since it is
 * only valid for the current R->T session. If the adversary re-sent the RN16, it will be ignored by
 * tag.
 */


void NodeAdversary::initialize()
{
    EV << "initial adversary" << endl;
    toRadio  = gate("toRadio");
    frRadio  = gate("frRadio");

    radioModule = gate("toRadio")->getPathEndGate()->getOwnerModule();
    radio1 = check_and_cast<inet::physicallayer::IRadio *>(radioModule);

    thisNode = inet::getContainingNode(this);
    mod = check_and_cast<inet::IMobility *>(thisNode->getParentModule()->getSubmodule("mobility"));

}

void NodeAdversary::finish() {}

void NodeAdversary::handleMessage(cMessage *msg) {
    radio1->setRadioMode(inet::physicallayer::IRadio::RADIO_MODE_RECEIVER);
    // 1st case: arrive a tout recevoir..
    EV <<"\nAdversary captured: " << msg;
    delete msg;
}



