//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_AUTHENTICATIONTAG_H_
#define __LOCPRIV_AUTHENTICATIONTAG_H_

#include <omnetpp.h>
#include "command.h"
#include "AllMsg_m.h"
//#include "memory.h" // for memset and memcpy
#include "sha1.h"


#define SHA1_LITTLE_ENDIAN
#define SHA1_WIPE_VARIABLES

//#define BYTE unsigned char
//#define UINT_32 unsigned int



// Member variables
//typedef union {
//    BYTE  c[64];
//    UINT_32 l[16];
//} SHA1_WORKSPACE_BLOCK;
//move to command.h

/*
 * TODO - Generated class
 */
class AuthenticationTag : public cSimpleModule
{
public:
//    enum {
//        SHA1_DIGEST_LENGTH  = 20,
//        SHA1_BLOCK_SIZE     = 64,
        //             HMAC_BUF_LEN        = 4096
//        HMAC_BUF_LEN        = 64
//    };

protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();

    cGate       *toTag;
    cGate       *frTag;
    int         cryptoSuite;
    int         challCSI;
    bool        cryptoGPSpass;

    //function declaration
     void    replyXOR                    (cMessage *msg);
     void    replyPresent                (cMessage *msg);
     void    reply1GPSCCR                (cMessage *msg);
     void    reply2GPSCCR                (cMessage *msg);
     tGPS1b  *CCRy                       ();
     void    replyAES1                   (cMessage *msg);
     void    replyAES2                   (cMessage *msg);
     void    AES128_ECB_encrypt          (int* input, const int* key, int* output);
     void    BlockCopy                   (int* output, int* input);
     void    KeyExpansion                ();
     void    Cipher                      ();
     int     getSBoxValue                (int num);
     void    AddRoundKey                 (int round);
     void    MixColumns                  ();
     void    ShiftRows                   ();
     void    SubBytes                    ();
     int     xtime                       (int x);
     void    AES128_CBC_encrypt_buffer   (int* output, int* input, int length, const int* key, const int* iv);
     void    XorWithIv                   (int* buf);
     bool    fnInRange                   (int x1, int y1, int z1, int x2, int y2, int z2);

     void    HMAC_SHA1(BYTE text[12], int text_len, BYTE *key, int key_len, BYTE *digest);
     void    dispHEX                     (BYTE *msg, int msgLength);
     void    Update(BYTE *data, UINT_32 len);      // Update the hash value
     void    Final();     // Finalize hash and report
     void    GetHash(BYTE *puDest);
     void    Transform(UINT_32 *state, BYTE *buffer);     // Private SHA-1 transformation
     virtual void Reset();

     // The array that stores the round keys.
      int           RoundKey[176];

      // The Key input to the AES Program
      const int*    Key;

      state_t*      state;
      int           *Iv;

private:
      BYTE          m_ipad[64];
      BYTE          m_opad[64];
      BYTE          digest[20] ;
      BYTE          m_buffer[64];
      BYTE          m_digest[20];

      UINT_32       m_state[5];
      UINT_32       m_count[2];
      UINT_32       __reserved1[1];
      UINT_32       __reserved2[3];

      BYTE AppendBuf1[64];
      BYTE AppendBuf2[64];
      BYTE SHA1_Key[64];
      BYTE szReport[64];
      BYTE          m_workspace[64];

      enum {
          SHA1_DIGEST_LENGTH  = 20,
          SHA1_BLOCK_SIZE     = 64,
          //             HMAC_BUF_LEN        = 4096
          HMAC_BUF_LEN        = 64
      };

      typedef union {
          BYTE    c[64];
          UINT_32   l[16];
      } SHA1_WORKSPACE_BLOCK;
      SHA1_WORKSPACE_BLOCK *m_block; // SHA1 pointer to the byte array above
      int           hmSHA1[20];
};

#endif
