/*
 * sha1.h
 *
 *  Created on: Mar 11, 2017
 *      Author: AHMAD
 */

#ifndef SHA1_H_
#define SHA1_H_

#define ROL32(_val32, _nBits) (((_val32)<<(_nBits))|((_val32)>>(32-(_nBits))))
#define SHABLK0(i) (m_block->l[i] = (ROL32(m_block->l[i],24) & 0xFF00FF00) | (ROL32(m_block->l[i],8) & 0x00FF00FF))
#define SHABLK(i) (m_block->l[i&15] = ROL32(m_block->l[(i+13)&15] ^ m_block->l[(i+8)&15] ^ m_block->l[(i+2)&15] ^ m_block->l[i&15],1))

// SHA-1 rounds
#define _R0(v,w,x,y,z,i) { z+=((w&(x^y))^y)     + SHABLK0(i) + 0x5A827999 + ROL32(v,5); w=ROL32(w,30); }
#define _R1(v,w,x,y,z,i) { z+=((w&(x^y))^y)     + SHABLK(i)  + 0x5A827999 + ROL32(v,5); w=ROL32(w,30); }
#define _R2(v,w,x,y,z,i) { z+=(w^x^y)           + SHABLK(i)  + 0x6ED9EBA1 + ROL32(v,5); w=ROL32(w,30); }
#define _R3(v,w,x,y,z,i) { z+=(((w|x)&y)|(w&x)) + SHABLK(i)  + 0x8F1BBCDC + ROL32(v,5); w=ROL32(w,30); }
#define _R4(v,w,x,y,z,i) { z+=(w^x^y)           + SHABLK(i)  + 0xCA62C1D6 + ROL32(v,5); w=ROL32(w,30); }

#endif /* SHA1_H_ */
