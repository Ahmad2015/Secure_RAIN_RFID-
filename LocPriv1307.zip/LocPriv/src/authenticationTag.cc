//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "authenticationTag.h"
//#include "command.h"
//#include "memory.h"
//#include "stdio.h"
//#include "string.h" // memcmp, memcpy, memset


Define_Module(AuthenticationTag);
//GPS CCR do not support Challenge command..
//GPS CCR do not support ResponseBuffer with EPC

//  AES secret key
int key[16] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};

BYTE tsKey[64] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
                 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13,
                 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d,
                 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
                 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31,
                 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b,
                 0x3c, 0x3d, 0x3e, 0x3f};

void AuthenticationTag::initialize() {
    // TODO - Generated method body
    toTag = gate("toTag");
    frTag = gate("frTag");
    cryptoSuite = par("CryptoSuite");
//    challCSI = par("challCSI");
    cryptoGPSpass = false;
}

void AuthenticationTag::HMAC_SHA1( BYTE text[12], int text_len, BYTE *key, int key_len, BYTE *digest) {
    m_block = (SHA1_WORKSPACE_BLOCK *)m_workspace;

    //for (int i=0;i<64;i++) {
     //   m_ipad[i]=0;
     //   m_opad[i]=0;
     //   szReport[i]=0;
    //    AppendBuf1[i]=0;
    //    AppendBuf2[i]=0;
    //    SHA1_Key[i]=0;
    //}

    //initialize with 0
    memset(SHA1_Key, 0x00, SHA1_BLOCK_SIZE); //SHA1_BLOCK_SIZE = 64
    memset(AppendBuf1,0x00,sizeof(AppendBuf1));
    memset(AppendBuf2,0x00,sizeof(AppendBuf2));
    //memset=(szReport,0x00,sizeof(szReport));

    /* repeated 64 times for values in ipad and opad */
    memset(m_ipad, 0x36, sizeof(m_ipad)); //decimal 54
    memset(m_opad, 0x5c, sizeof(m_opad)); //decimal 92
   // EV <<"\n text in clear:\t:" << text;

    EV <<"\nText in HEX:\t"; dispHEX((unsigned char *)text, text_len);
    EV <<"\n\nkey:\t";       dispHEX((unsigned char *)key, key_len);

   // EV << thisNode->getParentModule()->getSubmodule("tag");
    //pos = mod->getCurrentPosition();
    //EV <<"\n\nTag Real coordinate: (" << pos.x <<"," <<pos.y<<","<<pos.z<<")"<<endl;

    /* STEP 1 */
    //if key length is equal to the block size
    if (key_len > SHA1_BLOCK_SIZE) {
        Reset();
        Update((BYTE *)key, key_len);
        Final();
        GetHash((BYTE *)SHA1_Key);
   }
    else {
        memcpy(SHA1_Key, key, key_len);
        }

    EV <<"\n\nK0:\t";
    dispHEX((unsigned char *) SHA1_Key, sizeof(SHA1_Key));

    /* STEP 2 */
    for (int i=0; i<sizeof(m_ipad); i++) {
        m_ipad[i] ^= SHA1_Key[i];
    }
    EV <<"\n\nStep 2:\nK0 ^ ipad:\t";
    dispHEX((unsigned char *) m_ipad, sizeof(m_ipad));

    /* STEP 3 */
    memcpy(AppendBuf1, m_ipad, sizeof(m_ipad));
    memcpy(AppendBuf1 + sizeof(m_ipad), text, text_len);
    EV << "\n\nSTEP 3\n(K0^ipad||text):\t";
    dispHEX((unsigned char *) AppendBuf1, 64+text_len);

    /* STEP 4 */
    Reset();
    Update((BYTE *)AppendBuf1, sizeof(m_ipad) + text_len);
    Final();
    GetHash((BYTE *)szReport);
    EV << "\n\nSTEP 4:\nHash(K0^ipad||text) after:";
    dispHEX(szReport, std::strlen((char *)szReport));

    /* STEP 5 */
    for (int j=0; j<sizeof(m_opad); j++) {
        m_opad[j] ^= SHA1_Key[j];
    }
     EV <<"\n\nStep5\nopad ^ KO:\t";// for (int i=0;i<64;i++) EV<< m_opad[i]+1-1;
     dispHEX((unsigned char *)m_opad, sizeof(m_opad));

    /* STEP 6 */
//  EV <<"\n\nStep 6 b4:\n";
     dispHEX(AppendBuf2, 64);
    memcpy(AppendBuf2, m_opad, sizeof(m_opad));
    memcpy(AppendBuf2 + sizeof(m_opad), szReport, SHA1_DIGEST_LENGTH);
    EV <<"\n\nStep 6\n(K0 ^ opad) || Hash((Key ^ ipad)||text)";
 //   dispHEX(AppendBuf2, sizeof(m_opad)+SHA1_DIGEST_LENGTH);


    /*STEP 7 */
    Reset();
    Update((BYTE *)AppendBuf2, sizeof(m_opad) + SHA1_DIGEST_LENGTH);
    Final();
    GetHash((BYTE *)digest);

    EV <<"\n\nSTEP 7\nHMAC(Key, Text) = Hash((K0^opad)||Hash(Key ^ ipad)||clearEPC))";
    dispHEX((unsigned char *) digest,20);


 //   cPacket *result = (cPacket *)digest;
 //   cPacket *pktOut = new cPacket;
 //   pktOut->setName("HMACSHA1");
 //   pktOut->addPar("hmac");
 //   pktOut->par("hmac").setStringValue((char *)digest);
 //   send(pktOut,toTag);

}


/****** BAWAK DR SHA1 ***/

void AuthenticationTag::Reset() {
    // SHA1 initialization constants
    m_state[0] = 0x67452301;
    m_state[1] = 0xEFCDAB89;
    m_state[2] = 0x98BADCFE;
    m_state[3] = 0x10325476;
    m_state[4] = 0xC3D2E1F0;

    m_count[0] = 0;
    m_count[1] = 0;
}

void AuthenticationTag::Transform(UINT_32 *state, BYTE *buffer) {
    // Copy state[] to working vars
        UINT_32 a, b, c, d, e;

        a = state[0];
        b = state[1];
        c = state[2];
        d = state[3];
        e = state[4];

        memcpy(m_block, buffer, 64);

        // 4 rounds of 20 operations each. Loop unrolled.
        _R0(a,b,c,d,e, 0); _R0(e,a,b,c,d, 1); _R0(d,e,a,b,c, 2); _R0(c,d,e,a,b, 3);
        _R0(b,c,d,e,a, 4); _R0(a,b,c,d,e, 5); _R0(e,a,b,c,d, 6); _R0(d,e,a,b,c, 7);
        _R0(c,d,e,a,b, 8); _R0(b,c,d,e,a, 9); _R0(a,b,c,d,e,10); _R0(e,a,b,c,d,11);
        _R0(d,e,a,b,c,12); _R0(c,d,e,a,b,13); _R0(b,c,d,e,a,14); _R0(a,b,c,d,e,15);
        _R1(e,a,b,c,d,16); _R1(d,e,a,b,c,17); _R1(c,d,e,a,b,18); _R1(b,c,d,e,a,19);
        _R2(a,b,c,d,e,20); _R2(e,a,b,c,d,21); _R2(d,e,a,b,c,22); _R2(c,d,e,a,b,23);
        _R2(b,c,d,e,a,24); _R2(a,b,c,d,e,25); _R2(e,a,b,c,d,26); _R2(d,e,a,b,c,27);
        _R2(c,d,e,a,b,28); _R2(b,c,d,e,a,29); _R2(a,b,c,d,e,30); _R2(e,a,b,c,d,31);
        _R2(d,e,a,b,c,32); _R2(c,d,e,a,b,33); _R2(b,c,d,e,a,34); _R2(a,b,c,d,e,35);
        _R2(e,a,b,c,d,36); _R2(d,e,a,b,c,37); _R2(c,d,e,a,b,38); _R2(b,c,d,e,a,39);
        _R3(a,b,c,d,e,40); _R3(e,a,b,c,d,41); _R3(d,e,a,b,c,42); _R3(c,d,e,a,b,43);
        _R3(b,c,d,e,a,44); _R3(a,b,c,d,e,45); _R3(e,a,b,c,d,46); _R3(d,e,a,b,c,47);
        _R3(c,d,e,a,b,48); _R3(b,c,d,e,a,49); _R3(a,b,c,d,e,50); _R3(e,a,b,c,d,51);
        _R3(d,e,a,b,c,52); _R3(c,d,e,a,b,53); _R3(b,c,d,e,a,54); _R3(a,b,c,d,e,55);
        _R3(e,a,b,c,d,56); _R3(d,e,a,b,c,57); _R3(c,d,e,a,b,58); _R3(b,c,d,e,a,59);
        _R4(a,b,c,d,e,60); _R4(e,a,b,c,d,61); _R4(d,e,a,b,c,62); _R4(c,d,e,a,b,63);
        _R4(b,c,d,e,a,64); _R4(a,b,c,d,e,65); _R4(e,a,b,c,d,66); _R4(d,e,a,b,c,67);
        _R4(c,d,e,a,b,68); _R4(b,c,d,e,a,69); _R4(a,b,c,d,e,70); _R4(e,a,b,c,d,71);
        _R4(d,e,a,b,c,72); _R4(c,d,e,a,b,73); _R4(b,c,d,e,a,74); _R4(a,b,c,d,e,75);
        _R4(e,a,b,c,d,76); _R4(d,e,a,b,c,77); _R4(c,d,e,a,b,78); _R4(b,c,d,e,a,79);

        // Add the working vars back into state
        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
        state[4] += e;

        /* Wipe variables */
        a = b = c = d = e = 0;
}

void AuthenticationTag::Update(BYTE *data, UINT_32 len) {
    UINT_32 i, j;

    j = (m_count[0] >> 3) & 63;

    if((m_count[0] += len << 3) < (len << 3)) m_count[1]++;

    m_count[1] += (len >> 29);

    if((j + len) > 63) {
        i = 64 - j;
        memcpy(&m_buffer[j], data, i);
        Transform(m_state, m_buffer);
        for(; i + 63 < len; i += 64) Transform(m_state, &data[i]);
       j = 0;
    }
    else i = 0;

    memcpy(&m_buffer[j], &data[i], len - i);
}

void AuthenticationTag::Final() {
    UINT_32 i;
    BYTE finalcount[8];

    for(i = 0; i < 8; i++)
        finalcount[i] = (BYTE)((m_count[((i >= 4) ? 0 : 1)]
            >> ((3 - (i & 3)) * 8) ) & 255); // Endian independent

    Update((BYTE *)"\200", 1);

    while ((m_count[0] & 504) != 448)
        Update((BYTE *)"\0", 1);

    Update(finalcount, 8); // Cause a SHA1Transform()

    for(i = 0; i < 20; i++) {
        m_digest[i] = (BYTE)((m_state[i >> 2 ] >> ((3 - (i & 3)) * 8) ) & 255);
    }
}

void AuthenticationTag::GetHash(BYTE *puDest) {
    memcpy(puDest, m_digest, 20);
 }



void AuthenticationTag::dispHEX(unsigned char *msg, int msgLength) {

    for (int i=0;i<msgLength;i++) {
        //EV <<" <"<< msg[i]-0<<"> ";
         if (i % 4 == 0) EV << " ";
         if (i % 16 == 0) EV << "\n";

         if ((int) msg[i] /16 == 0)       { EV <<"0"; hmSHA1[i] = 0;     }
         else if ((int) msg[i] /16 == 1)  { EV <<"1"; hmSHA1[i] = 1*16;  }
         else if ((int) msg[i] /16 == 2)  { EV <<"2"; hmSHA1[i] = 2*16;  }
         else if ((int) msg[i] /16 == 3)  { EV <<"3"; hmSHA1[i] = 3*16;  }
         else if ((int) msg[i] /16 == 4)  { EV <<"4"; hmSHA1[i] = 4*16;  }
         else if ((int) msg[i] /16 == 5)  { EV <<"5"; hmSHA1[i] = 5*16;  }
         else if ((int) msg[i] /16 == 6)  { EV <<"6"; hmSHA1[i] = 6*16;  }
         else if ((int) msg[i] /16 == 7)  { EV <<"7"; hmSHA1[i] = 7*16;  }
         else if ((int) msg[i] /16 == 8)  { EV <<"8"; hmSHA1[i] = 8*16;  }
         else if ((int) msg[i] /16 == 9)  { EV <<"9"; hmSHA1[i] = 9*16;  }
         else if ((int) msg[i] /16 == 10) { EV <<"A"; hmSHA1[i] = 10*16; }
         else if ((int) msg[i] /16 == 11) { EV <<"B"; hmSHA1[i] = 11*16; }
         else if ((int) msg[i] /16 == 12) { EV <<"C"; hmSHA1[i] = 12*16; }
         else if ((int) msg[i] /16 == 13) { EV <<"D"; hmSHA1[i] = 13*16; }
         else if ((int) msg[i] /16 == 14) { EV <<"E"; hmSHA1[i] = 14*16; }
         else if ((int) msg[i] /16 == 15) { EV <<"F"; hmSHA1[i] = 15*16; }

         if ((int) msg[i] %16 == 0)       { EV <<"0"; hmSHA1[i] += 0;  }
         else if ((int) msg[i] %16 == 1)  { EV <<"1"; hmSHA1[i] += 1;  }
         else if ((int) msg[i] %16 == 2)  { EV <<"2"; hmSHA1[i] += 2;  }
         else if ((int) msg[i] %16 == 3)  { EV <<"3"; hmSHA1[i] += 3;  }
         else if ((int) msg[i] %16 == 4)  { EV <<"4"; hmSHA1[i] += 4;  }
         else if ((int) msg[i] %16 == 5)  { EV <<"5"; hmSHA1[i] += 5;  }
         else if ((int) msg[i] %16 == 6)  { EV <<"6"; hmSHA1[i] += 6;  }
         else if ((int) msg[i] %16 == 7)  { EV <<"7"; hmSHA1[i] += 7;  }
         else if ((int) msg[i] %16 == 8)  { EV <<"8"; hmSHA1[i] += 8;  }
         else if ((int) msg[i] %16 == 9)  { EV <<"9"; hmSHA1[i] += 9;  }
         else if ((int) msg[i] %16 == 10) { EV <<"A"; hmSHA1[i] += 10; }
         else if ((int) msg[i] %16 == 11) { EV <<"B"; hmSHA1[i] += 11; }
         else if ((int) msg[i] %16 == 12) { EV <<"C"; hmSHA1[i] += 12; }
         else if ((int) msg[i] %16 == 13) { EV <<"D"; hmSHA1[i] += 13; }
         else if ((int) msg[i] %16 == 14) { EV <<"E"; hmSHA1[i] += 14; }
         else if ((int) msg[i] %16 == 15) { EV <<"F"; hmSHA1[i] += 15; }
     }
}

void AuthenticationTag::handleMessage(cMessage *msg) {
    // TODO - Generated method body
    // if "hideEPC2"
    if (strcmp(msg->getName(),"hideEPC1") == 0) {
        EV <<"\nAuthenticationTag: hideEPC1\n";
        BYTE input[sizeEPC];
        msgHideEPC *msgIn = check_and_cast <msgHideEPC *> (msg);

        for (int i=0;i<sizeEPC;i++) {
            input[i] = (BYTE) msgIn->getEPC96(i);
        }

   //unsigned char *clearEPC = (unsigned char *) "Sample #1" ;
   //     unsigned char *clearEPC = (unsigned char *) msg->getDefaultOwner()->getOwner()->getFullName();

        //sKey + RN16... however, R will need to calculate all the possibilitites
        HMAC_SHA1( input, sizeEPC, tsKey, 64, digest);
        msgHideEPC *msgOut = new msgHideEPC;
        msgOut->setName("doneHideEPC");
        msgOut->setRN16(msgIn->getRN16());
        for (int i=0; i<20 ;i++) {
            msgOut->setHideEPC128(i,digest[i]);
        }
        EV <<"\nSend out to tags";
        send(msgOut,toTag);
    }
    else if (strcmp(msg->getName(), "hideEPC2") == 0) {
        int input[16] ={0};
        int output[16]= {0};

        msgHideEPC *msgIn = check_and_cast <msgHideEPC *> (msg);
        EV << "\nReceived EPC: ";

        for (int i=0;i<12;i++) {
            input[i] = msgIn->getEPC96(i);
            EV << input[i]<<" ";
        }

        // concanate RN16

        AES128_ECB_encrypt(input, key, output);
        msgHideEPC *msgOut = new msgHideEPC;
        msgOut->setName("doneHideEPC");
        msgOut->setRN16(msgIn->getRN16());

        EV <<"\nencryptedAES: ";

        for (int i=0; i<16 ;i++) {
            msgOut->setHideEPC128(i,output[i]);
            EV<<output[i]<<" ";
        }
        send(msgOut,toTag);
        //delete packetIn;
      }
    else if (strcmp(msg->getName(), "AuthRequest") == 0) {
        if (cryptoSuite == XOR) {
            replyXOR(msg);
        }
        else if (cryptoSuite == PRESENT80) {
            replyPresent(msg);
        }
        else if (cryptoSuite == GPSCCR) {
            if (cryptoGPSpass == false) {
                EV<<"\nreply1CCR";
                reply1GPSCCR(msg);
                cryptoGPSpass = true;
            }
            else {
                EV<< "\nreply2CCR:\t";
                reply2GPSCCR(msg);
                cryptoGPSpass = false;
            }
        }
        else if (cryptoSuite == AES128ECB) {
            replyAES1(msg);
        }
        else if (cryptoSuite == AES128CBC) {
            EV << "dlm AES2";
            replyAES2(msg);
        }
        else { // cryptoERROR
            //tState = ARBITRATE;
            EV << "need to change tState to ARBITRATE!!! ";
            //1606 ////delete msg;
        }
        //delete msg;
    }
    else if  (strcmp(msg->getName(), "ChallRequest") == 0) {
    }
 //   else if (strcasecmp(msg->getName(), "Hide") == 0) {
//    }
    delete msg;
}


void AuthenticationTag::replyXOR(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgXOR1In = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iXOR1 *msgIn = check_and_cast <iXOR1 *> (msgXOR1In->decapsulate());
//  inRange = fnInRange(lastPosition.x, lastPosition.y, lastPosition.z, msgIn->getSx(), msgIn->getSy(), msgIn->getSz());

    tXOR1 *msgXOR1Out = new tXOR1;
    unsigned long Register1, Register2, n;
    int Bit1Counter;

//  tState = READY;
    Register1 = msgIn->getSrni(); //SRNi from Reader
    Register2 = XOR_PSK;
    Register1 = Register1 ^ Register2;  //SRNi ⊕ PSK
    EV << "\n\t\t SRNi ⊕ PSK :\t\t" << Register1 <<" = RN + On";
    Register1 = Register1 - XOR_On;     //9.1.2.3.2.a RNi = (SRNi ⊕ PSK) - On
    n = Register1;

    Bit1Counter = 0;
    while(n) {
        Bit1Counter++;
        n &= n-1;
    }

    while (Bit1Counter >0) {
        Register1 = Register1 << 1; //RNi'
        Register2 = Register2 << 1; //PSK'
        Bit1Counter--;
    }
    Register2 = Register2 + XOR_On; //PSK' + On
    EV << "\n\t\t PSK' + On : \t\t" << Register2;
    Register2 = Register2 ^ Register1; //SORNi = (PSK'+On) ⊕ RNi
    EV << "\n\t\t SORNi  : \t\t" << Register2;

//1904    Register1 = rand();
//1904    Register1 = Register1 + XOR_On;
//1904    Register1 = Register1 ^ XOR_PSK;

    msgXOR1Out->setSorni(Register2);
//1904    EV << "\n\t\t SRNi :" << Register1;
    //return (msgXOR1Out);

    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");
    msgOut->encapsulate(msgXOR1Out);

    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTXOR);
    send(pktOut,toTag);

//  duration = nbitTXOR/txRate;
//  EV << "send tp:\t" << server->getFullName();
//  sendDirect(msgOut, radioDelay, duration, server->gate("in"));
    delete msgXOR1In;
    delete msgIn;
    //1606 ////delete pktIn;;
}

void AuthenticationTag::replyPresent(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgPresentIn = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iPRESENT *msgIn = check_and_cast <iPRESENT *> (msgPresentIn->decapsulate());
//  inRange = fnInRange(lastPosition.x, lastPosition.y, lastPosition.z, msgIn->getSx(), msgIn->getSy(), msgIn->getSz());

    const int sBox4[] = {  0xc, 0x5, 0x6, 0xb, 0x9, 0x0, 0xa, 0xd, 0x3, 0xe, 0xf, 0x8, 0x4, 0x7, 0x1, 0x2};
//  Input values
    int keyp[] = {0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b};
    volatile int state[] = {
            msgIn->getIChallenge(0), msgIn->getIChallenge(1),
            msgIn->getIChallenge(2), msgIn->getIChallenge(3),
            msgIn->getIChallenge(4), msgIn->getIChallenge(5),
            msgIn->getIChallenge(6), msgIn->getIChallenge(7)};

//  Counter
    int i = 0;
//  pLayer variables
    int position = 0;
    int element_source = 0;
    int bit_source = 0;
    int element_destination = 0;
    int bit_destination = 0;
    int temp_pLayer[8];
//  Key scheduling variables
    int round;
    int save1;
    int save2;
//  ****************** Encryption **************************
    round=0;
    do
    {
//  ****************** addRoundkey *************************
        //state[i] ⨁ roundkey (80bits)
        i=0;
        do
        {
            state[i] = (state[i] &0xFF) ^ (keyp[i+2] &0xFF);
            i++;
        }
        while(i<=7);
//  ****************** sBox ********************************
        // substitute state[i] with new value
        do
        {
            i--;
            state[i] = (sBox4[state[i]>>4]<<4 &0xFF) | sBox4[state[i] & 0xF];
        }
        while(i>0);
//  ****************** pLayer ******************************
        for(i=0;i<8;i++)
        {
            temp_pLayer[i] = 0;
        }
        for(i=0;i<64;i++)
        {
            position = (16*i) % 63;         //Artithmetic calculation of the pLayer
            if(i == 63)                     //exception for bit 63
                position = 63;
            element_source      = i / 8;
            bit_source          = i % 8;
            element_destination = position / 8;
            bit_destination     = position % 8;
            temp_pLayer[element_destination] |= ((state[element_source]>>bit_source) & 0x1) << bit_destination;
        }
        for(i=0;i<=7;i++)
        {
            state[i] = temp_pLayer[i];
        }
//  ****************** End pLayer **************************
//  ****************** Key Scheduling **********************
        save1  = keyp[0];
        save2  = keyp[1];
        i = 0;
        do
        {
            keyp[i] = keyp[i+2];
            i++;
        }
        while(i<8);
        keyp[8] = save1;
        keyp[9] = save2;
        i = 0;
        save1 = keyp[0] & 7;                             //61-bit left shift
        do
        {
            keyp[i] = (keyp[i] >> 3 &0xFF)| (keyp[i+1] << 5 &0xFF);
            i++;
        }
        while(i<9);
        keyp[9] = (keyp[9] >> 3 &0xFF)| (save1 << 5 &0xFF);

        keyp[9] = sBox4[keyp[9]>>4]<<4 | (keyp[9] & 0xF);  //S-Box application

        if((round+1) % 2 == 1)                          //round counter addition
            keyp[1] ^= 128;
        keyp[2] = ((((round+1)>>1) ^ (keyp[2] & 15)) | (keyp[2] & 240));
//  ****************** End Key Scheduling ******************
        round++;
    }
    while(round<31);

//  ****************** addRoundkey *************************
    i = 0;
    do                                      //final key XOR
    {
        state[i] = (state[i] &0xFF) ^ (keyp[i+2] &0xFF);
        i++;
    }
    while(i<=7);

//  ****************** End addRoundkey *********************
//  ****************** End Encryption  **********************
    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");
    tPRESENT *msgPresent = new tPRESENT;
    for (int i=0 ; i<8 ; i++) {
        msgPresent->setTResponse(i,state[i]);
    }
    msgOut->encapsulate(msgPresent);
    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTPRESENT);
    send(pktOut,toTag);

//  duration = nbitTPRESENT/txRate;
//  EV << "send tp:\t" << server->getFullName();
//  sendDirect(msgOut, radioDelay, duration, server->gate("in"));

//1606 delte msgIn;
//1606 ////delete pktIn;;

}
void AuthenticationTag::reply1GPSCCR(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgCcr1In = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iGPS1a *msgIn = check_and_cast <iGPS1a *> (msgCcr1In->decapsulate());
//  inRange = fnInRange(lastPosition.x, lastPosition.y, lastPosition.z, msgIn->getSx(), msgIn->getSy(), msgIn->getSz());

    tGPS1a *msgGps = new tGPS1a;
    if ((msgIn->getAuthMethod() == 0)
            && (msgIn->getStep() == 0)
            && (msgIn->getFlags() == 0)) {
        // a new coupon (ri, Xi) is used,
        // 10.2.b T->R sends coupon X
        // X = EC2OSPe([r]P,fmt);

        int X[] = { 0x04, 0xDA, 0xD4, 0x8D, 0x02, 0x4B, 0x83, 0xE2,
                    0x23, 0x4C, 0x0F, 0x5F, 0xFF, 0xB5, 0x1C, 0x15,
                    0xB7, 0x1D, 0x52, 0xCF, 0x92, 0xB3, 0x53, 0x58,
                    0xCF, 0xFF, 0xE4, 0x27, 0x56, 0x84, 0x3D, 0x0D,
                    0xF8, 0xF3, 0x16, 0x69, 0x71, 0xE8, 0xAF, 0x6E,
                    0x22, 0x6F, 0xD3, 0x81, 0xB0, 0xA8, 0x16, 0x72,
                    0x0F};

        //T -> R, sending Xi
        msgGps->setLenghtx(8*49);
        for (int i=0; i<49 ; i++) {
            msgGps->setX(i,X[i]);
        }
    }
//  return msgOut;
    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");
    msgOut->encapsulate(msgGps);
    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTCRYPTO1a);
    send(pktOut,toTag);
//  duration = nbitTCRYPTO1a/txRate;
//  sendDirect(msgOut, radioDelay, duration, server->gate("in"));
//  //1606 delte msgIn;
}

void AuthenticationTag::reply2GPSCCR(cMessage *msg) {
    EV <<"\n\ninreply2";
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgCcr2In = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iGPS1b *msgIn = check_and_cast <iGPS1b *> (msgCcr2In->decapsulate());
//  inRange = fnInRange(lastPosition.x, lastPosition.y, lastPosition.z, msgIn->getSx(), msgIn->getSy(), msgIn->getSz());

    tGPS1b *msgGps = new tGPS1b;

    int z[] = { 0x2D, 0xF0, 0xF5, 0xB4, 0xF2};

    // 10.2.e.12.i - no LHW optimization, therefore z = c
    int cisz=0;

    // verification of 'c'
    for (int i=0; i<5; i++) if (msgIn->getIChallenge(i) != z[i]) cisz=1;
    if (cisz == 0) msgGps = CCRy();
    else EV<< "c INVALID!!!";
//  EV << "\nCCR_Rep2 T->R\n";
    //return msgOut;
    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");
    msgOut->encapsulate(msgGps);
    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTCRYPTO1b);
    send(pktOut,toTag);
//  duration = nbitTCRYPTO1b/txRate;
//  EV << "send tp:\t" << server->getFullName();
//  sendDirect(msgOut, radioDelay, duration, server->gate("in"));

    //1606 delte msgIn;

//134 ////delete msgGps;
}

tGPS1b *AuthenticationTag::CCRy(void) {
//  The claimant shall store a private key s (as a string of σ bits).
    int s[] = {
            0x4f, 0x1d, 0xf0, 0x3a, 0xa3, 0x2d, 0xca, 0x02,
            0x65, 0x2e, 0x83, 0xe7, 0xe5, 0xff, 0x52, 0x59,
            0xd6, 0x1f, 0x55, 0x63, 0xb3, 0xa0, 0xfa, 0x10
    };

    int r[] = {
            0x05, 0xE8, 0xB1, 0xE1, 0x12, 0x1B, 0x08, 0xFB,
            0x9A, 0x0F, 0x58, 0xFC, 0x1E, 0x93, 0x2F, 0x9C,
            0xEF, 0xE9, 0x4D, 0x62, 0x9B, 0xC2, 0x23, 0x40,
            0xB5, 0xF0, 0x4B, 0x55, 0x4D, 0xCD, 0x2B, 0xC8,
            0x12, 0xA7, 0x6D, 0x98, 0xF8, 0xBA, 0x3E
    };

    int z[] = {
            0x2D, 0xF0, 0xF5, 0xB4, 0xF2
    };

    int res[tailleSZ]={0};
    //y = r + z*s
    int indice;
    int l=0;
    int z5, z6;
    for (int i=0; i<tailleZ;i++) {
        int mul[tailleSZ]={0};
        int restantProd=0;
        int valeurtotal=0;
        int restantAdd=0;
        indice=l;
        for (int j=0; j<tailleS;j++) {
            valeurtotal = (((z[tailleZ-1-i]*s[tailleS-1-j])>>0 &0xFF)) + restantProd + restantAdd;
            restantProd = ((z[tailleZ-1-i]*s[tailleS-1-j])>>8 &0xFF) ;
            mul[indice] = (valeurtotal >>0 &0xFF);
            restantAdd = (valeurtotal>>8 &0xFF);
            indice++;
        }
        mul[indice]=restantProd+restantAdd;
        l++;
        z6=0;
        for(int i1=0; i1<tailleSZ;i1++) {
            z5 = mul[i1] + res[i1] + z6;
            res[i1] = (z5>>0 &0xFF);
            z6 = (z5>>8 &0xFF);
         }
    }
    int yprime[tailleY]={0};
    int tmp1 = 0;
    for (int i=0;i<tailleSZ;i++){
        tmp1=r[tailleR-1-i]+res[i]+yprime[i];
        yprime[i] = (tmp1>>0 &0xFF);
        yprime[i+1] =(tmp1>>8 &0xFF);
    }

    for (int i=tailleSZ;i<tailleY;i++) {
        yprime[i]=r[tailleY-1-i];
    }

    tGPS1b *msgOut = new tGPS1b;
    for(int i=0; i<tailleY;i++) {
         msgOut->setY(i,yprime[tailleY-1-i]);
    }
    return msgOut;
}



void AuthenticationTag::replyAES1(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgAesIn = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iAES1 *msgIn = check_and_cast <iAES1 *> (msgAesIn->decapsulate());
//  inRange = fnInRange(lastPosition.x, lastPosition.y, lastPosition.z, msgIn->getSx(), msgIn->getSy(), msgIn->getSz());

    tAES1 *msgAes = new tAES1;

    int input[] = {
            msgIn->getIChallenge(0), msgIn->getIChallenge(1),
            msgIn->getIChallenge(2), msgIn->getIChallenge(3),
            msgIn->getIChallenge(4), msgIn->getIChallenge(5),
            msgIn->getIChallenge(6), msgIn->getIChallenge(7),
            msgIn->getIChallenge(8), msgIn->getIChallenge(9),
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

//  128bit output
    int output[16] = {0};
    int i;

    for (i=0 ; i<176 ; i++)
        RoundKey[i] = 0x00;

    AES128_ECB_encrypt(input, key, output);
    for (i=0; i<16 ;i++) {
        msgAes->setTResponse(i, output[i]);
    }
//  return msgOut;

    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");
    msgOut->encapsulate(msgAes);
    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTAES1);
    send(pktOut,toTag);
//  duration = nbitTAES1/txRate;
//  EV << "send tp:\t" << server->getFullName();
//  sendDirect(msgOut, radioDelay, duration, server->gate("in"));

    delete msgIn;
    delete msgAesIn;
    //1606 ////delete pktIn;;
}

//  Encryption.......
void AuthenticationTag::AES128_ECB_encrypt(int* input, const int* key, int* output)
{
  // Copy input to output, and work in-memory on output
  BlockCopy(output, input);
  state = (state_t*)output;

  Key = key;
  KeyExpansion();

  // The next function call encrypts the PlainText with the Key using AES algorithm.
  Cipher();
}

void AuthenticationTag::BlockCopy(int* output, int* input) {
    int i;
    for (i=0;i<KEYLEN;++i) {
        output[i] = input[i];
    }
}

// This function produces Nb(Nr+1) round keys. The round keys are used in each round to decrypt the states.
void AuthenticationTag::KeyExpansion(void)
{
    int i, j, k, t0, t1, t2, t3;
    int tempa[4]; // Used for the column/row operations
    // The round constant word array, Rcon[i], contains the values given by
    // x to th e power (i-1) being powers of x (x is denoted as {02}) in the field GF(2^8)
    // Note that i starts at 1, not 0).
    int Rcon[] = {
            0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a,
            0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39,
            0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a,
            0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8,
            0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef,
            0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc,
            0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b,
            0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3,
            0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94,
            0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20,
            0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35,
            0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f,
            0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04,
            0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63,
            0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd,
            0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb  };


    // The first round key is the key itself.
    for(i = 0; i < Nk; ++i) {
        t0 = (i*4) + 0;
        t1 = (i*4) + 1;
        t2 = (i*4) + 2;
        t3 = (i*4) + 3;

        RoundKey[t0] = Key[t0];
        RoundKey[t1] = Key[t1];
        RoundKey[t2] = Key[t2];
        RoundKey[t3] = Key[t3];
  }

  // All other round keys are found from the previous round keys.
  for(; (i < (Nb * (Nr + 1))); ++i) {
    for(j = 0; j < 4; ++j) {
      tempa[j]=RoundKey[(i-1) * 4 + j];
    }
    if (i % Nk == 0) {
      // This function rotates the 4 bytes in a word to the left once.
      // [a0,a1,a2,a3] becomes [a1,a2,a3,a0]

      // Function RotWord()
      {
        k = tempa[0];
        tempa[0] = tempa[1];
        tempa[1] = tempa[2];
        tempa[2] = tempa[3];
        tempa[3] = k;
      }

      // SubWord() is a function that takes a four-byte input word and
      // applies the S-box to each of the four bytes to produce an output word.

      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }

      tempa[0] =  (tempa[0] &0xFF) ^ (Rcon[i/Nk] &0xFF);
    }
    else if (Nk > 6 && i % Nk == 4) {
      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }
    }
    RoundKey[i * 4 + 0] = (RoundKey[(i - Nk) * 4 + 0] &0xFF) ^ (tempa[0] &0xFF);
    RoundKey[i * 4 + 1] = (RoundKey[(i - Nk) * 4 + 1] &0xFF) ^ (tempa[1] &0xFF);
    RoundKey[i * 4 + 2] = (RoundKey[(i - Nk) * 4 + 2] &0xFF) ^ (tempa[2] &0xFF);
    RoundKey[i * 4 + 3] = (RoundKey[(i - Nk) * 4 + 3] &0xFF) ^ (tempa[3] &0xFF);
  }
}

// Cipher is the main function that encrypts the PlainText.
 void AuthenticationTag::Cipher(void) {
  int round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(0);

  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for(round = 1; round < Nr; ++round) {
    SubBytes();
    ShiftRows();
    MixColumns();
    AddRoundKey(round);
  }

  // The last round is given below.
  // The MixColumns function is not here in the last round.
  SubBytes();
  ShiftRows();
  AddRoundKey(Nr);
}

int AuthenticationTag::getSBoxValue(int num) {
     // The lookup-tables are marked const so they can be placed in read-only storage instead of RAM
     // The numbers below can be computed dynamically trading ROM for RAM -
     // This can be useful in (embedded) bootloader applications, where ROM is often limited.
   int sbox[] =   {
           //0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F
           0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
           0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
           0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
           0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
           0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
           0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
           0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
           0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
           0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
           0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
           0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
           0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
           0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
           0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
           0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
           0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 };

   return sbox[num];
}

// This function adds the round key to state.
// The round key is added to the state by an XOR function.
void AuthenticationTag::AddRoundKey(int round) {
   int i,j;
   for(i=0;i<4;++i) {
     for(j = 0; j < 4; ++j) {
       (*state)[i][j] = ((*state)[i][j] &0xFF) ^ (RoundKey[round * Nb * 4 + i * Nb + j] &0xFF);
     }
   }
}

// MixColumns function mixes the columns of the state matrix
void AuthenticationTag::MixColumns(void) {
    int i;
    int Tmp,Tm,t;
    for(i = 0; i < 4; ++i) {
      t   = (*state)[i][0];
      Tmp = (*state)[i][0] ^ (*state)[i][1] ^ (*state)[i][2] ^ (*state)[i][3] ;
      Tm  = (*state)[i][0] ^ (*state)[i][1] ; Tm = xtime(Tm);  (*state)[i][0] ^= Tm ^ Tmp ;
      Tm  = (*state)[i][1] ^ (*state)[i][2] ; Tm = xtime(Tm);  (*state)[i][1] ^= Tm ^ Tmp ;
      Tm  = (*state)[i][2] ^ (*state)[i][3] ; Tm = xtime(Tm);  (*state)[i][2] ^= Tm ^ Tmp ;
      Tm  = (*state)[i][3] ^ t ;        Tm = xtime(Tm);  (*state)[i][3] ^= Tm ^ Tmp ;
    }
}

// The ShiftRows() function shifts the rows in the state to the left.
// Each row is shifted with different offset.
// Offset = Row number. So the first row is not shifted.
 void AuthenticationTag::ShiftRows(void) {
  int temp;

  // Rotate first row 1 columns to left
  temp           = (*state)[0][1];
  (*state)[0][1] = (*state)[1][1];
  (*state)[1][1] = (*state)[2][1];
  (*state)[2][1] = (*state)[3][1];
  (*state)[3][1] = temp;

  // Rotate second row 2 columns to left
  temp           = (*state)[0][2];
  (*state)[0][2] = (*state)[2][2];
  (*state)[2][2] = temp;

  temp       = (*state)[1][2];
  (*state)[1][2] = (*state)[3][2];
  (*state)[3][2] = temp;

  // Rotate third row 3 columns to left
  temp       = (*state)[0][3];
  (*state)[0][3] = (*state)[3][3];
  (*state)[3][3] = (*state)[2][3];
  (*state)[2][3] = (*state)[1][3];
  (*state)[1][3] = temp;
}

// The SubBytes Function Substitutes the values in the
// state matrix with values in an S-box.
 void AuthenticationTag::SubBytes(void) {
  int i, j;
  for(i = 0; i < 4; ++i) {
    for(j = 0; j < 4; ++j) {
      (*state)[j][i] = getSBoxValue((*state)[j][i]);
    }
  }
}

int AuthenticationTag::xtime(int x) {
  return ((x<<1) ^ (((x>>7) & 1) * 0x1b));
}

void AuthenticationTag::replyAES2(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgAuthenticate *msgAesIn = check_and_cast <iMsgAuthenticate *> (pktIn->decapsulate());
    iAES2 *msgIn = check_and_cast <iAES2 *> (msgAesIn->decapsulate());

    tAES2 *msgAes = new tAES2;

    //80bit iChallenge + 48bits buffer
    int input[] = {
                msgIn->getIChallenge(0), msgIn->getIChallenge(1),
                msgIn->getIChallenge(2), msgIn->getIChallenge(3),
                msgIn->getIChallenge(4), msgIn->getIChallenge(5),
                msgIn->getIChallenge(6), msgIn->getIChallenge(7),
                msgIn->getIChallenge(8), msgIn->getIChallenge(9),
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    //128bit output
    int output[16] = {0};
    int i;

    int iv[]  = {
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    };

    AES128_CBC_encrypt_buffer(output, input, CBC_BLOCKSIZE, key, iv);

    for (i=0; i<16 ;i++) {
        msgAes->setTResponse(i,output[i]);
    }
//  return msgOut;
    tMsgAuthenticate *msgOut = new tMsgAuthenticate ("Response");

    msgOut->encapsulate(msgAes);
    cPacket *pktOut = new cPacket;
    pktOut->setName("Response");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitTAES2);
    send(pktOut,toTag);
//    duration = nbitTAES2/txRate;
//    EV << "send tp:\t" << server->getFullName();
//    sendDirect(msgOut, radioDelay, duration, server->gate("in"));

//    //1606 ////delete pktIn;; //134
    //delete msgIn;
    ////delete msgAesIn;
    //1606 ////delete msg;
}

void AuthenticationTag::AES128_CBC_encrypt_buffer(int* output, int* input, int length, const int* key, const int* iv) {
  int i;
  int remainders = length % KEYLEN; /* Remaining bytes in the last non-full block */

  BlockCopy(output, input);
  state = (state_t*)output;

  // Skip the key expansion if key is passed as 0
  if(0 != key) {
    Key = key;
    KeyExpansion();
  }

  if(iv != 0) {
    Iv = (int*)iv;
  }

  for(i = 0; i < length; i += KEYLEN) {
    XorWithIv(input);
    BlockCopy(output, input);
    state = (state_t*)output;
    Cipher();
    Iv = output;
    input += KEYLEN;
    output += KEYLEN;
  }

  if(remainders) {
    BlockCopy(output, input);
    memset(output + remainders, 0, KEYLEN - remainders); // add 0-padding
    state = (state_t*)output;
    Cipher();
  }
}

void AuthenticationTag::XorWithIv(int* buf) {
  int i;
  for(i = 0; i < KEYLEN; ++i) {
    buf[i] ^= Iv[i];
  }
}

//bool AuthenticationTag::fnInRange(int x1, int y1, int z1, int x2, int y2, int z2) {
//  double commRange;
//    commRange = sqrt( (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2) + (z1 - z2)*(z1 - z2) );
//    EV <<" range :\t"<<commRange<<endl;
//    if (commRange < maxCommRange)
//        return(true);
//     else return(false);
//}
///////////////////////

void AuthenticationTag::finish() {
//    BYTE sKey[20]= {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
//                    0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13};
//    BYTE sKey[20] = {0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b,
//                     0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b};
//    memset(sKey,0x0b,20);
//    EV << "\nRFC2202\ttest case:\t0xb617318655057264e28bc0b6fb378c8ef146be00\n";
    //SHA1 test_case + SHA1key
//    unsigned char *test = (unsigned char *) "Hi There" ;
//    unsigned char *test = (unsigned char *) "Sample message for keylen<blocklen" ;
//    EV <<"\nTest in Hexa:\t"<< std::strlen((char *)test)<<"\n";
//    dispHEX((char *) test, std::strlen((char *)test));
//    HMAC_SHA1( test, 8, sKey, 20, digest);
//    HMAC_SHA1( test, 34, sKey, 20, digest);
//    EV <<"\n\nfinal digest:\n";
//    dispHEX((char *)digest, SHA1_DIGEST_LENGTH);
//    EV <<"\n Test2:\t4C 99 FF 0C B1 B3 1B D3 3F 84 31 DB AF 4D 17 FC D3 56 A8 07\n";
//    EV << "Expected result:\t0xb617318655057264e28bc0b6fb378c8ef146be00";

}

