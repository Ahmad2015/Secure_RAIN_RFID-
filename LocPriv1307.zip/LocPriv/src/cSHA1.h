//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

/*  ======== Test Vectors (from FIPS PUB 180-1) ========

    SHA1("abc") =
        A9993E36 4706816A BA3E2571 7850C26C 9CD0D89D

    SHA1("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq") =
        84983E44 1C3BD26E BAAE4AA1 F95129E5 E54670F1

    SHA1(A million repetitions of "a") =
        34AA973C D4C4DAA4 F61EEB2B DBAD2731 6534016F
*/

#ifndef __LOCPRIV_CSHA1_H_
#define __LOCPRIV_CSHA1_H_

#include <omnetpp.h>
#include <memory.h> // Needed for memset and memcpy

#define SHA1_LITTLE_ENDIAN
#define SHA1_WIPE_VARIABLES

/////////////////////////////////////////////////////////////////////////////
// Define 8- and 32-bit variables
#define UINT_8 unsigned char
#define UINT_32 unsigned int


// Declare SHA1 workspace
typedef union
{
    UINT_8  c[64];
    UINT_32 l[16];
} SHA1_WORKSPACE_BLOCK;


/**
 * TODO - Generated class
 */
class CSHA1 : public cSimpleModule
{
public:
    UINT_32 m_state[5];
    UINT_32 m_count[2];
    UINT_32 __reserved1[1];
    UINT_8  m_buffer[64];
    UINT_8  m_digest[20];
    UINT_32 __reserved2[3];

    void Reset();
    void Update(UINT_8 *data, UINT_32 len);  // Update the hash value
    void Final();                            // Finalize hash and report
    void GetHash(UINT_8 *puDest);

protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();

    cGate *toHMAC;
    cGate *frHMAC;

private:

    void Transform(UINT_32 *state, UINT_8 *buffer);     // Private SHA-1 transformation

    // Member variables
    UINT_8 m_workspace[64];
    SHA1_WORKSPACE_BLOCK *m_block; // SHA1 pointer to the byte array above

};

#endif
