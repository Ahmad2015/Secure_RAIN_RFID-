//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

    /*
     * RSSI = TxPower - 10 * n * lg(d)
     * n = 2 (in free space)
     *
     * d = 10 ^ ((TxPower - RSSI) / (10 * n))
     */

#include "nodeReader.h"
//#include "command.h"


Define_Module(NodeReader);

void NodeReader::initialize()
{
    EV << "initial reader" << endl;
//  multime = par("multime");
    method              = par("method");
    frameOverhead       = par("frameOverhead");
    preambleDuration    = par("preambleDuration");
    headerBitLength     = par("headerBitLength");
    bitrate             = par("bitrate");
    whichSession        = par("whichSession");
    rAction             = par("rAction");
    rQ                  = par("rQ");
    numTags             = par("numTags");
    csiId               = par("CryptoSuite");
    propagationSpeed    = par("propagationSpeed");

    toRadio             = gate("toRadio");
    frRadio             = gate("frRadio");
    toServer            = gate("toServer");
    toAuth              = gate("toAuth");
    frAuth              = gate("frAuth");

    constraintAreaMaxX  = par("constraintAreaMaxX");
    constraintAreaMaxY  = par("constraintAreaMaxY");;
    maxCoverage         = sqrt((constraintAreaMaxX*constraintAreaMaxX)+(constraintAreaMaxY*constraintAreaMaxY));

    radioModule = gate("toRadio")->getPathEndGate()->getOwnerModule();
    radio1 = check_and_cast<inet::physicallayer::IRadio *>(radioModule);

    //statistics
//  totalCollision      = 0;
//  iterCollision       = 0;
//  totalRequest        = 0;
    totalAuthTime       = 0;
//  numActive           = 0;
    totRepCount         = 0;
    qRepCount           = 0;      //totalQueryRep
    qAdjCount           = 0;      //totalQueryAdjust
    endMethod           = 0;
    isCollision         = false;
    isRecepting         = false;

    for (int i=0;i<(4*numTags);i++) {
        locTime[i] = simTime();
    }

    //initialization
    replied             = false;
    startQuery          = false;

    //used for Query command
    rSel                = par("Sel");           //All/All/~SL/SL
    rSession            = par("Session");       //S0/S1/S2/S3
    rTarget             = par("Target");        //A or B
    CryptoSuite         = par("CryptoSuite");
    slotCounter         = 0;                    //to count the number of slot
    iterQuery           = 0;                    //to count the number of query
    iterQueryRep        = 0;                    //to count the number of queryRep
    iterQueryAdj        = 0;                    //to count the number of QueryAdj

    scheduleAt(simTime(), new cMessage("initialize"));

//    EV <<"\nCoverage:" << maxCoverage << "\nReceptionState:\t IDLE: "<< inet::physicallayer::IRadio::RECEPTION_STATE_IDLE
//            << "\tBUSY: " << inet::physicallayer::IRadio::RECEPTION_STATE_BUSY
//            << "\tRECEIVING: " << inet::physicallayer::IRadio::RECEPTION_STATE_RECEIVING;

    thisNode = inet::getContainingNode(this);
    mod = check_and_cast<inet::IMobility *>(thisNode->getParentModule()->getSubmodule("mobility"));
}

void NodeReader::finish() {

    EV << rXPC((char *)thisNode->getDefaultOwner()->getOwner()->getFullName())
            << " (" << pos.x<<", " << pos.y<<", " << pos.z <<")"
            <<"\tTagActive\t"       << numActive
            <<"\tQ\t"               << rQ
            <<"\tTotal#\t"          << totalRequest
            <<"\tQuery#\t"          << iterQuery
            <<"\tQRep#\t"           << iterQueryRep
            <<"\tQAdj#\t"           << iterQueryAdj
            <<"\tdurWoA\t"          << durWoAuth
            <<"\tdurWA\t"           << durTot
            <<"\tAuthDur\t"         << durTot-durWoAuth
            <<"\t"                  << method
            <<"\tcurrToA: "         << currToa
            <<"\tcurrdistance: "    << currentDistance
            <<"toaEPC: "            << ToaEPC
            <<"toaHandle: "         << ToaHandle;
}

void NodeReader::handleMessage(cMessage *msg) {
//   if (msg->isSelfMessage()) {
       if (strcmp(msg->getName(),"collision") == 0) {
           EV <<"\t\t\t***collision existe: \tone tag already replied:\t"<<replied;
           replied = false;
           cancelEvent(msg);
           iterCollision++;
           EV<<"\titerCollision:\t"<<iterCollision<<endl;
//         slotCounter = 0;
       }
       else if (strcmp(msg->getName(),"queryResponse") == 0) {

           if (iterCollision <= 0 ) { // send ACK if no collision
               rCmdAck();
           }
       }
       else if (strcmp(msg->getName(),"initialize") == 0) {
           EV <<"\n" << thisNode->getDefaultOwner()->getFullName();
           //All Id came from here!!!

           radio1->setRadioMode(inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER);
//           inet::MobilityBase::lastPosition.x = 5;
//           inet::MobilityBase::lastPosition.y = 10;
           pos = mod->getCurrentPosition();

           rMsgPosition *msgOut = new rMsgPosition("readerInitPosition");
           currReaderId = rXPC((char *) msgOut->getDefaultOwner()->getOwner()->getFullName());
           msgOut->setReaderId(currReaderId);
           msgOut->setR_X(pos.x);
           msgOut->setR_Y(pos.y);
           msgOut->setR_Z(pos.z);
           send(msgOut,toServer);

           EV <<"\ni'm R"<<msgOut->getDefaultOwner()->getOwner()->getFullName();
//           EV <<"Reader#"<<rXPC((char *) msgOut->getDefaultOwner()->getOwner()->getFullName())<<"( "<<pos.x<<", "<<pos.y<<", "<<pos.z<<")";
       }
       else if (strcmp(msg->getName(),"endSelect") == 0){
           rCmdChallenge();
       }
  //     else if  ((strcmp(msg->getName(),"waitQuery") == 0) || (strcmp(msg->getName(),"waitChallenge") == 0)) {
       else if  (strcmp(msg->getName(),"waitChallenge") == 0) {
           startQueryTime = simTime();
           slotCounter++;
           totalRequest++;
           iterQuery++;
           rCmdQuery(); // One & only call 13052017
       }
       else if  ((strcmp(msg->getName(),"QueryTimeout") == 0)) {
           slotCounter++;
           // modification as per request on 01122016
           if (method == methodQueryAdj) { //directe QueryAdj
               if (numActive < numTags) {
                   if (iterCollision > 0 ) {
                       totalCollision += iterCollision;
                       iterCollision = 0;
                       replied = false;

                       totalRequest++;
                       iterQueryAdj++;
                       rCmdQueryAdj();
                   } //iterCollision == 0
                   else if (iterCollision == 0 ) {
                       if (slotCounter <= pow(2,rQ)) {
                           totalRequest++;
                           iterQueryRep++;
                           rCmdQueryRep(); //call after timeout in method1
                       }
                       else if (slotCounter > pow(2,rQ)) {
                           slotCounter = 0;
                           totalCollision += iterCollision;
                           iterCollision = 0;
                           replied = false;

                           totalRequest++;
                           iterQueryAdj++;
                           totalRequest++;
                           iterQueryAdj++;
                           rCmdQueryAdj();
                       }
                   }
               }
               else {
                   if (numActive == numTags) {
                       iMsgToServer *msgOut = new iMsgToServer;
                       msgOut->setCsi_ID(csiId);
                       msgOut->setQ(rQ);
                       msgOut->setActiveTags(numActive);
                       msgOut->setTotQRep(iterQueryRep);
                       msgOut->setTotQAdj(iterQueryAdj);
                       msgOut->setTotReq(totalRequest);
                       msgOut->setTotCol(totalCollision);
                       msgOut->setWoutAuth(SIMTIME_DBL(durWoAuth));
                       msgOut->setWithAuth(SIMTIME_DBL(durTot));
                       for (int i=0;i<numTags;i++) {
                           msgOut->setToa(i,SIMTIME_DBL(toaTime[i]));
                       }
                       cPacket *pktOut = new cPacket;
                       pktOut->setName("endReader");
                       pktOut->setBitLength(4);
                       pktOut->encapsulate(msgOut);
                       send(pktOut,toServer);
                       startQuery = false;
                   }
               }
           }
           else if (method == methodQueryRep) { //2 to finish all slots
               EV <<"\nada dlm methodQueryRep\t"<< slotCounter;
               //termine tout les slots avant de passer a QueryAdj
               if (slotCounter <= pow(2,rQ)) { //slotCounter < 2^rQ 1505 tukar <= pada <

                   totalRequest++;
                   iterQueryRep++; //lupa ke? 13052017
                   rCmdQueryRep(); // call after timeout method2
               }
               else { //3 dah abis slot slotCounter > 2^rQ call QueryAdj
                   if (iterCollision > 0 ) {//4a kalau ada collision
                       totalCollision += iterCollision;
                       iterCollision = 0;   // reinitialize
                       slotCounter = 0;     // reinitialize
                       replied = false;     // reinitialize

                       totalRequest++;
                       iterQueryAdj++; //lupa ke? 13052017
                       rCmdQueryAdj();      // if collision, run QueryAdj
                   } //4a
                   else { //4b slotCounter > 2^rQ & no collision
                       if (numActive < numTags) { //5a
                           iterCollision = 0;   // reinitialize 25042017
                           slotCounter = 0;       // reinitialize 25042017
                           replied = false;     // reinitialize 25042017
                           EV << "slotCounter: " << slotCounter
                                   <<"numActive: " << numActive
                                   <<" < " << numTags
                                   <<"collision: " << iterCollision<<"<0\t";
                           totalRequest++;
                           iterQuery++;
                           rCmdQuery(); //add 25042017
                       } //5a
                       else if (numActive == numTags) { //5b tambh &&
                           iMsgToServer *msgOut = new iMsgToServer;
                           msgOut->setCsi_ID(csiId);
                           msgOut->setQ(rQ);
                           msgOut->setActiveTags(numActive);
                           msgOut->setTotReq(totalRequest);
                           msgOut->setTotCol(totalCollision);
                           msgOut->setWoutAuth(SIMTIME_DBL(durWoAuth));
                           msgOut->setWithAuth(SIMTIME_DBL(durTot));
                           for (int i=0;i<numTags;i++) {//6a
                               msgOut->setToa(i,SIMTIME_DBL(toaTime[i]));
                           } //6a
                           cPacket *pktOut = new cPacket;
                           pktOut->setName("endReader");
                           pktOut->setBitLength(4);
                           pktOut->encapsulate(msgOut);
                           send(pktOut,toServer);
                           startQuery = false;
                       } //5b
                   }//4b
               } //3
           }//2
       }
//   } //end of selfmsg
   else if (strcmp(msg->getName(),"startQuery") == 0) {
       slotCounter = 0;
       startQuery = true;
       startOperationTime = simTime();
       //delete msg ;
       rCmdSelect(); //Select Command (1010)
   }
   else if (startQuery == true
           && ((strcmp(msg->getName(),"QueryReply")    == 0)
           ||  (strcmp(msg->getName(),"QueryRepReply") == 0)
           ||  (strcmp(msg->getName(),"QueryAdjReply") == 0))) {
       EV<< "\nQueryReply/QueryRepReply/QueryAdjReply";

       if (replied == true) { //possible collision
           EV<<"\nreplied == true";
           scheduleAt(simTime(), new cMessage("collision"));
           cancelEvent(msg);
           ////delete msg;
       }
       else { // no collision
           EV << "\nreplied == false";

           //int tagId;
           replied = true;
           queryCx = false;
           rcvQueryRepTime = simTime();

           if (strcmp(msg->getName(),"QueryReply") == 0) {
//             processTime = frameOverhead + (nbitQUERY/bitrate) + frameOverhead + (nbitReplyQuery/bitrate);
               processTime = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitQUERY/bitrate) + (nbitReplyQuery/bitrate);
           }
           else if (strcmp(msg->getName(),"QueryRepReply") == 0) {
//             processTime = frameOverhead + (nbitQueryRep/bitrate) + frameOverhead + (nbitReplyQueryRep/bitrate);
               processTime = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitQueryRep/bitrate) + (nbitReplyQueryRep/bitrate);
           }
           else if (strcmp(msg->getName(),"QueryAdjReply") == 0) {
//             processTime = frameOverhead + (nbitQueryAdjust/bitrate) + frameOverhead + (nbitReplyQueryAdjust/bitrate);
               processTime = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitQueryAdjust/bitrate) + (nbitReplyQueryAdjust/bitrate);
           }

           cPacket *pktIn = check_and_cast <cPacket *> (msg);
           tRespond *msgIn = check_and_cast <tRespond *> (pktIn->decapsulate());
           locTagId = msgIn->getId();

           //store tag info in R..
           //tagId = msgIn->getId();
//15/06/2017
         /*  currToa = toaTime[tagId] = (msg->getArrivalTime() - startQueryRepTime - processTime)/2;
           currToa = toaTime[tagId] = (msg->getArrivalTime() - startQueryRepTime)/2;
           currDist = currentDistance = SIMTIME_DBL(toaTime[tagId]*propagationSpeed);
           currentDistance = SIMTIME_DBL(currToa*propagationSpeed);
           distTag[msgIn->getId()] = currentDistance;*/

           //  RE-SENT RN16 RECEIVED FROM TAG.
           RN16tref = msgIn->getRN16();
           simtime_t dur1;
           dur1 = 0.000000061713 + (maxCoverage/propagationSpeed) - (msg->getArrivalTime()) + (msg->getSendingTime());
           scheduleAt(simTime() + dur1, new cMessage("queryResponse"));
//           rCmdQueryResponse(msg); // move to QueryResponse..
           delete msgIn;
       }
   }
   else if (strcmp(msg->getName(),"PC/XPC,EPC") == 0) {
       locTime[locSequence] = msg->getArrivalTime();
       locSequence++;
       EV <<"\nR"<<currReaderId;
//       EV<<"\n\ncubaan dulu: " << msg->getDefaultOwner()->getOwner()->getFullName();
       rCmdReqRN2(msg);
   }
//       simtime_t process_tmp = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitACK/bitrate) + (nbitACKReply/bitrate);
//       ToA2 = (simtime_t) (msg->getArrivalTime() - startLocAck2 - process_tmp)/2;
//       EV <<"\nToA passive positonning: " << ToA2
//          <<"(sec) * " << propagationSpeed
//          <<"(m/s) = " << SIMTIME_DBL(ToA2)*(propagationSpeed) <<"(m)"
//          <<"\nDuree " <<  msg->getArrivalTime() - startLocAck2;
//       currentPosition(ToA2);
/*       simtime_t tmp;
       tmp = SIMTIME_DBL(ToA2*propagationSpeed);
      // currentDistance = SIMTIME_DBL(ToA2*propagationSpeed);

       iMsgManager *msgOut = new iMsgManager ("RTLS");

       for (int i=0; i<16;i++){
          msgOut->setHideEPC128(i,hideEPC128[i]);
       }
       msgOut->setReaderId();
       msgOut->setJarak(currentDistance);
       msgOut->setRX(pos.x);
       msgOut->setRY(pos.y);
       msgOut->setRZ(pos.z);
       msgOut->setToA(SIMTIME_DBL(ToA2));
       msgOut->setRN16(RN16tref);
       send(msgOut,toServer);
   }*/
//   else if ((strcmp(msg->getName(),"clearEPC") == 0) && (startQuery == true)) {
//       rCmdReqRN2(msg);
//   }

   else if (strcmp(msg->getName(),"Handle") == 0) {
       locTime[locSequence] = msg->getArrivalTime();
       locSequence++;
       EV <<"\nR"<<currReaderId;

       msgLocTime *timeUpdateOut = new msgLocTime("timeUpdate");

       timeUpdateOut->setLocTime(SIMTIME_DBL(msg->getArrivalTime()));
       timeUpdateOut->setReaderId(currReaderId);
       timeUpdateOut->setTagId(numActive);
       timeUpdateOut->setTypeOverhead(overhHandle);
       EV <<"\nsending to server from R"
                             <<timeUpdateOut->getDefaultOwner()->getOwner()->getName()
                             <<" \toverheadType: "
                             <<timeUpdateOut->getTypeOverhead()
                             <<endl;
       send(timeUpdateOut,toServer);


       if  (startQuery == true) {
       rCmdHandle(msg);
 //      ToA3 = (simtime_t) msg->getArrivalTime()-startLocRqRn3;

       //currentPosition(ToA3);
/*       simtime_t tmp;
          tmp = SIMTIME_DBL(ToA3*propagationSpeed);
         // currentDistance = SIMTIME_DBL(ToA2*propagationSpeed);

          iMsgManager *msgOut = new iMsgManager ("RTLS");

          for (int i=0; i<16;i++){
             msgOut->setHideEPC128(i,hideEPC128[i]);
          }
          msgOut->setReaderId(currReaderId);
          msgOut->setJarak(currentDistance);
          msgOut->setRX(pos.x);
          msgOut->setRY(pos.y);
          msgOut->setRZ(pos.z);
          msgOut->setToA(SIMTIME_DBL(ToA3));
          msgOut->setRN16(RN16tref);
          send(msgOut,toServer);*/
       }
   }
   else if ((strcmp(msg->getName(),"nextReader") == 0) && (startQuery == true)) {
       // find next tag
       EV <<"\n*****\tReplied:\t"<< replied << (startQuery ? " query started!!" : "query not start!!!")
                                    << (replied ? " replied!!" : "no reply yet!!!");;
       //initialize
       replied = false;
       if (method == methodQueryAdj) {
           slotCounter=0;
           if (slotCounter < pow(2,rQ)) {
               slotCounter++;

               totalRequest++;
               iterQueryRep++; //13052017
               rCmdQueryRep(); //call after found a tag
           }
           else rCmdQuery(); //remove 13052017
       }
       else if (method == methodQueryRep) {
           EV <<"\n** XXX0 **\n"<< slotCounter;
           if (slotCounter < pow(2,rQ)) {
               EV <<"\n** XXX1 **\n"<<slotCounter;
               slotCounter++;

               totalRequest++;
               iterQueryRep++; //13052017
               rCmdQueryRep(); //call after found a tag
           }
           else if ((slotCounter >= pow(2,rQ)) && (iterCollision >0)) {
               EV <<"\n** XXX2 **\n"<<slotCounter;
               slotCounter=0;
               totalCollision += iterCollision;
               iterCollision = 0;
               replied = false;

               totalRequest++;
               iterQueryAdj++;
               totalRequest++;
               iterQueryAdj++;
               rCmdQueryAdj();
           }
           else  {
               if (numActive < numTags) {
                   iterCollision = 0;   // reinitialize 25042017
                   slotCounter = 0;       // reinitialize 25042017
                   replied = false;     // reinitialize 25042017
                   EV << "slotCounter: " << slotCounter
                           <<"numActive: " << numActive
                           <<" < " << numTags
                           <<"collision: " << iterCollision<<"<0\t";
                   totalRequest++;
                   iterQuery++;
                   rCmdQuery(); //add 25042017
               } //5a
               else if (numActive == numTags) { //5b tambh &&
                   iMsgToServer *msgOut = new iMsgToServer;
                   msgOut->setCsi_ID(csiId);
                   msgOut->setQ(rQ);
                   msgOut->setActiveTags(numActive);
                   msgOut->setTotReq(totalRequest);
                   msgOut->setTotCol(totalCollision);
                   msgOut->setWoutAuth(SIMTIME_DBL(durWoAuth));
                   msgOut->setWithAuth(SIMTIME_DBL(durTot));
                   for (int i=0;i<numTags;i++) {//6a
                       msgOut->setToa(i,SIMTIME_DBL(toaTime[i]));
                   } //6a
                   cPacket *pktOut = new cPacket;
                   pktOut->setName("endReader");
                   pktOut->setBitLength(4);
                   pktOut->encapsulate(msgOut);
                   send(pktOut,toServer);
                   startQuery = false;
               }
           }
       }
       //delete msg;
    }
   else if ((strcmp(msg->getName(),"AuthRequest") == 0) && (startQuery == true)) {
      cMessage *pktOut = msg->dup(); //bukan ke?
      pktOut->setName("AuthRequest");
       //EV << "\nAuthRequest";

       if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
          //send(msg,toRadio);
          send(pktOut,toRadio);
          startLocAuth4 = pktOut->getSendingTime();
       }
       else {
           endMethod = 1;
       }
      //delete msg;
   }
   else if (strcmp(msg->getName(),"Response") == 0) {
       locTime[locSequence] = msg->getArrivalTime();
       locSequence++;

//       EV <<"\nsending to server from R" <<timeUpdateOut->getOwner()->getName();
       EV <<"\nR"<<currReaderId<< "with overhead: " << overhResAES1;

       if (startQuery == true){

           cMessage *pktOut = msg->dup();
           send(pktOut,toAuth);
       }
       else {
           msgLocTime *timeUpdateOut = new msgLocTime("timeUpdate");
           timeUpdateOut->setLocTime(SIMTIME_DBL(msg->getArrivalTime()));
           timeUpdateOut->setReaderId(currReaderId);
           timeUpdateOut->setTagId(numActive);
           timeUpdateOut->setTypeOverhead(overhResAES1);
           send(timeUpdateOut,toServer);
       }
   }
   else if ((strcmp(msg->getName(),"Authenticated") == 0) && (startQuery == true)) {
       //totalQuery += qRepCount;
       totRepCount += qRepCount;
       qRepCount=0;
       queryCx = true;

       //statistics
       durTot = simTime() - startOperationTime;
       durQuery = simTime() - startQueryTime;
       durQueryRep = simTime() - startQueryRepTime;
       totalAuthTime = totalAuthTime + (simTime() - startAuthTime);

       //send update to manager
       pos = mod->getCurrentPosition();
//       iMsgManager *msgOut = new iMsgManager ("update");

       //update Server on TagID, ReaderID, distance & reader coordinate
       /*should add
         totalrequest
         WoutAuth = SIMTIME_DBL(durWoAuth);
         WithAuth = SIMTIME_DBL(durTot);
         Toa = SIMTIME_DBL(toaTime); */
//       msgOut->setHostId(currentId);
//       currentPosition(ToA4); //xjln!!! 19062017

       //11/0717
//       for (int i=0; i<16;i++){
//          msgOut->setHideEPC128(i,hideEPC128[i]);
//       }
//       msgOut->setReaderId(currReaderId);
//       msgOut->setJarak(currentDistance);
//       msgOut->setRX(pos.x);
//       msgOut->setRY(pos.y);
//       msgOut->setRZ(pos.z);
//       msgOut->setToA(SIMTIME_DBL(currToa));
//       msgOut->setWiAuth(SIMTIME_DBL(simTime() - queryInitTime));
//       msgOut->setWoAuth(SIMTIME_DBL(currQueryDuration));
 //      msgOut->setRN16(RN16tref);

// 11/07/17 add timeUpdate here

       //found 1 more tag...
//       cPacket *pktOut = new cPacket;
//       pktOut->setName("done!!!");
//       pktOut->encapsulate(msgOut);
//       pktOut->setBitLength(4);
//       send(pktOut,toServer);

       msgLocTime *timeUpdateOut = new msgLocTime("timeUpdate");
       timeUpdateOut->setLocTime(SIMTIME_DBL(msg->getArrivalTime()));
       timeUpdateOut->setReaderId(currReaderId);
       timeUpdateOut->setTagId(numActive);
       timeUpdateOut->setTypeOverhead(overhResAES1);
       timeUpdateOut->setDone(1);
       send(timeUpdateOut,toServer);

       numActive++;
       //add 11/7/17
  //     replied = false;
  //     startQuery = false;
  //     EV << "\n Authenticated and sending"
  //             << msgOut->getRX()<<", " << msgOut->getRY()<<", "<< msgOut->getRZ()<<")"
  //             << " with distance to tag :"<< msgOut->getJarak() << endl;
  //          EV <<"sending to main server fr\t" <<msg->getDefaultOwner()->getOwner()->getFullName();
       //delete msg;
   }
   else if ((strcmp(msg->getName(),"NoAuth") == 0) && (startQuery == true)) {
       qRepCount=0;
       queryCx = true;

       //statistics
       durTot = durWoAuth;
       durQuery = simTime() - startQueryTime;
       durQueryRep = simTime() - startQueryRepTime;

       //send update to manager
       pos = mod->getCurrentPosition();
       iMsgManager *msgOut = new iMsgManager ("update");
       msgOut->setHostId(currentId);

       msgOut->setRN16(RN16tref);
           for (int i=0; i<16;i++){
              msgOut->setHideEPC128(i,hideEPC128[i]);
           }

       msgOut->setReaderId(currReaderId);
       msgOut->setJarak(currentDistance);
       msgOut->setRX(pos.x);
       msgOut->setRY(pos.y);
       msgOut->setRZ(pos.z);
       msgOut->setToA(SIMTIME_DBL(currToa));
       msgOut->setWiAuth(SIMTIME_DBL(simTime() - queryInitTime));
       msgOut->setWoAuth(SIMTIME_DBL(currQueryDuration));

       cPacket *pktOut = new cPacket;
       pktOut->setName("done!!!");
       pktOut->encapsulate(msgOut);
       pktOut->setBitLength(4);
       send(pktOut,toServer);
       EV << "\nsending:\t ("
               << msgOut->getRX()<<", " << msgOut->getRY()<<", "<< msgOut->getRZ()<<")"
               << " with distance to tag :"<< msgOut->getJarak() << endl;
       numActive++;
       //delete msg;
   }
   else if (startQuery == false
           && ((strcmp(msg->getName(),  "QueryReply")    == 0)
             ||  (strcmp(msg->getName(),"QueryRepReply") == 0)
             ||  (strcmp(msg->getName(),"QueryAdjReply") == 0))) {
       cPacket *pktIn   = check_and_cast <cPacket *> (msg);
       tRespond *msgIn  = check_and_cast <tRespond *> (pktIn->decapsulate());
       RN16loc = msgIn->getRN16();
       startLocQueryRep = (simtime_t) msg->getArrivalTime();
       delete msgIn;
   }

   //added for RTLS

       /*
       simtime_t process_tmp = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitACK/bitrate) + (nbitACKReply/bitrate);
       ToaEPC = (startLocEPC - startLocQueryRep - process_tmp)/2;

//       ToApassive1 = (simtime_t) (startLocPassive2 - startLocPassive1)/2 - (nbitACKReply/bitrate) - (nbitReqRNReply/bitrate) - (2*headerBitLength/bitrate) - (2*preambleDuration);
       EV <<"\nDuree" <<  startLocEPC - startLocQueryRep
          <<"\nToA passive positonning: " << ToaEPC
          <<"(sec) * " << propagationSpeed
          <<"(m/s) = " << SIMTIME_DBL(ToaEPC)*(propagationSpeed) <<"(m)";
//     currentPosition(ToApassive1);
       double tmp;
       tmp = SIMTIME_DBL(ToaEPC)*(propagationSpeed);
      // currentDistance = SIMTIME_DBL(ToA2*propagationSpeed);

       iMsgManager *msgOut = new iMsgManager ("RTLS");

       for (int i=0; i<16;i++) {
          msgOut->setHideEPC128(i,msgIn->getHEPC(i));
       }
       msgOut->setReaderId(currReaderId);
       msgOut->setJarak(tmp);
       //msgOut->setRX(pos.x);
       //msgOut->setRY(pos.y);
       //msgOut->setRZ(pos.z);
       msgOut->setToA(SIMTIME_DBL(ToaEPC));
       msgOut->setRN16(RN16loc);
       msgOut->setActiveReader(startQuery);
       send(msgOut,toServer);
   }*/
   else if ((strcmp(msg->getName(),"Handle") == 0) && (startQuery == false)) {
       locTime[locSequence] = msg->getArrivalTime();
       locSequence++;

       msgLocTime *timeUpdateOut = new msgLocTime("timeUpdate");
       timeUpdateOut->setLocTime(SIMTIME_DBL(msg->getArrivalTime()));
       timeUpdateOut->setTagId(numActive);

       send(timeUpdateOut,toServer);

       EV << "Handle:\t";

       for (int i=0; i<16;i++){
           EV << " " << hideEPC128[i];
           }

       startLocHandle = (simtime_t) msg->getArrivalTime();
       simtime_t process_tmp;
       process_tmp = (2*headerBitLength/bitrate) + (2*preambleDuration) + (nbitReqRN/bitrate) + (nbitReqRNReply/bitrate);
       ToaHandle = (startLocHandle- startLocQueryRep - processTime)/2;
       EV << "\nToA passive positioning: " << ToaHandle           <<"(sec) * " << propagationSpeed
          <<"(m/sec) = " << SIMTIME_DBL(ToaHandle)*(propagationSpeed) <<"m";
       double tmp;
       tmp = SIMTIME_DBL(ToaHandle)*(propagationSpeed);
   }
   else if ((strcmp(msg->getName(),"Response") == 0) && (startQuery == false)) {

   }
   delete msg; //134 even when remopve all ////delete msg
}

   void NodeReader::rCmdSelect() {
    iMsgSelect *msgOut = new iMsgSelect;
    cPacket *pktOut = new cPacket;
    msgOut->setName("Select");
    msgOut->setITarget(whichSession); // 000:S0 001:S1 010:S2 011:S3 100:SL from R
    msgOut->setIAction(rAction);
    msgOut->setIMemBank(1); //00:filetype 01:EPC 10:TID 11:File_0
    msgOut->setIPointer(0);
    msgOut->setILength(0);
    msgOut->setIMask(0);
    radio1->setRadioMode(inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER);
    pktOut->encapsulate(msgOut);

    //6.3.2.12
    //QueryRep and ACK have 2-bit command codes beginning with 0
    //Query, QueryAdjust, and Select have 4-bit command codes beginning with 10
    pktOut->setName("Select");
    pktOut->setBitLength(4);
    simtime_t duration = pktOut->getDuration();
    if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
        send(pktOut,toRadio);
    }
    else {
        endMethod = 9;
    }
//    scheduleAt(radio1->getTransmissionInProgress()->getDataEndTime(), new cMessage("waitQuery"));//20122016
    waitTimer = 2*(maxCoverage/propagationSpeed); // aller - retour
    waitSelect = nbitSELECT/bitrate;
    scheduleAt(simTime()+waitTimer+waitSelect, new cMessage("endSelect"));//12102016
}

void NodeReader::rCmdChallenge() {
    cPacket *pktOut = new cPacket;
    iMsgChallenge *msgOut = new iMsgChallenge;

    msgOut->setName("Challenge");
    msgOut->setRFU(0);
    msgOut->setIncRepLen(0);
    msgOut->setImmed(0);
    msgOut->setCSI(AES128ECB);

    pktOut->setName("Challenge");
    pktOut->encapsulate(msgOut);

    radio1->setRadioMode(inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER);

    if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
        send(pktOut,toRadio);
    }
    else {
        endMethod = 100;
    }

    waitTimer = 2*(maxCoverage/propagationSpeed); // aller - retour
    waitChallenge = nbitCHALLENGE/bitrate;
    scheduleAt(simTime()+waitTimer+waitChallenge, new cMessage("waitChallenge"));
}

void NodeReader::rCmdHandle(cMessage *msg) {
    cPacket *pktIn  = check_and_cast <cPacket *> (msg);
    tRespond *msgIn = check_and_cast <tRespond *> (pktIn->decapsulate());
    verify1 = false;

    currentId           = msgIn->getId();
    durWoAuth           = simTime() - startOperationTime;
    currQueryDuration   = simTime() - queryInitTime;

    authPacket *msgOut = new authPacket;
    msgOut->setAuthType(csiId);

    cPacket *pktOut = new cPacket;
    pktOut->setName("authStart");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(4);
    send(pktOut, toAuth);
    startAuthTime = simTime();

    // 23/06/17 send tRefLoc to server
    // requires ReaderId,EPC,RN16
//    msgTRefLoc *msgUpdate = new msgTRefLoc;
//    msgUpdate->setName("TRefLoc");
//    msgUpdate->setTRefLoc( SIMTIME_DBL(pktOut->getSendingTime()));
//    msgUpdate->setRN16(RN16tref);
//    msgUpdate->setReaderId(currReaderId);

//    for (int i =0; i<16; i++) {
//        msgUpdate->setHideEPC128(i,hideEPC128[i]);
//     EV << " " << hideEPC128[i];
//    }
//    send(msgUpdate,toServer);

//    EV << "\nsend to server from R"<<msgUpdate->getReaderId();

    delete msgIn;
}

void NodeReader::rCmdReqRN1(cMessage *msg) {
//  host=msg->getSenderModule();
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    tRespond *msgIn = check_and_cast <tRespond *> (pktIn->decapsulate());

    EV<< "\n\n Receive EPC encrypted\t";
    for (int i=0;i<20;i++) {
        EV<<msgIn->getHEPC(i)<<" ";
    }

    msgHideEPC *pktOut = new msgHideEPC;
    pktOut->setName("decryptECP");
    pktOut->setRN16(msgIn->getRN16());
    for (int i=0; i<16;i++){
       pktOut->setHideEPC128(i,msgIn->getHEPC(i));
    }
    send(pktOut,toAuth);
    EV<< "\nSent to Auth";

    delete msgIn;
}

void NodeReader::rCmdReqRN2(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    tRespond *msgIn = check_and_cast <tRespond *> (pktIn->decapsulate());

    EV<<"\n\ncubaan dulu: " << msgIn->getDefaultOwner()->getOwner()->getFullName()
            <<" " << numActive;

    for (int i=0; i<16;i++){
           hideEPC128[i] = msgIn->getHEPC(i);
        }

    //message to server
      msgLocTime *timeUpdateOut = new msgLocTime("timeUpdate");

      int locReaderId = rXPC( (char *) timeUpdateOut->getDefaultOwner()->getOwner()->getFullName());
      EV <<"\nsending to server from R" << locReaderId;

      if (startQuery == true) {
          for (int i=0; i<16;i++){
              EV<<" " << hideEPC128[i];
              timeUpdateOut->setHideEPC128(i,hideEPC128[i]);
          }

        //message to Tags
        iMsgACK *msgOut = new iMsgACK;
        msgOut->setName("Req_RN");
        msgOut->setRN16(RN16tref);
        msgOut->setBitLength(nbitReqRN);

        cPacket *pktOut = new cPacket;
        pktOut->setName("Req_RN");
        pktOut->encapsulate(msgOut);
        pktOut->setBitLength(nbitReqRN);
        if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
            send(pktOut,toRadio);
            startLocRqRn3 = pktOut->getSendingTime();
        }
        else {
            endMethod = 2;
        }
      }
      timeUpdateOut->setRN16(RN16tref);
      timeUpdateOut->setTypeOverhead(overhEPC);
      timeUpdateOut->setLocTime(SIMTIME_DBL(msg->getArrivalTime()));
      timeUpdateOut->setReaderId(locReaderId);
      timeUpdateOut->setTagId(numActive);
      send(timeUpdateOut,toServer);

      delete msgIn;
}

//need to figure out the owner of the signal
//void NodeReader::rCmdQueryResponse(cMessage *msg) {
//   EV <<"\n\nReception state:\t"<<radio1->getReceptionState()
//           << "\tgate received:\t"<< msg->getArrivalGate();
//   EV <<"\n"<< msgIn->getName()
//      << "\tmsgIn... Tag#"       << msgIn->getId()
//      << "\tcurrent distance:\t" << currentDistance
//      << "\ttime of flight:\t"   << toaTime[tagId]
//      << "\narrivaltime\t"       << msg->getArrivalTime()
//      << "\tstartQueryRepTime\t" << startQueryRepTime
//      << "\tprocessTime\t"       << processTime
//      << "\tduration:\t"         << msgIn->getDuration()
//      << "\ttotalBit:\t"         << msgIn->getBitLength();


//ACK2
 //   if (radio1->getReceptionState() != inet::physicallayer::IRadio::RECEPTION_STATE_RECEIVING) {
      //  if (radio1->getRadioGate() == msg->getArrivalGate()){
 //           rCmdAck();
     //   }
//    }
//}

void NodeReader::rCmdAck() {
    iMsgACK *msgOut = new iMsgACK;
//    currentTransmisson = check_and_cast<inet::physicallayer::ITransmission *>(radio1->getTransmissionInProgress());
//    EV <<"currentTrs:\t"<< currentTransmisson;

    msgOut->setRN16(RN16tref);
    msgOut->setName("ACK");
    cPacket *pktOut = new cPacket;
    pktOut->setName("ACK");
    pktOut->encapsulate(msgOut);
    pktOut->setBitLength(nbitACK);

//    EV << "ACK Reception :\t" << radio1->getReceptionState()
//    << "\n reception in prograss\t " << radio1->getReceptionState()
//    << "\n transmission in progress ends in:\t" << currentTransmisson->getEndTime()
//    << "\n transmission in progress:\t" << currentTransmisson->getMacFrame()->getName();

    if ((radio1->getTransmissionState() == inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING)
     || (radio1->getReceptionState() == inet::physicallayer::IRadio::RECEPTION_STATE_RECEIVING) ) {
        if (radio1->getTransmissionInProgress()->getMacFrame()->isSelfMessage()){
            EV << "\nnodeReader.cc:\tEndTransmission: "<<radio1->getTransmissionInProgress()->getEndTime()<<endl;
            send(pktOut,toRadio);
        }
    }
    else {
        EV << "\nnodeReader.cc/rCmdAck/else: RN16 received: " << RN16tref;
        send(pktOut,toRadio);

        //added 05/07/2017

        locTime[locSequence] = pktOut->getSendingTime();
        locSequence++;

        msgLocTime *timeUpdateOut = new msgLocTime("timeRefUpdate");
        currReaderId = rXPC((char *) timeUpdateOut->getDefaultOwner()->getOwner()->getFullName());
        timeUpdateOut->setReaderId(currReaderId);
//        timeUpdateOut->setTagId(locTagId);
        timeUpdateOut->setTagId(numActive);
        timeUpdateOut->setLocTime(SIMTIME_DBL(pktOut->getSendingTime()));
        send(timeUpdateOut,toServer);
    }
}

void NodeReader::rCmdQueryRep() {

    //not receive or transmit
    if ((radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING)
    && (radio1->getReceptionState() != inet::physicallayer::IRadio::RECEPTION_STATE_RECEIVING)) {
//      qRepCount++;
//      iterQueryRep++;
//      totalRequest++;  //update the number of request
        EV <<"\nqRepCount: "<<qRepCount
                << "\n2. totReq: " <<totalRequest;
        iMsgQueryRep *msgOut= new iMsgQueryRep;
        msgOut->setSession(rSession);
        msgOut->setName("QueryRep");
        cPacket *pktOut = new cPacket;
        pktOut->setName("QueryRep");
        pktOut->encapsulate(msgOut);
        pktOut->setBitLength(nbitQueryRep);
        //16032017
        //simtime_t duration = pktOut->getDuration();
        cMessage *timeOut = new cMessage ("QueryTimeout");
        send(pktOut,toRadio);
        startQueryRepTime = pktOut->getSendingTime();
        EV << "\nstart locate1:\t"<< startQueryRepTime;

//      waitQueryRep = (maxCoverage/propagationSpeed)+frameOverhead+(nbitQueryRep/bitrate)
//                + (maxCoverage/propagationSpeed)+frameOverhead+(nbitReplyQueryRep/bitrate)
//                + (maxCoverage/propagationSpeed);

        waitQueryRep = (3*headerBitLength/bitrate) + (2*preambleDuration) + (2*maxCoverage/propagationSpeed) + (nbitQueryRep/bitrate) + (nbitReplyQueryRep/bitrate);

        scheduleAt(simTime()+waitQueryRep, timeOut);
    }
//    else {
//        scheduleAt(simTime(), new cMessage("Collision"));
//        endMethod = 10;
//    }
}

void NodeReader::rCmdQuery() {
    queryInitTime = simTime(); // to be used to calculate query time for each tag.

    if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
//      iterQuery++;
//      totalRequest++;  //update total request
//      EV << "\ntotReq: " <<totalRequest;

        cPacket *pktOut = new cPacket;
        iMsgQuery *msgOut = new iMsgQuery;
        msgOut->setName("Query");
        msgOut->setSel(rSel);
        msgOut->setSession(rSession);
        msgOut->setTarget(rTarget);
        msgOut->setQ(rQ);

        pktOut->setName("Query");
        pktOut->encapsulate(msgOut);
        pktOut->setBitLength(nbitQUERY);
        simtime_t duration = pktOut->getDuration();
        send(pktOut,toRadio);
        cMessage *timeOut = new cMessage ("QueryTimeout");
        startQueryRepTime = pktOut->getSendingTime();
        EV <<"\n\nStart locate1:\t" << startQueryRepTime;

//      waitQuery = frameOverhead+(nbitQUERY/bitrate)+frameOverhead+(nbitReplyQuery/bitrate)+(2*maxCoverage/propagationSpeed);
        waitQuery = (3*headerBitLength/bitrate) + (2*preambleDuration) + (2*maxCoverage/propagationSpeed) + (nbitQUERY/bitrate)+(nbitReplyQuery/bitrate);
//        EV << "\nframeOverhead: "<< frameOverhead
//             <<"\nnbitQUERY/bitrate: "<< nbitQUERY/bitrate
//             <<"\nnbitReplyQuery/bitrate: "<< nbitReplyQuery/bitrate
//             <<"\nmaxCoverage/propagationSpeed: "<<maxCoverage/propagationSpeed
//             <<"\nwaitQuery"<<waitQuery;
        scheduleAt(simTime()+waitQuery, timeOut);
    }
    else
    {
        scheduleAt(radio1->getTransmissionInProgress()->getEndTime(), new cMessage("collision"));
        endMethod = 8;
    }
}

void NodeReader::rCmdQueryAdj() {
    if (radio1->getTransmissionState() != inet::physicallayer::IRadio::TRANSMISSION_STATE_TRANSMITTING) {
        //iterQueryAdj++;  //cx qAdj#
        qRepCount++;
        qAdjCount++;
        //consider @ x?
//      totalRequest++; //does not take into account queryAdjust as per ssic paper
//      EV <<"\nqAdjCount: "<<qAdjCount
//         << "\n1. totReq: " <<totalRequest;
        totRepCount += qRepCount;
        qRepCount = 0;
        iMsgQueryAdjust *msgOut = new iMsgQueryAdjust;
        msgOut->setName("QueryAdjust");
        msgOut->setSession(rSession);
        msgOut->setUpDn(UNCHANGE);

        cPacket *pktOut = new cPacket;
        pktOut->setName("QueryAdjust");
        pktOut->encapsulate(msgOut);
        pktOut->setBitLength(nbitQueryAdjust);
        simtime_t duration = pktOut->getDuration();
        send(pktOut,toRadio);
        cMessage *timeOut = new cMessage ("QueryTimeout");
        startQueryRepTime = pktOut->getSendingTime();
//      waitQueryAdj = frameOverhead+(maxCoverage/propagationSpeed)+(nbitQueryAdjust/bitrate)+frameOverhead+(maxCoverage/propagationSpeed)+(nbitReplyQueryAdjust/bitrate);
        waitQueryAdj = (3*headerBitLength/bitrate) + (2*preambleDuration)+(2*maxCoverage/propagationSpeed)+(nbitQueryAdjust/bitrate)+(nbitReplyQueryAdjust/bitrate);

        scheduleAt(simTime()+waitQueryAdj, timeOut);

    }
    else {
//12042017        scheduleAt(radio1->getTransmissionInProgress()->getEndTime(), new cMessage("collision"));
        scheduleAt(simTime(), new cMessage("collision"));
        endMethod = 11;
    }
}

int NodeReader::rXPC(char *sig) {
    int res = 0;

    //server[
    int i=7;

    //reader[

    EV << "\n";
    while (sig[i] != ']') {
        res = ((int) sig[i]-48) + (res*10);
        i++;
    }
    return res;
}

void NodeReader::currentPosition(simtime_t ToA){
   double tmp;
   tmp = SIMTIME_DBL(ToA)*(propagationSpeed);
// currentDistance = SIMTIME_DBL(ToA2*propagationSpeed);

   iMsgManager *msgOut = new iMsgManager ("RTLS");

   for (int i=0; i<16;i++){
       msgOut->setHideEPC128(i,hideEPC128[i]);
    }
    msgOut->setReaderId(currReaderId);
    msgOut->setJarak(tmp);
//  msgOut->setRX(pos.x);
//  msgOut->setRY(pos.y);
//  msgOut->setRZ(pos.z);
    msgOut->setToA(SIMTIME_DBL(ToA));
    msgOut->setRN16(RN16tref);
    send(msgOut,toServer);
}
