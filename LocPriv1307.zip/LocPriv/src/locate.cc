//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "locate.h"


Define_Module(Locate);

void Locate::initialize()
{
    // TODO - Generated method body
 //   medium = inet::getModuleFromPar<inet::physicallayer::IRadioMedium>(par("radioMediumModule"), this);
 //    EV << "updateMediumModuleId" << endl;
 //    mediumModuleId = check_and_cast<cModule *>(medium)->getId();

//     radioIn = gate("radioIn");
//     radioIn->setDeliverOnReceptionStart(true);

     toServer   = gate("toServer");
     frServer   = gate("frServer");
     numReaders = par("numReaders");
     numTags    = par("numTags");

     R[0].x = NaN; R[0].y = NaN; R[0].z = NaN;
     R[1].x = NaN; R[1].y = NaN; R[1].z = NaN;
     R[2].x = NaN; R[2].y = NaN; R[2].z = NaN;

     posResult.x = NaN; posResult.y = NaN; posResult.z = NaN;

     iter = 0;
     dist0 = dist1 = dist2 = 0;
}

void Locate::finish() {
   // EV<< "\n d1: "<<dist0<<"\t d2:"<< dist1 <<"\t d3: "<< dist2;
    if (numReaders == 2 ) {
        EV << "\n\nPossibility#1: " << T1 << " & Possibility#2: " << T2;
    } else if (numReaders == 3 ) {
        EV << endl;
        for (int i=0;i<numTags;i++) {
            EV << "\nCoordinate Result#"<<i<<": " << allResults[i];
        }
    } else {
        EV <<"\nOnly " << numReaders << "reader";
    }
}

void Locate::handleMessage(cMessage *msg) {
    // TODO - Generated method body
    if (strcmp(msg->getName(),"readerPosition") == 0) {
        rMsgPosition *msgIn = check_and_cast <rMsgPosition *> (msg);
        //int rId = msgIn->getReaderId());
        R[msgIn->getReaderId()].x = msgIn->getR_X();
        R[msgIn->getReaderId()].y = msgIn->getR_Y();
        R[msgIn->getReaderId()].z = msgIn->getR_Z();
        EV<<"received R# "<<msgIn->getReaderId()
                <<" ("<<R[msgIn->getReaderId()].x<<", "
                << R[msgIn->getReaderId()].y<<", "
                << R[msgIn->getReaderId()].z <<")\n";
        delete msgIn;
    }

    else if (strcmp(msg->getName(),"locate") == 0) {
        msgLocate *pktIn = check_and_cast <msgLocate *> (msg);
        R[0].x = pktIn->getX(0); R[0].y = pktIn->getY(0); R[0].z = pktIn->getZ(0);
        R[1].x = pktIn->getX(1); R[1].y = pktIn->getY(1); R[1].z = pktIn->getZ(1);
        R[2].x = pktIn->getX(2); R[2].y = pktIn->getY(2); R[2].z = pktIn->getZ(2);

        dist0 = pktIn->getDistanceRT(0);
        dist1 = pktIn->getDistanceRT(1);
        dist2 = pktIn->getDistanceRT(2);

        EV <<"\n receive: " << dist0 <<"\t "<< dist1 << "\t " << dist2 <<" for: T"<< pktIn->getTagId();


        if (dist0 <= 0) {               //0xx
            if (dist1 <= 0) {           //00x
                if (dist2 > 0){         //001
                    //R2
                    EV <<"\nReader#"<< pktIn->getReaderId()<<"-> Tag"<< pktIn->getTagId() <<": "<<dist2 ;
                }
            }
            else {                      //01x
                if (dist2 <= 0) {       //010
                    //R1
                    EV <<"\nReader#"<< pktIn->getReaderId()<<"-> Tag"<< pktIn->getTagId() <<": "<<dist1 ;
                }
                else {                  //011
                    //R1 & R2
                    findCirclesIntersections(R[1], R[2], dist1, dist2);
                }
            }
        }
        else {                          //1xx
            if (dist1 <= 0 ) {          //10x
                if (dist2 <= 0) {       //100
                    //R0
                    EV <<"\nReader#"<< pktIn->getReaderId()<<"-> Tag"<< pktIn->getTagId() <<": "<<dist0 ;
                }
                else {                  //101
                    //R0 & R2
                    findCirclesIntersections(R[0], R[2], dist0, dist2);
                }
            }
            else {                      //11x
                if (dist2 <= 0) {       //110
                    //R0 & R1
                    findCirclesIntersections(R[0], R[1], dist0, dist1);
                }
                else {                  //111
                    //R0 & R1 & R2
                    posResult = trilateration(R[0], R[1], R[2], dist0, dist1, dist2);
                    allResults[pktIn->getTagId()] = posResult;
                    EV << "\ncurrResult ("<< posResult.x<<", " << posResult.y<<", " << posResult.z <<")";

                }
            }
        }

 /*
        if (pktIn->getReaderId() == 0) {
                EV <<"\nTag"<< pktIn->getTagId() <<" is "<<dist0 <<"m from Reader#"<< pktIn->getReaderId();
            }
            else if (pktIn->getReaderId() == 1 ) {
                findCirclesIntersections(R1, R2, dist0, dist1);
            }
            else if (pktIn->getReaderId() == 2 ) {
            posResult = trilateration(R1, R2, R3, dist0, dist1, dist2);
            allResults[pktIn->getTagId()] = posResult;
            EV << "\ncurrResult ("<< posResult.x<<", " << posResult.y<<", " << posResult.z <<")";
        }

        if (numReaders == 3) {
            EV << "\n3 Readers";
            posResult = trilateration(R1, R2, R3, dist0, dist1, dist2);
//            allResults[iter] = posResult;
            allResults[pktIn->getTagId()] = posResult;

            lMsgToServer *msgOut = new lMsgToServer;
 //           msgOut->setTagID(iter);
            msgOut->setTagID(pktIn->getTagId());
            msgOut->setX(posResult.x);
            msgOut->setY(posResult.y);
            msgOut->setZ(posResult.z);

            cPacket *pktOut = new cPacket;
            pktOut->setName("frLocate");
            pktOut->encapsulate(msgOut);
            send(pktOut,gate("toServer"));

            EV << "\npossible position - (" <<posResult.x <<", "<< posResult.y <<", "<< posResult.z<<")";
            iter++;
        }
        else if (numReaders == 2 ) {
            EV << "\n2 Readers";
            findCirclesIntersections(R1, R2, pktIn->getR1_Distance(), pktIn->getR2_Distance());
        }*/
        EV <<"\n\n\n"<< numReaders <<"\tCoordinate result : " << posResult;
       delete pktIn;
    }
}

double Locate::norm (inet::Coord p) {
        return pow(pow(p.x,2)+pow(p.y,2),0.5);
}

inet::Coord Locate::trilateration(inet::Coord reader0, inet::Coord reader1, inet::Coord reader2,
        double distanceR0, double distanceR1, double distanceR2) {

    EV << "locate by trilateration:\n R0:("<< reader0.x<<","<< reader0.y<<","<< reader0.z <<")"<<distanceR0
               <<"\nR1:("<< reader1.x<<","<< reader1.y<<","<< reader1.z <<") " << distanceR1
               <<"\nR2:("<< reader2.x<<","<< reader2.y<<","<< reader2.z <<") " << distanceR2;
    inet::Coord resultPose;
    inet::Coord ex;
    inet::Coord ey;
    inet::Coord aux;
    inet::Coord aux2;

    double i;
    double j;
    double x;
    double y;

    //unit vector in a direction from reader0 to reader1
    double r2r1Distance = pow(pow(reader1.x-reader0.x,2) + pow(reader1.y-reader0.y,2),0.5);

    ex = {(reader1.x-reader0.x)/r2r1Distance, (reader1.y-reader0.y)/r2r1Distance};
    aux = {reader2.x-reader0.x,reader2.y-reader0.y};

    //signed magnitude of the x component
    i = ex.x * aux.x + ex.y * aux.y;

    //the unit vector in the y direction.
    aux2 = { reader2.x-reader0.x-i*ex.x, reader2.y-reader0.y-i*ex.y};
    ey = { aux2.x / norm (aux2), aux2.y / norm (aux2) };

    //the signed magnitude of the y component
    j = ey.x * aux.x + ey.y * aux.y;

    //coordinates
    x = (pow(distanceR0,2) - pow(distanceR1,2) + pow(r2r1Distance,2))/ (2 * r2r1Distance);
    y = (pow(distanceR0,2) - pow(distanceR2,2) + pow(i,2) + pow(j,2))/(2*j) - i*x/j;

    //result coordinates
    resultPose.x = reader0.x+ x*ex.x + y*ey.x;
    resultPose.y = reader0.y+ x*ex.y + y*ey.y;
    return resultPose;
}

// Find the points where the two circles intersect.
void Locate::findCirclesIntersections(inet::Coord R1, inet::Coord R2, double radius0, double radius1)
//,    out PointF intersection1, out PointF intersection2)
{
//    inet::Coord T1;
    T1.x = NaN;
    T1.y = NaN;

//    inet::Coord T2;
    T2.x = NaN;
    T2.y = NaN;

    // Find the distance between the centers.
    double dx = R1.x - R2.x;
    double dy = R1.y - R2.y;
    double dist = sqrt(dx * dx + dy * dy);

    // See how many solutions there are.
    if (dist > radius0 + radius1)
    {
        EV << "No solutions, the circles are too far apart";
        //return 0;

    }
    else if (dist < std::abs(radius0 - radius1))
    {
        EV << "No solutions, one circle contains the other";
        //return 0;
    }
    else if ((dist == 0) && (radius0 == radius1))
    {
        EV << "No solutions, the circles coincide";
        //return 0;
    }
    else
    {
        // Find a and h.
        double a = (radius0 * radius0 - radius1 * radius1 + dist * dist) / (2 * dist);
        double h = sqrt(radius0 * radius0 - a * a);

        // Find P2.
        double cx2 = R1.x + a * (R2.x - R1.x) / dist;
        double cy2 = R1.y + a * (R2.y - R1.y) / dist;

        // Get the points P3.
        T1.x = (cx2 + h * (R2.y - R1.y) / dist);
        T1.y = (cy2 - h * (R2.x - R1.x) / dist);
        T2.x = (cx2 - h * (R2.y - R1.y) / dist);
        T2.y = (cy2 + h * (R2.x - R1.x) / dist);

        // See if we have 1 or 2 solutions.
        if (dist == radius0 + radius1) {
            EV << "\n\nCoordinate result1 : " << T1;
            //return 1;
        } else {
            EV << "\n\nCoordinate result1 : " << T1 <<" or " << T2;
            //return 2;
        }
    }
}
