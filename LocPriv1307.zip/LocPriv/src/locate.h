//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_LOCATE_H_
#define __LOCPRIV_LOCATE_H_

#include <omnetpp.h>
#include "AllMsg_m.h"
#include "inet/physicallayer/contract/packetlevel/IRadioMedium.h"
#include "inet/common/ModuleAccess.h"
#include "inet/physicallayer/common/packetlevel/RadioMedium.h"


/**
 * TODO - Generated class
 */
class Locate : public cSimpleModule
{
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
    virtual double norm(inet::Coord p);
    virtual inet::Coord trilateration(inet::Coord reader1, inet::Coord reader2, inet::Coord reader3,
            double distanceR1, double distanceR2, double distanceR3);
    virtual void findCirclesIntersections(inet::Coord R1, inet::Coord R2, double radius0, double radius1);


    /**
     * The radio medium model is never nullptr.
     */
//    inet::physicallayer::IRadioMedium *medium = nullptr;

    /**
     * The module id of the medim model.
     */
//    int mediumModuleId = -1;

//    cGate *radioIn = nullptr;
    inet::Coord T1;
    inet::Coord T2;

    inet::Coord R[3];
    inet::Coord posResult;

    cGate *toServer;
    cGate *frServer;
    int numReaders;
    int numTags;
    int iter;
    inet::Coord allResults[501];

    double dist0;
    double dist1;
    double dist2;



};

#endif
