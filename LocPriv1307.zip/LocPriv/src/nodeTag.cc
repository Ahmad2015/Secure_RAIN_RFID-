//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

/* 6.3.2.1.2.2 Protocol Control
 *  StoredPC in 10h - 1Fh of EPC memory (15bits)
 *     MSB                                                       LSB
 *      | 10h | 11h | 12h | 13h | 14h | 15h | 16h | 17h | 18h-1Fh |
 *  EPC | L4  | L3  | L2  | L1  | L0  | UMI | XI  | T=0 | RFU     |
 *
 *  -> L4-L0: EPC Length
 *  o 00000: Zero words.
 *  o 00001: One word (addresses 20h to 2Fh in EPC memory).
 *  o 00010: Two words (addresses 20h to 3Fh in EPC memory).
 *   .
 *   .
 *  o 111112: 31 words (addresses 20h to 20Fh in EPC memory).
 *
 *  -> UMI 15h: User Memory Indicator
 *  0: could allocate memory in file_0
 *  1: could not allocate memory in file_0
 *
 *  -> XI (XPC_W1 16h):
 *  o 0: if w/o XPC_W1
 *  o logical OR of bits (210n-21Fh) or (210h-218h) of EPC, chose by manufacturer
 *
 *  -> T (numbering system identifier toggle, 17h)
 *  o 0: GS1 EPCglobal
 *  o 1: non GS1 ECPGlobal
 *
 *  -> RFU (18h – 1Fh):
 *  o 00h if "T=0"
 *  ISO/IEC 15961 if "T=1"
 *
 *
 *  EPC 20h-210h total 496bits
 */

#include "nodeTag.h"

Define_Module(NodeTag);

void NodeTag::initialize()
{
    //currMsg = NULL;
    // TODO - Generated method body
    toRadio = gate("toRadio");
    frRadio = gate("frRadio");
    toAuth  = gate("toAuth");
    frAuth  = gate("frAuth");
//  toHMAC = gate("toHMAC");
//  frHMAC = gate("frHMAC");
    hideTag = par("hideTag");

    csiId = par("CryptoSuite");
    //cmdQuery
    tSession     = 0;
    tOldSession  = 0;
    tQ           = 0;
    tSel         = 0;   //ALL/ALL/~SL/SL
    tState       = READY;
    tSlotCounter = 999;

    //tSlotCounter = rand() %15;
    //Session & Target
    for (int i=0; i<4 ;i++) {
        // tagInventory[0]:S0   tagInventory[1]:S1  tagInventory[2]:S2  tagInventory[3]:S3
        // value A/B/SL/~SL
        tagInventory[i] = 0;
    }

    tMemBank   = 1;
    tPointer   = 0;
    tLength    = 0;
    tMask      = 0;
//  queryReplied = false;
    startReply = false;
    startAuth  = false;

    radioModule = gate("toRadio")->getPathEndGate()->getOwnerModule();
    radio = check_and_cast<inet::physicallayer::IRadio *>(radioModule);
    scheduleAt(simTime(), new cMessage("init"));
    EV<< "\nwhichSession: "   << whichSession
            << "\ttMemBank: " << tMemBank
            << "\ttPointer: " << tPointer
            << "\ttLength: "  << tLength
            << "\ttMask: "    << tMask
            << "tState: "     << tState<<endl;

    thisNode = inet::getContainingNode(this);
    mod = check_and_cast<inet::IMobility *>(thisNode->getSubmodule("mobility"));

    EV << thisNode->getParentModule()->getSubmodule("tag");
    EV <<"\nposition:\t"<< pos.x << " " << pos.y ;
}

void NodeTag::finish() {
    pos = mod->getCurrentPosition();
    EV <<"\nTag#"<< gsEPC96[10]*16 + gsEPC96[11]
    <<" Real tag coordinate: (" << pos.x <<"," <<pos.y<<","<<pos.z<<")\t";
}

void NodeTag::handleMessage(cMessage *msg) {
    //currMsg = msg;
    EV <<"\n***** handleMessage tag:\t"<<msg->getName()<<"\tfrom:\t"<<msg->getOwner()->getName()<<"\tState"<<tState<<endl;
    // TODO - Generated method body
    if (strcmp(msg->getName(),"init") == 0) {
        radio->setRadioMode(inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER);
        id = tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName());
        gsEPC96[11] = id;
    }
    else if ( strcmp(msg->getName(), "Select")      == 0) {
        tCmdSelect(msg);

    }
    else if ( strcmp(msg->getName(), "Challenge")   == 0) {
        tCmdChallenge(msg);

    }
    else if ((strcmp(msg->getName(), "Query")       == 0) && (!startReply)) {
        tCmdQueryReply(msg);

    }
    else if (strcmp(msg->getName(), "QueryRep")    == 0) {
        tCmdQueryRepReply(msg);

    }
    else if (strcmp(msg->getName(), "QueryAdjust") == 0) {
        tCmdQueryAdjust(msg);

    }
    else if ((strcmp(msg->getName(), "ACK")         == 0)) {
        EV<< "\n\nreceivedACK\n";
        tCmdPcXpcEpc1(msg);

    }
    else if ((strcmp(msg->getName(), "Req_RN") == 0) && (startReply)) {
        tCmdReqRNReply(msg);

    }
    else if ((strcmp(msg->getName(), "AuthRequest") == 0) && (startReply))  {
        EV << "\n\n*****************Authenticate for:\t"<< csiId <<"\ttState:\t"<<tState <<"msg:\t"<<msg->getFullName();
        if ((tState == OPEN) || (tState == SECURED)) {
            startAuth = true;
            cMessage *pktOut = msg->dup();
            send(pktOut,toAuth);
            }
        else if ((tState == ARBITRATE)
                    || (tState == REPLY)
                    || (tState == ACKNOWLEDGED)) {
            tState = ARBITRATE;
            EV << "\n*****ARBITRATE/REPLY/ACKNOWLEDGED";
        }
        else if ((tState == READY) || (tState == KILLED)) {
            EV << "READY/KILLED";
        }

    }
    else if ((strcmp(msg->getName(),"Response") == 0) && (startReply) && (startAuth == true)) {
        EV << "\nthis->getFullPath():\t" << this->getFullPath() << "\tmsg->getSenderModule()"<<msg->getSenderModule();
        EV <<"\nback from authenticationTag module:\t" ;
        startAuth = false;
        cMessage *pktOut = msg->dup();
        send(pktOut,toRadio);

    }
    else if (strcmp(msg->getName(),"doneHideEPC") == 0 ) {
        EV <<"\nBack to tag\n";
        tCmdPcXpcEpc2(msg);
    }
    else cancelEvent(msg);

    EV <<"\nIn nodeTag\t"<< msg->getName()<<endl;
    delete msg;
}


void NodeTag::tCmdQueryAdjust(cMessage *msg) {
    //6.3.2.12.2.2
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgQueryAdjust *msgIn = check_and_cast <iMsgQueryAdjust *> (pktIn->decapsulate());
    EV <<"\ntState:\t"<<tState <<"\tOldSession:\t"<<tOldSession <<"Session:\t"<<msgIn->getSession();
    if ((tState == READY) || (tState == KILLED)) {
        tState = READY;
    }
    else if ((tState == ARBITRATE) || (tState == REPLY) ) {
        //EV << "tOldSession: " << tOldSession;
        if (msgIn->getSession() == tOldSession) {
            if (msgIn->getUpDn() == UPq) {
                if (tQ<15)
                    tQ++;   //slot counter ++
            }
            else if (msgIn->getUpDn() == DOWNq) {
                if (tQ>0) {
                    tQ--;   //slot counter --
                    }
            }
            // 2^tQ
            int limit;
//            limit = pow(2,tQ) -1;
            limit = pow(2,tQ);
            //slotCounter [0,2^Q -1]
            if (limit == 0) {
                EV << "\nlimit ==1";
                tSlotCounter = 0;
            }
            else {
                //          tSlotCounter = rand() %limit;
                //          tSlotCounter = rand() %10; // * FOR SIMULATION PURPOSE
                tSlotCounter = intrand(limit);
            }
            if (tSlotCounter <= 0) {
//                tRN16 = rand() %65535;
                tRN16 = intrand(65535);

                tRespond *msgOut = new tRespond;

                msgOut->setName("QueryAdjReply");
                msgOut->setRN16(tRN16);
                msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));

                cPacket *pktOut = new cPacket;
                pktOut->setName("QueryAdjReply");
                pktOut->encapsulate(msgOut);
                pktOut->setBitLength(nbitRespond);
                send(pktOut,toRadio);
//                scheduleAt(simTime()+(0.000000001),pktOut);
                tState = REPLY;
                queryReplied = true;
                startReply = true;

            } else {
                tState = ARBITRATE;
    //        EV << "ARTBIT3";
            }
        }
    }
    else if ((tState == ACKNOWLEDGED) || (tState == OPEN) || (tState == SECURED)) {
        if (msgIn->getSession() == tOldSession) {
            if (tagInventory[whichSession] == SessionA) {tagInventory[whichSession] = SessionB;}
            else {tagInventory[whichSession] = SessionA;}
            tState = READY;
        }
    }
    delete msgIn; //1705
}

void NodeTag::tCmdReqRNReply(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgACK *msgIn = check_and_cast <iMsgACK *> (pktIn->decapsulate());

    EV << "***\t\t\t*** receiving:\t" << msgIn->getRN16() <<" vs " << tRN16<<endl;
//    EV <<"\nduration: " << pktIn->getDuration();

    if (tState == ACKNOWLEDGED) {
        if (msgIn->getRN16() == tRN16) {
            tRespond *msgOut = new tRespond;
            //tRN16 = rand() %65535;
            msgOut->setName("Handle");
            msgOut->setRN16(tRN16);
//          msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));

            cPacket *pktOut = new cPacket;
            pktOut->setName("Handle");
            pktOut->encapsulate(msgOut);
            pktOut->setBitLength(nbitReqRNReply);
            send(pktOut,toRadio);
 //         queryReplied = false; //initialize semula;
 //         startReply = false;

//**** for simulation purpose
            if (tAccessPwd == 0) {
                tState = SECURED;
            }
            else {
                tState = OPEN;
            }
        }
    //nak tau status akhir
        EV<< "\nwhichSession: " << whichSession
                <<"\ttMemBank: "<<tMemBank
                <<"\ttPointer: "<<tPointer
                <<"\ttLength: "<<tLength
                <<"\ttMask: "<<tMask
                <<"\ttState: "<<tState<<endl;

    }
    else if ((tState == OPEN) || (tState == SECURED)) {

        //send new RN16
        tRespond *msgOut = new tRespond;
//        tRN16 = rand() %65535;
        tRN16 = intrand(65535);

        msgOut->setName("Handle");
        msgOut->setRN16(tRN16);
        msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));

        cPacket *pktOut = new cPacket;
        pktOut->setName("Handle");
        pktOut->encapsulate(msgOut);
        pktOut->setBitLength(nbitReqRNReply);
        send(pktOut,toRadio);
 //       queryReplied = false; //initialize semula;
//        startReply = false;
    }
    else if (tState == REPLY) {
  //      EV <<"ARBT6";
        tState = ARBITRATE;
    }
    delete msgIn;
}

void NodeTag::tCmdPcXpcEpc1(cMessage *msg) {
    EV<<"within tCmdPcXpcEpc1"<<endl;
    queryReplied = true;
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgACK *msgIn = check_and_cast <iMsgACK *> (pktIn->decapsulate());

    if (hideTag == 1) {
        if ((tState == REPLY) || (tState == ACKNOWLEDGED)) {
            if (tRN16 == msgIn->getRN16()) {
                tState = ACKNOWLEDGED;
                msgHideEPC *pktOut = new msgHideEPC;
                pktOut->setName("hideEPC1");
                pktOut->setRN16(msgIn->getRN16());
                for (int i=0; i<sizeEPC;i++){
                    pktOut->setEPC96(i,gsEPC96[i]);
                }
                EV <<"\n\nnodeTag: send to Authentication\n";
                send(pktOut,toAuth);
            }
        }
    }
    else if (hideTag == 2 ) {
        if ((tState == REPLY) || (tState == ACKNOWLEDGED)) {
            EV <<"\tOriginal EPC: ";
            for (int i=0;i<12;i++){
                EV << gsEPC96[i] <<" ";
            }
            //EV <<"RN16: "<<tRN16<<" "<<(int) highByte(tRN16)<<" "<<(int) lowByte(tRN16)<<endl;

            //gsEPC96[10] = gsEPC96[10] ^ highByte(tRN16);
            //gsEPC96[11] = gsEPC96[11] ^ lowByte(tRN16);

            //send to authentication "hideEPC2"
            msgHideEPC *pktOut = new msgHideEPC;
            pktOut->setName("hideEPC2");
            pktOut->setRN16(msgIn->getRN16());
            for (int i=0; i<10;i++){
                pktOut->setEPC96(i,gsEPC96[i]);
            }

            //EPC^RN16
            pktOut->setEPC96(10,gsEPC96[10] ^ highByte(tRN16));
            pktOut->setEPC96(11,gsEPC96[11] ^ highByte(tRN16));
            send(pktOut,toAuth);

            EV <<"\nEPC^RN16: ";
            for (int i=0;i<sizeEPC;i++){
                EV << pktOut->getEPC96(i) <<" ";
            }
        }
    }
    delete msgIn;
    /*

    if ((tState == REPLY) || (tState == ACKNOWLEDGED)) {
        if (tRN16 == msgIn->getRN16()) {
            tState = ACKNOWLEDGED;
            /////////////////////////////////////send XPC////////////////////////////
            tRespond *msgOut = new tRespond;
            EV <<"\nACKNOWLEDGED\n";
            msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));
            EV <<"\n\nHMAC-SHA1:\t";
            for (int i=0;i<20;i++) {
                if (i % 10 == 0 ) EV<<"\n";
                EV <<" <" <<hmSHA1[i]<<"> ";
                msgOut->setHSHA1(i,hmSHA1[i]);
            }
//            msgOut->setId(digest);
            msgOut->setName("PC/XPC,EPC");

            cPacket *pktOut = new cPacket;
            pktOut->setName("PC/XPC,EPC");
            pktOut->encapsulate(msgOut);
            pktOut->setBitLength(nbitACKReply);
            send(pktOut,toRadio);
        }
        else {
            tState = ARBITRATE;
 //       EV << "tState = ARBITRATE";
        }
    }
    else if ((tState == OPEN) || tState == SECURED) {
  //      EV << "OPEN/SECURED";
        if (tHandle == msgIn->getRN16()) {
            EV <<"\nOPEN/SECURED\n";
            //send XPC
            tRespond *msgOut = new tRespond;
            msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));
            msgOut->setName("PC/XPC,EPC");

            cPacket *pktOut = new cPacket;
            pktOut->setName("PC/XPC,EPC");
            pktOut->encapsulate(msgOut);
            pktOut->setBitLength(nbitACKReply);
            send(pktOut,toRadio);
        }
        else {
    //        EV << "ARBT2";
            tState = ARBITRATE;
        }
    }
    delete msgIn;*/
}

void NodeTag::tCmdPcXpcEpc2(cMessage *msg) {
    msgHideEPC *msgIn = check_and_cast <msgHideEPC *> (msg);
    EV<<"\ntag Received: ";
    for (int i=0;i<16;i++) {
        EV<<msgIn->getHideEPC128(i)<<" ";
    }

    if ((tState == REPLY) || (tState == ACKNOWLEDGED)) {
           if (tRN16 == msgIn->getRN16()) {
               tState = ACKNOWLEDGED;
               if (hideTag == 1) {
                   tRespond *msgOut = new tRespond;
                   msgOut->setName("PC/XPC,EPC");
                   for (int i=0;i<16;i++) {
                       msgOut->setHEPC(i,msgIn->getHideEPC128(i));
                   }
                   cPacket *pktOut = new cPacket;
                   pktOut->setName("PC/XPC,EPC");
                   pktOut->encapsulate(msgOut);
                   pktOut->setBitLength(nbitACKReply);
                   send(pktOut,toRadio);
               }
               else if (hideTag == 2) {
                   tRespond *msgOut = new tRespond;
                   msgOut->setName("PC/XPC,EPC");
                   for (int i=0;i<16;i++) {
                       msgOut->setHEPC(i,msgIn->getHideEPC128(i));
                   }
                   cPacket *pktOut = new cPacket;
                   pktOut->setName("PC/XPC,EPC");
                   pktOut->encapsulate(msgOut);
                   pktOut->setBitLength(nbitACKReply);
                   send(pktOut,toRadio);
               }
           }
           else tState = ARBITRATE;
    }
    else if ((tState == OPEN) || tState == SECURED) {
        if (tHandle == msgIn->getRN16()) {
            EV <<"\nOPEN/SECURED\n";
            //send XPC
            if (hideTag == 2) {
                tRespond *msgOut = new tRespond;
                msgOut->setName("PC/XPC,EPC");
                for (int i=0;i<16;i++) {
                    msgOut->setHEPC(i,msgIn->getHideEPC128(i));
                }
                cPacket *pktOut = new cPacket;
                pktOut->setName("PC/XPC,EPC");
                pktOut->encapsulate(msgOut);
                pktOut->setBitLength(nbitACKReply);
                send(pktOut,toRadio);
            }
            else {
                tRespond *msgOut = new tRespond;
                msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));
                msgOut->setName("PC/XPC,EPC");

                cPacket *pktOut = new cPacket;
                pktOut->setName("PC/XPC,EPC");
                pktOut->encapsulate(msgOut);
                pktOut->setBitLength(nbitACKReply);
                send(pktOut,toRadio);
            }
        }
    }
}


void NodeTag::tCmdQueryRepReply(cMessage *msg){
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgQueryRep *msgIn = check_and_cast <iMsgQueryRep *> (pktIn->decapsulate());
 //   EV <<"\nduration: " << pktIn->getDuration();

    if (msgIn->getSession() == tSession) {
        if (tState == ARBITRATE) {
            EV <<"tSlotCounter:\t"<<tSlotCounter;
            tSlotCounter--;
            EV <<"\nnew slotcounter:\t"<<tSlotCounter;
            if (tSlotCounter == 0) {
                tRespond *msgOut = new tRespond ("QueryRepReply");
                tState=REPLY;
//                tRN16 = rand() %65535;
                tRN16 = intrand(65535);
                //send new RN16
                msgOut->setRN16(tRN16);
                msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));
                //msgOut->setBitLength(nbitReplyQueryRep);

                cPacket *pktOut = new cPacket;
                pktOut->setName("QueryRepReply");
                pktOut->encapsulate(msgOut);
                pktOut->setBitLength(nbitReplyQueryRep);
                send(pktOut,toRadio);
            }
            EV << "\t***slotcounter:\t"<<tSlotCounter<<"\t RN16:\t"<<tRN16<<"\tSTATE:\t"<<tState;
        }
        else if (tState == REPLY) {
            tState = ARBITRATE;
            EV << "ARBT 4 \tSTATE:\t"<<tState;
        }
        else if ((tState == ACKNOWLEDGED) || (tState == OPEN) || (tState == SECURED)) {
            tState = READY;
            if (tagInventory[whichSession] == SessionA)
                tagInventory[whichSession] = SessionB;
            else
                tagInventory[whichSession] = SessionA;
        }
    }
    startReply = true;
    EV << "state when reply:\t" << tState;
    delete msgIn;
}

void NodeTag::tCmdSelect(cMessage *msg) {
    EV << "\nreply to select"<<endl;
    int rAction;
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgSelect *msgIn = check_and_cast <iMsgSelect *> (pktIn->decapsulate());
    EV << "\nmsgSelect:\t" << msgIn->getITarget();

    tState = READY; //return to READY
    startAuth = false;
    startReply = false;

    whichSession = msgIn->getITarget(); //  S0/S1/S2/S3
    rAction = msgIn->getIAction(); // [0:7]
    EV <<"rAction" << rAction;
    //6.3.2.2 Sessions and inventoried flags
    if ((tMemBank == msgIn->getIMemBank())
            && (tPointer == msgIn->getIPointer())
            && (tLength == msgIn->getILength())
            && (tMask == msgIn->getIMask())) {
        EV << "\ntag match";

        // tagInventory[0]:S0   tagInventory[1]:S1  tagInventory[2]:S2  tagInventory[3]:S3 -> value A/B/SL/~SL
        if (rAction == 0)       {tagInventory[whichSession] = SessionA;}
        else if (rAction == 1)      {tagInventory[whichSession] = SessionA;}
        else if (rAction == 3)      {if (tagInventory[whichSession] == SessionA)    tagInventory[whichSession] = SessionB; else tagInventory[whichSession] = SessionA;}
        else if (rAction == 4)      {tagInventory[whichSession] = SessionB;}
        else if (rAction == 5)      {tagInventory[whichSession] = SessionB;}
    }
    else {
        if (rAction == 0)       {tagInventory[whichSession] = SessionB;}
        else if (rAction == 2)      {tagInventory[whichSession] = SessionB;}
        else if (rAction == 4)      {tagInventory[whichSession] = SessionA;}
        else if (rAction == 6)      {tagInventory[whichSession] = SessionA;}
        else if (rAction == 7)      {if (tagInventory[whichSession] == SessionA)    tagInventory[whichSession] = SessionB; else tagInventory[whichSession] = SessionA;}
    }
delete msgIn;
}

void NodeTag::tCmdChallenge(cMessage *msg) {
    cPacket *pktIn = check_and_cast <cPacket *>(msg);
    iMsgChallenge * msgIn = check_and_cast<iMsgChallenge *>(pktIn->decapsulate());
  //  int challID;
    if (msgIn->getCSI() == AES128CBC){
        //AES
    }
    else if (msgIn->getCSI() == GPSCCR){
        //GPS
    }
    else if (msgIn->getCSI() == XOR){
        //XOR
    }
    delete msgIn;
    //1606 //
}

void NodeTag::tCmdQueryReply(cMessage *msg) {
    EV << "\nstart to process reply to Query in tCmdQueryReply, entry tSTATE:\t" << tState <<endl;
    cPacket *pktIn = check_and_cast <cPacket *> (msg);
    iMsgQuery *msgIn = check_and_cast <iMsgQuery *> (pktIn->decapsulate());
    EV <<"\nduration: " << pktIn->getDuration();

    // Select:All/All/~SL/SL
    // Session:S0/S1/S2/S3
    // Target: A/B
        if ((msgIn->getSel() == tSel) && (msgIn->getTarget() == tagInventory[whichSession])) {
            tQ = msgIn->getQ();
        //2^tQ
            int limit;
//            limit = pow(2,tQ) - 1;
            limit = pow(2,tQ);

        //slotCounter [0,2^Q -1]
            if (limit > 0) {
//                tSlotCounter = rand() %(limit);
                tSlotCounter = intrand(limit);
            }
            else {
                tSlotCounter = 0;
            }
            tOldSession = msgIn->getSession();

            if ((tState == READY) || (tState == ARBITRATE) || (tState == REPLY)) {
        // refer to pg 125 gen2v2
                if (tSlotCounter == 0) tState = REPLY;
                else {
                    tState = ARBITRATE;
                    EV <<"ARBT5";
                }
            }
            else if ((tState == ACKNOWLEDGED) ||(tState == OPEN) || (tState == SECURED)) {
                if (msgIn->getSession() == tOldSession) {
                    if (tagInventory[whichSession] == SessionA) tagInventory[whichSession] = SessionB;
                    else tagInventory[whichSession] = SessionA;

                    if (tSlotCounter == 0) tState = REPLY;
                    else {tState = ARBITRATE;
                    EV << "ARBT6";}
                }
            }
        }
        else {
            EV << "\nSel & Target NOT Match!!! Session :\t"
                    << whichSession
                    <<"\t"
                    << msgIn->getSel() << " vs " << tSel
                    <<" Target: " << msgIn->getTarget()
                    << " vs "
                    <<tagInventory[whichSession];
            if (msgIn->getSession() == tOldSession) {
                if (tagInventory[whichSession] == SessionA) tagInventory[whichSession] = SessionB;
                else tagInventory[whichSession] = SessionA;
            }
        }
        EV << "\n\ntState:\t"<<tState<< endl;
        if (tState == REPLY) {

            EV<<"***\t\t\t*** sending RN16:\t" <<tRN16<<"***\n";
            tRespond *msgOut = new tRespond;
//            tRN16 = rand() %65535;
            tRN16 = intrand(65535);
            msgOut->setRN16(tRN16);
            msgOut->setName("QueryReply");
            msgOut->setId(tXPC((char *) msg->getDefaultOwner()->getOwner()->getFullName()));

            cPacket *pktOut = new cPacket;
            pktOut->setName("QueryReply");
            pktOut->encapsulate(msgOut);
            pktOut->setBitLength(nbitReplyQuery);
            send(pktOut,toRadio);
//          queryReplied = true;
            startReply = true;
        }
        EV << "\n\ntState:\t"<<tState <<"\nCmdQueryReply slotcounter"<<tSlotCounter<<"\tQ:\t" <<tQ<<endl;
        delete msgIn;
        //
        //
}

int NodeTag::tXPC(char *sig) {
    int res = 0;

    //host[
    //int i=5;

    //tag[
    int i=4;


    EV << "\n";
    while (sig[i] != ']') {
        res = ((int) sig[i]-48) + (res*10);
        i++;
    }
    return res;
}








//  radio->setRadioMode(fullDuplex ? inet::physicallayer::IRadio::RADIO_MODE_TRANSCEIVER : inet::physicallayer::IRadio::RADIO_MODE_TRANSMITTER);
