//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_NODETAG_H_
#define __LOCPRIV_NODETAG_H_

#include <omnetpp.h>
#include "AllMsg_m.h"
#include "command.h"
//#include "authenticationTag.h"
#include "inet/physicallayer/contract/packetlevel/IRadio.h"
//#include "stdio.h"
#include "ModuleAccess.h"
#include "IMobility.h"



/**
 * TODO - Generated class
 */
class NodeTag : public cSimpleModule {
  protected:
    virtual void    initialize();
    virtual void    finish();
    virtual void    handleMessage(cMessage *msg);
    virtual void    tCmdChallenge(cMessage *msg);
    virtual void    tCmdQueryReply(cMessage *msg);
    virtual void    tCmdQueryRepReply(cMessage *msg);
    virtual void    tCmdSelect(cMessage *msg);
    virtual void    tCmdPcXpcEpc1(cMessage *msg);
    virtual void    tCmdPcXpcEpc2(cMessage *msg);
    virtual void    tCmdReqRNReply(cMessage *msg);
    virtual void    tCmdQueryAdjust(cMessage *msg);
    int             tXPC(char *sig);



    cGate *toRadio = nullptr;
    cGate *frRadio = nullptr;
    cGate *toAuth = nullptr;
    cGate *frAuth = nullptr;
    cGate *toHMAC = nullptr;
    cGate *frHMAC = nullptr;
 // cPacket *pktOut;

    cModule *radioModule;

    inet::physicallayer::IRadio *radio = nullptr;
//    cPacket *pktOut;

   // cMessage *currMsg;

    //Select
    int tagInventory[500];
    int tLength;        //Mask Length
    int tMask;          //Mask value
    int tMemBank;       //00:FileType  01:EPC  10:TID  11:File_0
    int tPointer;
    int whichSession;
    int hideTag;

    //Query verification
    int tSession;
    int tOldSession;
    int tSel;           // ALL: 0&1, ~SL:2, SL:3
    int tQ;

    //QueryReply
    int tSlotCounter;
    int tState;
    int tRN16;

    //ACK
    int tHandle;


    //reqRN
    bool startReply;
    int tAccessPwd;


    bool queryReplied;
    bool startAuth;

    //authentication
    int csiId;

    //tMax
    double tMax; //maximum time to wait before return to
    inet::IMobility  *mod;
    inet::Coord pos;
    cModule *thisNode;

  private:
        //int gsEPC96[12];
        int id;
        int gsEPC96[12] = {0x30, 0x74, 0x25, 0x7b, 0xf7, 0x19, 0x4e, 0x40, 0x00, 0x00, 0x00, 0x00};
 };

#endif
