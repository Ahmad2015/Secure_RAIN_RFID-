//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_AUTHENTICATIONSERVER_H_
#define __LOCPRIV_AUTHENTICATIONSERVER_H_

#include <omnetpp.h>
#include <command.h>
#include "AllMsg_m.h"


/**
 * TODO - Generated class
 */
class AuthenticationServer : public cSimpleModule
{
  protected:
    cGate *frServer;
    cGate *toServer;

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    void AES128_ECB_decrypt(int* input, const int* ikey, int *output);
    void BlockCopy(int* output, int* input);
    void InvCipher(void);
    void KeyExpansion(void);
    void AddRoundKey(int round);
    void InvMixColumns(void);
    void InvSubBytes(void);
    void InvShiftRows(void);
    int getSBoxValue(int num);
    int getSBoxInvert(int num);
    int xtime(int x);
    int Multiply(int x, int y);
    void decryptEPC(cMessage *msg);

    state_t*      sstate;

    //128bit keyR
     int AESkey[16] = {
             0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
             0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};

     const int* sAESKey;     // The Key input to the AES Program
     int sRoundKey[176];     // The array that stores the round keys.






};

#endif
