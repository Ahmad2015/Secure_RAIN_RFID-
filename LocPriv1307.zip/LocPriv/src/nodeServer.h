//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_NODESERVER_H_
#define __LOCPRIV_NODESERVER_H_

#include <omnetpp.h>
#include "AllMsg_m.h"
#include "command.h"
#include "inet/physicallayer/contract/packetlevel/IRadio.h"
#include "iostream"

/**
 * TODO - Generated class
 */
class NodeServer : public cSimpleModule
{
  protected:
    virtual void initialize();
    void finish();
    virtual void handleMessage(cMessage *msg);
 //   virtual void RTLS(int cT);
    void calculateDuration (int cR, int aR, int overheadType, simtime_t tStart, simtime_t tEnd);

    cGate *toReader [3];
    cGate *frReader [3];

    cGate *toLocate;
    cGate *frLocate;
    cGate *toAuth;
    cGate *frAuth;

    cModule *reader;
    double tRefQ        [3] [200];
    double locateBuffer [3] [200];
    double propagationSpeed;
    simtime_t preambleDuration;
    double bitrate;
    double headerBitLength = 1;

    int numReaders;
    int activeReaderTX;
    int currReader;

    int counterLocate;
    char readerName[11];

    double currX;
    double currY;
    double currZ;
    double currDist;
    double refToA;
    double currToA[3];
    double currTRefLoc;

    double distR1R2;
    double distR2R3;
    double distR1R3;

    simtime_t currWoAuth;
    simtime_t currWiAuth;

    inet::Coord coordReader [3];
    double distanceTag      [3] [200];
    simtime_t wiAuthDur     [3] [200];
    simtime_t woAuthDur     [3] [200];
    simtime_t tofRT         [3] [200];
    simtime_t rxTime        [3] [200];
    simtime_t rxTimePrime   [3] [200];
    simtime_t overheadRTR;

    int seqLoc = 0;
    int numTags;
    int Q;
    int seed;
    int multime;
    int cryptoSuite;
    int method;
    int h;
    int iterLocTmp; // to calculate the positioning instance

    simtime_t startReaderTime   [3];
    simtime_t endReaderTime     [3];
    simtime_t startOverallTime;
    simtime_t endOverallTime;
    simtime_t startLocateTime;
    simtime_t endLocateTime;

    simtime_t overallAuthTime;
    simtime_t overallDiscoveryTime;
    simtime_t overallTime;
    simtime_t recvTRefLocMsg;

//  typedef struct {
//        int readerId;
//        int tagId;
//        int tempsRef;
//        int distance;
//  } locDetail;
//  locDetail locDetails[30][1000][5];//reader-tag-n

//    simtime_t locTmps   [30] [1000] [5];

    typedef struct {
        int csi_ID;
        int Q;
        int activeTags;
        int totQRep;
        int totQAdj;
        int totReq;
        int totCol;
        double WoutAuth;
        double WithAuth;
        double toa  [200];
    }rDetail;
    rDetail ReaderDetail    [30];

    inet::Coord tagsCoordinate  [200];
    bool boolRTLS;

    int tagEPC[100] = {999999999};
    simtime_t locTimeUpdate[400];
    int locReaderCounter = 0;
    simtime_t locDurationUpdate[30][100][10];
    int locTagId;

    //typedef struct {
    //    int     reader;
    //    int     tag;
    //    int     seq;
    //    double  distance;
    //    simtime_t timeUpdate;
    //}locUpdate;
    //locUpdate locUpdateList[1500] = {};


    simtime_t locUpdateList[200][3][2400] = {}; //seq = numhosts * 12
    simtime_t overheadRT_ACK;
    simtime_t overheadTR_EPC;
    simtime_t overheadRT_ReqRN;
    simtime_t overheadTR_Handle;
    simtime_t overheadRT_AuthAES1;
    simtime_t overheadTR_RespAES1;
    simtime_t overheadXchange1;
    simtime_t overheadXchange2;
    simtime_t overheadXchange3;

    simtime_t activeRT_propTime;
    double distRefRT;
    simtime_t propRefTime;

    int constraintAreaMaxX;
    int constraintAreaMaxY;
    double maxCoverage;
    simtime_t diffTime1;
    simtime_t propTime1;
    simtime_t propTime2;
    simtime_t   tmpOverhead;
    int         tmpOverheadType;
    double      distTRprime;

};

#endif
