//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __LOCPRIV_NODEREADER_H_
#define __LOCPRIV_NODEREADER_H_

#include <omnetpp.h>
#include "AllMsg_m.h"
#include "command.h"
#include "inet/physicallayer/contract/packetlevel/IRadio.h"
#include "inet/physicallayer/common/packetlevel/Radio.h"
#include "inet/physicallayer/common/packetlevel/RadioMedium.h"
#include "ModuleAccess.h"
#include "IMobility.h"
#include "MobilityBase.h"

/**
 * TODO - Generated class
 */
class NodeReader : public cSimpleModule
{
  protected:
    virtual void initialize();
    void finish();
    virtual void handleMessage(cMessage *msg);
    void        rCmdSelect();
    void        rCmdChallenge();
    void        rCmdQuery();
    void        rCmdQueryAdj();
    void        rCmdQueryRep();
    void        rCmdQueryResponse(cMessage *msg);
    void        rCmdReqRN1(cMessage *msg);
    void        rCmdReqRN2(cMessage *msg);
    void        rCmdHandle(cMessage *msg);
    void        rCmdAck();
    int         rXPC(char *sig);
    void        currentPosition(simtime_t ToA);
    int         method;
    int         endMethod;
    int         currReaderId;


    cGate *toRadio = nullptr;
    cGate *frRadio = nullptr;
    cGate *toServer = nullptr;
    cGate *frServer = nullptr;
    cGate *toAuth = nullptr;
    cGate *frAuth = nullptr;

    cModule *thisNode;
    cModule *radioModule;
    inet::Coord pos;
    inet::IMobility  *mod;
    inet::physicallayer::IRadio *radio1 = nullptr;
//    inet::physicallayer::RadioMedium *radioMedium = nullptr;
    inet::physicallayer::ITransmission *currentTransmisson = nullptr;

    int whichSession;
    int rAction;
    int seed;

    //statistics
    int totalCollision = 0;
    int iterCollision = 0;

    int numActive = 0;
    int qRepCount;
    int qAdjCount;
//    int totalQuery;
    int totalRequest = 0;

    simtime_t startOperationTime;
    simtime_t startQueryTime;
    simtime_t startQueryRepTime;
    simtime_t startAuthTime;
    simtime_t totalAuthTime;
    simtime_t rcvQueryRepTime;
    simtime_t endReceptionTime;
    simtime_t processTime;
    simtime_t preambleDuration;
    simtime_t queryInitTime;        // to be used to calculate query time for each tag.
    simtime_t currQueryDuration;    // query duration for each tag.

//    simtime_t timeOutTimer;
//    simtime_t timeOutTimer1;

    simtime_t waitTimer;
    simtime_t waitSelect;
    simtime_t waitChallenge;
    simtime_t waitQuery;
    simtime_t waitQueryRep;
    simtime_t waitQueryAdj;
    simtime_t waitACK;
    simtime_t waitHandle;

    simtime_t durTot;
    simtime_t durQuery;
    simtime_t durQueryRep;
    simtime_t toaTime[500];
    simtime_t durWoAuth;
    double currentDistance;

//    double distR1R2;
//    double distR2R3;
//    double distR1R3;

    //double distTag[100];
    double propagationSpeed;

    //Query Command
    int slotCounter;
    int rSel;
    int rTarget;
    int rSession;
    int rQ;
    int numTags;
    int totRepCount;

    int iterQuery;
    int iterQueryRep; //QueryRep command
    int iterQueryAdj; //QueryAdj command

     //QueryReply
     int RN16tref;  //RN16 received with QueryRep
     int RN16loc;   //RN16 equivalent to RN16tRef but required when R inactive

     //handle
     bool verify1;
     bool queryCx;
     int csiId;
     int challCSI;
     bool startQuery;

     bool replied;
     bool isCollision;
     bool isRecepting;

     //authentication
     int CryptoSuite;

     double bitrate;
     int headerBitLength;
     int maxCoverage;
 //    simtime_t processTime;
     double frameOverhead;
 //  int multime;
     int currentId;
//     double currDist;
     simtime_t currToa;
     int constraintAreaMaxX;
     int constraintAreaMaxY;

     int hideEPC128[20];

     simtime_t ToA2;
     simtime_t ToA3;
     simtime_t ToA4;
     simtime_t ToaEPC;
     simtime_t ToaHandle;
     simtime_t ToApassive3;

     simtime_t startLocAck2;
     simtime_t startLocRqRn3;
     simtime_t startLocAuth4;
     simtime_t startLocQueryRep;
     simtime_t startLocEPC;
     simtime_t startLocHandle;
     simtime_t startLocPassive3;
     simtime_t startLocPassive4;
     int locSequence = 0;
     simtime_t locTime[500];
     int locTagId;


};

#endif
